package interfaces;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.Icon;
import ConexionBD.Conexion;
import static interfaces.GestionarVentas.IDVentas_update;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class GestionarFacturas extends javax.swing.JFrame {

    public GestionarFacturas() {

        initComponents();

        setSize(450, 500);
        setResizable(false);
        setTitle("Gestión de Facturas");
        setLocationRelativeTo(null);

        inicializarVentana();
    }

    private void inicializarVentana() {
        cargarDatosCampos();
    }

    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("images/Icono.png"));
        return retValue;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel_Titulo = new javax.swing.JLabel();
        jTextField_CP = new javax.swing.JTextField();
        jTextField_Nombre = new javax.swing.JTextField();
        jTextField_RFC = new javax.swing.JTextField();
        JLabel_RFC = new javax.swing.JLabel();
        jLabel_Nombre = new javax.swing.JLabel();
        jLabel_CP = new javax.swing.JLabel();
        jLabel_Productos = new javax.swing.JLabel();
        jLabel_Regimen = new javax.swing.JLabel();
        jTextField_Regimen = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea_Productos = new javax.swing.JTextArea();
        jLabel_Factura = new javax.swing.JLabel();
        jTextField_Factura = new javax.swing.JTextField();
        jTextField_Fecha = new javax.swing.JTextField();
        jLabel_Fecha = new javax.swing.JLabel();
        jLabel_Venta = new javax.swing.JLabel();
        jTextField_Venta = new javax.swing.JTextField();
        jLabel_logo = new javax.swing.JLabel();
        jButton_Salir = new javax.swing.JButton();
        jLabel_Indicaciones = new javax.swing.JLabel();
        jLabel_Wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel_Titulo.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Titulo.setText("GESTION DE FACTURAS");
        getContentPane().add(jLabel_Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, 260, 20));

        jTextField_CP.setEditable(false);
        jTextField_CP.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_CP.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_CP.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_CP.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_CP.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_CP.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_CP, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 220, 110, 20));

        jTextField_Nombre.setEditable(false);
        jTextField_Nombre.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Nombre.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_Nombre.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Nombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Nombre.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Nombre.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 240, 20));

        jTextField_RFC.setEditable(false);
        jTextField_RFC.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_RFC.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_RFC.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_RFC.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_RFC.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_RFC.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_RFC, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 270, 110, 20));

        JLabel_RFC.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        JLabel_RFC.setText("RFC");
        getContentPane().add(JLabel_RFC, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 250, -1, -1));

        jLabel_Nombre.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Nombre.setText("Nombre o Denominación Social");
        getContentPane().add(jLabel_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 240, -1));

        jLabel_CP.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_CP.setText("Código Postal");
        getContentPane().add(jLabel_CP, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 200, -1, -1));

        jLabel_Productos.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Productos.setText("Productos comprados en la venta:");
        getContentPane().add(jLabel_Productos, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 310, -1, -1));

        jLabel_Regimen.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Regimen.setText("Régimen Fiscal");
        getContentPane().add(jLabel_Regimen, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, -1, -1));

        jTextField_Regimen.setEditable(false);
        jTextField_Regimen.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Regimen.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_Regimen.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Regimen.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Regimen.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Regimen.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Regimen, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, 240, 20));

        jTextArea_Productos.setEditable(false);
        jTextArea_Productos.setBackground(new java.awt.Color(255, 255, 255));
        jTextArea_Productos.setColumns(20);
        jTextArea_Productos.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextArea_Productos.setForeground(new java.awt.Color(0, 0, 0));
        jTextArea_Productos.setRows(5);
        jTextArea_Productos.setCaretColor(new java.awt.Color(0, 0, 0));
        jTextArea_Productos.setSelectedTextColor(new java.awt.Color(0, 0, 0));
        jScrollPane1.setViewportView(jTextArea_Productos);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, 380, 110));

        jLabel_Factura.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Factura.setText("¿Requiere Factura?");
        getContentPane().add(jLabel_Factura, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, -1, 20));

        jTextField_Factura.setEditable(false);
        jTextField_Factura.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Factura.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_Factura.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Factura.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Factura.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Factura.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Factura, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, 110, 20));

        jTextField_Fecha.setEditable(false);
        jTextField_Fecha.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Fecha.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_Fecha.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Fecha.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Fecha.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Fecha.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Fecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 170, 100, 20));

        jLabel_Fecha.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Fecha.setText("Fecha");
        getContentPane().add(jLabel_Fecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 150, -1, -1));

        jLabel_Venta.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Venta.setText("Venta ID");
        getContentPane().add(jLabel_Venta, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 150, -1, -1));

        jTextField_Venta.setEditable(false);
        jTextField_Venta.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Venta.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_Venta.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Venta.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Venta.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Venta.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Venta, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 170, 110, 20));

        jLabel_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Logo 2.png"))); // NOI18N
        getContentPane().add(jLabel_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 20, 70, 70));

        jButton_Salir.setBackground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setForeground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerca 1.png"))); // NOI18N
        jButton_Salir.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Salir.setContentAreaFilled(false);
        jButton_Salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 20, 60, 60));

        jLabel_Indicaciones.setFont(new java.awt.Font("Times New Roman", 3, 10)); // NOI18N
        jLabel_Indicaciones.setForeground(new java.awt.Color(19, 36, 145));
        jLabel_Indicaciones.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Indicaciones.setText("INFORMACIÓN DE FACTURA: DETALLES DE LA TRANSACCIÓN");
        getContentPane().add(jLabel_Indicaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, 310, 10));

        jLabel_Wallpaper.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Fondo2.png"))); // NOI18N
        getContentPane().add(jLabel_Wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 450, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SalirActionPerformed
        dispose();
        
    }//GEN-LAST:event_jButton_SalirActionPerformed

    private void cargarDatosCampos() {
        try {
            // Conexión a la base de datos
            java.sql.Connection conn = Conexion.conectar();

            // Consulta para obtener los datos de ventas según el ID de ventas
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Ventas WHERE VentaID = ?");
            stmt.setInt(1, IDVentas_update);
            ResultSet rs = stmt.executeQuery();

            // Limpiar el JTextArea antes de agregar nuevos datos
            jTextArea_Productos.setText("");

            // Iterar sobre los resultados de la consulta y agregarlos al JTextArea
            while (rs.next()) {
                double precio = rs.getDouble("Precio");
                double total = rs.getDouble("Total");
                int cantidad = rs.getInt("Cantidad");
                String codigoID = rs.getString("ProductoID");
                String nombre = rs.getString("Producto");

                jTextField_Nombre.setText(rs.getString("NombreDenominacion"));
                jTextField_CP.setText(rs.getString("CP"));
                jTextField_Factura.setText(rs.getString("Factura"));
                jTextField_Regimen.setText(rs.getString("Regimen"));
                jTextField_RFC.setText(rs.getString("RFC"));
                jTextField_Fecha.setText(rs.getString("Fecha"));
                jTextField_Venta.setText(rs.getString("VentaID"));

                // Construir la cadena de texto con los datos y agregarla al JTextArea
                StringBuilder textoProductoBuilder = new StringBuilder("---------------------\n");

                textoProductoBuilder.append(String.format("%-5s: %s\n", "Codigo Producto", codigoID));
                textoProductoBuilder.append(String.format("%-5s: %s\n", "Producto", nombre));
                textoProductoBuilder.append(String.format("%-5s: $%.2f MXN\n", "Precio Unitario", precio));
                textoProductoBuilder.append(String.format("%-5s: %d\n", "Cantidad", cantidad));
                textoProductoBuilder.append(String.format("%-5s: $%.2f MXN\n", "Total", total));

                String textoProducto = textoProductoBuilder.toString();
                jTextArea_Productos.append(textoProducto);
            }

            // Cerrar los recursos
            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos, intentelo de nuevo");
            ex.printStackTrace();
        }

    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GestionarFacturas.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GestionarFacturas.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GestionarFacturas.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GestionarFacturas.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JLabel_RFC;
    private javax.swing.JButton jButton_Salir;
    private javax.swing.JLabel jLabel_CP;
    private javax.swing.JLabel jLabel_Factura;
    private javax.swing.JLabel jLabel_Fecha;
    private javax.swing.JLabel jLabel_Indicaciones;
    private javax.swing.JLabel jLabel_Nombre;
    private javax.swing.JLabel jLabel_Productos;
    private javax.swing.JLabel jLabel_Regimen;
    private javax.swing.JLabel jLabel_Titulo;
    private javax.swing.JLabel jLabel_Venta;
    private javax.swing.JLabel jLabel_Wallpaper;
    private javax.swing.JLabel jLabel_logo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea_Productos;
    private javax.swing.JTextField jTextField_CP;
    private javax.swing.JTextField jTextField_Factura;
    private javax.swing.JTextField jTextField_Fecha;
    private javax.swing.JTextField jTextField_Nombre;
    private javax.swing.JTextField jTextField_RFC;
    private javax.swing.JTextField jTextField_Regimen;
    private javax.swing.JTextField jTextField_Venta;
    // End of variables declaration//GEN-END:variables
}
