package interfaces;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import ConexionBD.Conexion;
import javax.swing.table.DefaultTableModel;

public class gestionarVentas extends javax.swing.JFrame {
        String user;
    public static int IDcliente_update = 0;
    DefaultTableModel model = new DefaultTableModel();

    public gestionarVentas() {
        initComponents();
        setSize(550, 500);
        setResizable(false);
        setTitle("Gestión de Ventas");
        setLocationRelativeTo(null);

        ImageIcon wallpaper = new ImageIcon("src/images/Fondo2.png");
        Icon icono = new ImageIcon(wallpaper.getImage().getScaledInstance(jLabel_Wallpaper.getWidth(), jLabel_Wallpaper.getHeight(), Image.SCALE_DEFAULT));
        jLabel_Wallpaper.setIcon(icono);
        this.repaint();

        ImageIcon wallpaper_logo = new ImageIcon("src/images/Logo.png");
        Icon icono_logo = new ImageIcon(wallpaper_logo.getImage().getScaledInstance(jLabel_logo.getWidth(), jLabel_logo.getHeight(), Image.SCALE_DEFAULT));
        jLabel_logo.setIcon(icono_logo);
        this.repaint();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton_Salir = new javax.swing.JButton();
        jLabel_iconUser = new javax.swing.JLabel();
        jLabel_nameUser = new javax.swing.JLabel();
        jLabel_numUser = new javax.swing.JLabel();
        jLabel_logo = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Ventas = new javax.swing.JTable();
        jLabel_Titulo = new javax.swing.JLabel();
        jDateChooser_Fin = new com.toedter.calendar.JDateChooser();
        jDateChooser_Inicio = new com.toedter.calendar.JDateChooser();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel_FechaFin = new javax.swing.JLabel();
        jLabel_Factura = new javax.swing.JLabel();
        jLabel_FechaIn = new javax.swing.JLabel();
        jButton_Guardar = new javax.swing.JButton();
        jLabel_Wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton_Salir.setBackground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setForeground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerca 1.png"))); // NOI18N
        jButton_Salir.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Salir.setContentAreaFilled(false);
        jButton_Salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 20, 30, 30));

        jLabel_iconUser.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_iconUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/usuario 2.png"))); // NOI18N
        getContentPane().add(jLabel_iconUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 45, 45));

        jLabel_nameUser.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_nameUser.setText("A");
        getContentPane().add(jLabel_nameUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 130, 20));

        jLabel_numUser.setText("AQUI ESTA");
        getContentPane().add(jLabel_numUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, 130, 20));
        getContentPane().add(jLabel_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 10, 70, 70));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black, java.awt.Color.black, java.awt.Color.black));
        jScrollPane1.setForeground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setFont(new java.awt.Font("Times New Roman", 1, 10)); // NOI18N

        jTable_Ventas.setAutoCreateRowSorter(true);
        jTable_Ventas.setBackground(new java.awt.Color(255, 255, 255));
        jTable_Ventas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jTable_Ventas.setFont(new java.awt.Font("Times New Roman", 0, 10)); // NOI18N
        jTable_Ventas.setForeground(new java.awt.Color(0, 0, 0));
        jTable_Ventas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Producto", "Total", "Factura"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable_Ventas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jTable_Ventas.setSelectionBackground(new java.awt.Color(255, 255, 255));
        jTable_Ventas.setSelectionForeground(new java.awt.Color(0, 0, 0));
        jScrollPane1.setViewportView(jTable_Ventas);
        if (jTable_Ventas.getColumnModel().getColumnCount() > 0) {
            jTable_Ventas.getColumnModel().getColumn(0).setResizable(false);
            jTable_Ventas.getColumnModel().getColumn(1).setResizable(false);
            jTable_Ventas.getColumnModel().getColumn(2).setResizable(false);
            jTable_Ventas.getColumnModel().getColumn(3).setResizable(false);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, 480, 180));

        jLabel_Titulo.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Titulo.setText("GESTION DE VENTAS");
        getContentPane().add(jLabel_Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, 230, 20));

        jDateChooser_Fin.setBackground(new java.awt.Color(255, 255, 255));
        jDateChooser_Fin.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black));
        jDateChooser_Fin.setForeground(new java.awt.Color(0, 0, 0));
        jDateChooser_Fin.setDateFormatString("d/MMM/y");
        jDateChooser_Fin.setFont(new java.awt.Font("Times New Roman", 0, 10)); // NOI18N
        getContentPane().add(jDateChooser_Fin, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 170, 130, 30));

        jDateChooser_Inicio.setBackground(new java.awt.Color(255, 255, 255));
        jDateChooser_Inicio.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black));
        jDateChooser_Inicio.setForeground(new java.awt.Color(0, 0, 0));
        jDateChooser_Inicio.setDateFormatString("d/MMM/y");
        jDateChooser_Inicio.setFont(new java.awt.Font("Times New Roman", 0, 10)); // NOI18N
        getContentPane().add(jDateChooser_Inicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, 130, 30));

        jComboBox1.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox1.setFont(new java.awt.Font("Times New Roman", 0, 10)); // NOI18N
        jComboBox1.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Si", "No" }));
        jComboBox1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black));
        getContentPane().add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 170, 60, 30));

        jLabel_FechaFin.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_FechaFin.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel_FechaFin.setText("Fecha Fin");
        getContentPane().add(jLabel_FechaFin, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, -1, -1));

        jLabel_Factura.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Factura.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel_Factura.setText("Factura");
        getContentPane().add(jLabel_Factura, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 150, -1, -1));

        jLabel_FechaIn.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_FechaIn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel_FechaIn.setText("Fecha Inicio");
        getContentPane().add(jLabel_FechaIn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 90, -1));

        jButton_Guardar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Guardar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Guardar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/buscar.png"))); // NOI18N
        jButton_Guardar.setText("Buscar");
        jButton_Guardar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_GuardarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 170, 70, 30));
        getContentPane().add(jLabel_Wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 550, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SalirActionPerformed
        dispose();
        new administrador().setVisible(true);
    }//GEN-LAST:event_jButton_SalirActionPerformed

    private void jButton_GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_GuardarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton_GuardarActionPerformed

       @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("images/Icono.png"));
        return retValue;
    } 
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(gestionarVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(gestionarVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(gestionarVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(gestionarVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new gestionarVentas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Guardar;
    private javax.swing.JButton jButton_Salir;
    private javax.swing.JComboBox<String> jComboBox1;
    private com.toedter.calendar.JDateChooser jDateChooser_Fin;
    private com.toedter.calendar.JDateChooser jDateChooser_Inicio;
    private javax.swing.JLabel jLabel_Factura;
    private javax.swing.JLabel jLabel_FechaFin;
    private javax.swing.JLabel jLabel_FechaIn;
    private javax.swing.JLabel jLabel_Titulo;
    private javax.swing.JLabel jLabel_Wallpaper;
    private javax.swing.JLabel jLabel_iconUser;
    private javax.swing.JLabel jLabel_logo;
    private javax.swing.JLabel jLabel_nameUser;
    private javax.swing.JLabel jLabel_numUser;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Ventas;
    // End of variables declaration//GEN-END:variables
}
