package interfaces;

import Comandos.CreacionUsuarios;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import ConexionBD.Conexion;
import java.sql.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class gestionarEmpleados extends javax.swing.JFrame {

    // Variables para almacenar información del usuario y empleado seleccionado
    public static String usuario;
    public static String password;
    public static String TipoUsuario;
    public static int IDEmpleados_update;

    // Modelo de tabla predeterminado para la tabla de empleados
    DefaultTableModel model = new DefaultTableModel();

    //Constructor de la clase
    public gestionarEmpleados() {
        initComponents(); // Inicializa componentes de la interfaz
        setSize(650, 520); // Establece tamaño de la ventana
        setResizable(false); // Hace que la ventana no sea redimensionable
        setTitle("Gestión Empleados"); // Establece el título de la ventana
        setLocationRelativeTo(null); // Centra la ventana en la pantalla

        // Configuración de botónes extra
        jButton_Actualizar.setEnabled(false);
        jButton_Borrar.setEnabled(false);

        // Llama al método para llenar la tabla y los campos
        cargarDatosTabla();
        jLabel_nameUser.setText("Empleado: " + ingreso.nomEmpleado);
        jLabel_numUser.setText("Número Empleado: " + ingreso.numEmpleado);
    }

// Método para obtener el icono de la aplicación
    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("images/Icono.png"));
        return retValue;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton_Salir = new javax.swing.JButton();
        jLabel_iconUser = new javax.swing.JLabel();
        jLabel_logo = new javax.swing.JLabel();
        jTextField_Nombre = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Factura = new javax.swing.JTable();
        jLabel_Nombre = new javax.swing.JLabel();
        jLabel_Cargo = new javax.swing.JLabel();
        jLabel_Estado = new javax.swing.JLabel();
        jButton_Actualizar = new javax.swing.JButton();
        jButton_Guardar = new javax.swing.JButton();
        jLabel_Titulo = new javax.swing.JLabel();
        jComboBox_Estado = new javax.swing.JComboBox<>();
        jComboBox_Cargo = new javax.swing.JComboBox<>();
        jTextField_User = new javax.swing.JTextField();
        jLabel_Password = new javax.swing.JLabel();
        jLabel_User = new javax.swing.JLabel();
        jPassword_Password = new javax.swing.JPasswordField();
        jLabel_Nacimiento = new javax.swing.JLabel();
        jTextField_Contacto = new javax.swing.JTextField();
        jLabel_Contacto = new javax.swing.JLabel();
        jDateChooser_Nacimiento = new com.toedter.calendar.JDateChooser();
        jLabel_nameUser = new javax.swing.JLabel();
        jLabel_numUser = new javax.swing.JLabel();
        jButton_Borrar = new javax.swing.JButton();
        jLabel_Wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton_Salir.setBackground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setForeground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerca 1.png"))); // NOI18N
        jButton_Salir.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Salir.setContentAreaFilled(false);
        jButton_Salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 20, 45, 45));

        jLabel_iconUser.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_iconUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/usuario 2.png"))); // NOI18N
        getContentPane().add(jLabel_iconUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 45, 45));

        jLabel_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Logo 2.png"))); // NOI18N
        jLabel_logo.setLabelFor(jLabel_logo);
        getContentPane().add(jLabel_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 10, 70, 70));

        jTextField_Nombre.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Nombre.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 10)); // NOI18N
        jTextField_Nombre.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Nombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Nombre.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Nombre.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, 260, 20));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jScrollPane1.setForeground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setFont(new java.awt.Font("Times New Roman", 1, 10)); // NOI18N

        jTable_Factura.setBackground(new java.awt.Color(255, 255, 255));
        jTable_Factura.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2)));
        jTable_Factura.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTable_Factura.setForeground(new java.awt.Color(0, 0, 0));
        jTable_Factura.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable_Factura.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable_Factura);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, 600, 120));

        jLabel_Nombre.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Nombre.setText("Nombre Empleado");
        getContentPane().add(jLabel_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, -1, 20));

        jLabel_Cargo.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Cargo.setText("Cargo");
        getContentPane().add(jLabel_Cargo, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 150, -1, -1));

        jLabel_Estado.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Estado.setText("Estado");
        getContentPane().add(jLabel_Estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 150, -1, 20));

        jButton_Actualizar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Actualizar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Actualizar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Actualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/actualizar.png"))); // NOI18N
        jButton_Actualizar.setText("Actualizar");
        jButton_Actualizar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Actualizar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_ActualizarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 260, 105, 35));

        jButton_Guardar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Guardar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Guardar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/salvar (1).png"))); // NOI18N
        jButton_Guardar.setText("Cargar Datos");
        jButton_Guardar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Guardar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_GuardarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 260, 105, 35));

        jLabel_Titulo.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Titulo.setText("GESTION DE EMPLEADOS");
        getContentPane().add(jLabel_Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 90, 250, 25));

        jComboBox_Estado.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_Estado.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 10)); // NOI18N
        jComboBox_Estado.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_Estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Inactivo" }));
        jComboBox_Estado.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jComboBox_Estado.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().add(jComboBox_Estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 170, 100, 20));

        jComboBox_Cargo.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_Cargo.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 10)); // NOI18N
        jComboBox_Cargo.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_Cargo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Gerente", "Empleado" }));
        jComboBox_Cargo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jComboBox_Cargo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().add(jComboBox_Cargo, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 170, 100, 20));

        jTextField_User.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_User.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 10)); // NOI18N
        jTextField_User.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_User.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_User.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_User.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_User, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 220, 110, 25));

        jLabel_Password.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Password.setText("Password");
        getContentPane().add(jLabel_Password, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 200, 50, -1));

        jLabel_User.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_User.setText("Usuario");
        getContentPane().add(jLabel_User, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 200, 60, -1));

        jPassword_Password.setBackground(new java.awt.Color(255, 255, 255));
        jPassword_Password.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 10)); // NOI18N
        jPassword_Password.setForeground(new java.awt.Color(0, 0, 0));
        jPassword_Password.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPassword_Password.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black));
        getContentPane().add(jPassword_Password, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 220, 100, 25));

        jLabel_Nacimiento.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Nacimiento.setText("Fecha de Nacimiento");
        getContentPane().add(jLabel_Nacimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 200, 100, -1));

        jTextField_Contacto.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Contacto.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 10)); // NOI18N
        jTextField_Contacto.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Contacto.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Contacto.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Contacto.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Contacto, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 220, 120, 25));

        jLabel_Contacto.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Contacto.setText("Contacto");
        getContentPane().add(jLabel_Contacto, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, 50, -1));

        jDateChooser_Nacimiento.setBackground(new java.awt.Color(255, 255, 255));
        jDateChooser_Nacimiento.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black));
        jDateChooser_Nacimiento.setForeground(new java.awt.Color(0, 0, 0));
        jDateChooser_Nacimiento.setDateFormatString("d/MMM/y");
        jDateChooser_Nacimiento.setDebugGraphicsOptions(javax.swing.DebugGraphics.LOG_OPTION);
        jDateChooser_Nacimiento.setFocusCycleRoot(true);
        jDateChooser_Nacimiento.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        getContentPane().add(jDateChooser_Nacimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 220, 130, 25));

        jLabel_nameUser.setFont(new java.awt.Font("Tw Cen MT", 1, 10)); // NOI18N
        jLabel_nameUser.setForeground(new java.awt.Color(19, 36, 145));
        getContentPane().add(jLabel_nameUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, 130, 20));

        jLabel_numUser.setFont(new java.awt.Font("Tw Cen MT", 1, 10)); // NOI18N
        jLabel_numUser.setForeground(new java.awt.Color(19, 36, 145));
        getContentPane().add(jLabel_numUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 40, 130, 20));

        jButton_Borrar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Borrar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Borrar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Borrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/borrar.png"))); // NOI18N
        jButton_Borrar.setText("Eliminar");
        jButton_Borrar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Borrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_BorrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Borrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 260, 105, 35));

        jLabel_Wallpaper.setBackground(new java.awt.Color(255, 255, 255));
        jLabel_Wallpaper.setForeground(new java.awt.Color(0, 0, 0));
        jLabel_Wallpaper.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Fondo2.png"))); // NOI18N
        jLabel_Wallpaper.setLabelFor(jLabel_Wallpaper);
        getContentPane().add(jLabel_Wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 520));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Método para llenar la tabla y los campos correspondientes
    private void cargarDatosTabla() {
        try {
            java.sql.Connection HA = Conexion.conectar();
            PreparedStatement PHA = HA.prepareStatement("select * from Empleados");
            ResultSet HA1 = PHA.executeQuery();

            // Configura el modelo de la tabla
            DefaultTableModel model = new DefaultTableModel() {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false; // Hace que todas las celdas de la tabla no sean editables
                }
            };
            // Llena la tabla con los datos obtenidos de la base de datos
            model.addColumn("UsuarioID ");
            model.addColumn("Nombre");
            model.addColumn("Usuario");
            model.addColumn("Contraseña");
            model.addColumn("Cargo");
            model.addColumn("Estado");
            model.addColumn("Contacto");
            model.addColumn("Nacimiento");

            while (HA1.next()) {
                Object[] fila = new Object[8];
                for (int i = 0; i < 8; i++) {
                    fila[i] = HA1.getObject(i + 1);
                }
                model.addRow(fila);
            }

            // Establece el modelo en la tabla
            jTable_Factura = new JTable(model); // Aquí se crea la tabla con el modelo configurado
            jTable_Factura
                    .setDefaultEditor(Object.class,
                            null); // Hace que la tabla no sea editable
            jScrollPane1.setViewportView(jTable_Factura);

            //Añade un evento para cuando se hace clic en algún registro de la tabla
            jTable_Factura.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int fila_point = jTable_Factura.rowAtPoint(e.getPoint());
                    int columna_point = 0;
                    if (fila_point > -1) {
                        jButton_Actualizar.setEnabled(true); // Habilita el botón de actualizar
                        jButton_Borrar.setEnabled(true);// Habilita el botón de aborrar
                        jButton_Guardar.setEnabled(false); // Deshabilita el botón de guardar
                        jTextField_User.setEnabled(false);// Deshabilita el textfied de usuario y password
                        jPassword_Password.setEnabled(false);
                        //Recibe el UsuarioID de acuerdo al registro seleccionado en la tabla
                        IDEmpleados_update = (int) model.getValueAt(fila_point, columna_point);
                        java.sql.Connection HA = Conexion.conectar();
                        PreparedStatement PHA;

                        //Realiza una consulta para recuperar los datos de acuerdo al ID y los coloca en el campo correspondiente
                        try {
                            PHA = HA.prepareStatement("select * from Empleados where UsuarioID = '" + IDEmpleados_update + "'");
                            ResultSet HA1 = PHA.executeQuery();
                            if (HA1.next()) {
                                jTextField_Nombre.setText(HA1.getString("NombreEmpleado"));
                                jTextField_Contacto.setText(HA1.getString("Contacto"));
                                jTextField_User.setText(HA1.getString("NombreUsuario"));
                                jPassword_Password.setText(HA1.getString("Contrasena"));
                                jDateChooser_Nacimiento.setDate(HA1.getDate("FechaNacimiento"));
                                //Para los combobox se recibe la informacion y en base a esa se revisa que exista en las opciones
                                String valorEstado = HA1.getString("Estado");
                                for (int i = 0; i < jComboBox_Estado.getItemCount(); i++) {
                                    if (jComboBox_Estado.getItemAt(i).equals(valorEstado)) {
                                        jComboBox_Estado.setSelectedIndex(i);
                                        break;
                                    }
                                }
                                String valorTipo = HA1.getString("TipoUsuario");
                                for (int i = 0; i < jComboBox_Cargo.getItemCount(); i++) {
                                    if (jComboBox_Cargo.getItemAt(i).equals(valorTipo)) {
                                        jComboBox_Cargo.setSelectedIndex(i);
                                        break;
                                    }
                                }

                            }
                            // Si se produce una excepción SQLException, se captura y se maneja aquí
                        } catch (SQLException ex) {
                            System.err.println("Error al cargar usuario" + e);
                            JOptionPane.showMessageDialog(null, "Error al cargar contactar administrador");
                        }
                    }
                }
            });
        } catch (SQLException ex) {
            Logger.getLogger(gestionarEmpleados.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

//Metodo del boton salir
    private void jButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SalirActionPerformed
        dispose();
        new administrador().setVisible(true);
    }//GEN-LAST:event_jButton_SalirActionPerformed

    //Metodo del boton guardar
    private void jButton_GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_GuardarActionPerformed
        usuario = jTextField_User.getText().trim();
        password = String.valueOf(jPassword_Password.getPassword()).trim();
        TipoUsuario = (String) jComboBox_Cargo.getSelectedItem();
        String Estado = (String) jComboBox_Estado.getSelectedItem();
        String Contacto = jTextField_Contacto.getText().trim();
        String NombreEmpleado = jTextField_Nombre.getText().trim();
        Date FechaNacimiento = jDateChooser_Nacimiento.getDate();

        // Validación para asegurarse de que no haya campos vacíos
        if (TipoUsuario.isEmpty() || Estado.isEmpty() || Contacto.isEmpty()
                || NombreEmpleado.isEmpty() || usuario.isEmpty() || password.isEmpty() || FechaNacimiento == null) {
            JOptionPane.showMessageDialog(null, "Por favor complete todos los campos obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        } else {
            // Paso de parámetros para la creación del usuario en la base de datos
            CreacionUsuarios.crearNuevoUsuario(usuario, password);
            java.sql.Connection HA = Conexion.conectar();
            if (HA != null) {
                try {
                    // Prepara la consulta SQL para insertar un nuevo empleado en la base de datos
                    String insertQuery = "INSERT INTO Empleados (UsuarioID, NombreEmpleado, NombreUsuario, Contrasena,"
                            + " TipoUsuario, Estado, Contacto, FechaNacimiento) "
                            + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    PreparedStatement preparedStatement = HA.prepareStatement(insertQuery);

                    // Establece los valores de los parámetros en la consulta preparada
                    preparedStatement.setString(1, ""); // Se debe establecer adecuadamente el valor del ID del usuario
                    preparedStatement.setString(2, NombreEmpleado);
                    preparedStatement.setString(3, usuario);
                    preparedStatement.setString(4, password);
                    preparedStatement.setString(5, TipoUsuario);
                    preparedStatement.setString(6, Estado);
                    preparedStatement.setString(7, Contacto);
                    preparedStatement.setDate(8, new java.sql.Date(FechaNacimiento.getTime()));

                    // Ejecuta la consulta SQL para insertar los datos del nuevo empleado en la base de datos
                    int rowsInserted = preparedStatement.executeUpdate();
                    if (rowsInserted > 0) {
                        JOptionPane.showMessageDialog(null, "Empleado registrado correctamente.", "Exito", JOptionPane.INFORMATION_MESSAGE);;
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al registrar empleado.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (SQLException e) {
                    // Captura y maneja cualquier excepción SQLException que pueda ocurrir durante la ejecución de la consulta SQL
                    JOptionPane.showMessageDialog(null, "Error al ejecutar la consulta SQL: ", "Error", JOptionPane.ERROR_MESSAGE);
                } finally {
                    // Cierra la conexión a la base de datos
                    Conexion.cerrarConexion(HA);
                }
            } else {
                JOptionPane.showMessageDialog(null, "No se pudo establecer conexión a la base de datos.", "Error", JOptionPane.ERROR);
            }
        }
    }//GEN-LAST:event_jButton_GuardarActionPerformed

    private void jButton_BorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_BorrarActionPerformed
        try {
            java.sql.Connection HA = Conexion.conectar();
            PreparedStatement PHA = HA.prepareStatement("DELETE FROM Empleados WHERE UsuarioID = ?");
            PHA.setInt(1, IDEmpleados_update);
            int rowsDeleted = PHA.executeUpdate();
            HA.close();

            if (rowsDeleted > 0) {
                JOptionPane.showMessageDialog(null, "Registro eliminado correctamente.", "Exito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró ningún registro para eliminar", "Verifique", JOptionPane.ERROR);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar el registro", "Error", JOptionPane.ERROR_MESSAGE);
        }

        dispose();
        new gestionarEmpleados().setVisible(true);
    }//GEN-LAST:event_jButton_BorrarActionPerformed

    private void jButton_ActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_ActualizarActionPerformed
        usuario = jTextField_User.getText().trim();
        password = String.valueOf(jPassword_Password.getPassword()).trim();
        TipoUsuario = (String) jComboBox_Cargo.getSelectedItem();
        String Estado = (String) jComboBox_Estado.getSelectedItem();
        String Contacto = jTextField_Contacto.getText().trim();
        String NombreEmpleado = jTextField_Nombre.getText().trim();
        Date FechaNacimiento = jDateChooser_Nacimiento.getDate();
        // Declaración e inicialización de la variable de validación
        int validacion = 0;

        // Recopilación de datos de los campos de texto y elementos seleccionados
        // Verificación de campos obligatorios
        if (TipoUsuario.isEmpty() || Estado.isEmpty() || Contacto.isEmpty()
                || NombreEmpleado.isEmpty() || FechaNacimiento == null) {
            JOptionPane.showMessageDialog(null, "Por favor complete todos los campos obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        } else {
            try {
                //CreacionUsuarios.actualizarUsuario(usuario, password);
                // Actualización de la base de datos
                java.sql.Connection HA = Conexion.conectar();
                PreparedStatement PHA = HA.prepareStatement("UPDATE Empleados SET NombreEmpleado = ?, "
                        + "TipoUsuario = ?, Estado = ?, Contacto = ?, FechaNacimiento = ? "
                        + "WHERE UsuarioID = ?");
                PHA.setString(1, NombreEmpleado);
                PHA.setString(2, TipoUsuario);
                PHA.setString(3, Estado);
                PHA.setString(4, Contacto);

                // Verifica si la fecha de nacimiento no es nula antes de convertirla
                if (jDateChooser_Nacimiento.getDate() != null) {
                    java.sql.Date fechaNacimientoSQL = new java.sql.Date(jDateChooser_Nacimiento.getDate().getTime());
                    PHA.setDate(5, fechaNacimientoSQL);
                } else {
                    PHA.setNull(5, java.sql.Types.DATE); // Establece la fecha de nacimiento como NULL en la consulta
                }

                PHA.setInt(6, IDEmpleados_update); // Establece el valor de UsuarioID

                int rowsUpdated = PHA.executeUpdate();
                HA.close();

                // Limpiar campos y mostrar mensaje de éxito
                JOptionPane.showMessageDialog(null, "Modificación exitosa", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                new administrador().setVisible(true);
                dispose();
            } catch (SQLException e) {
                // Manejo de excepciones SQL
                System.err.println("Error al actualizar cliente" + e);
                JOptionPane.showMessageDialog(null, "Error al actualizar cliente", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        dispose();
        new gestionarEmpleados().setVisible(true);
    }//GEN-LAST:event_jButton_ActualizarActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(gestionarEmpleados.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(gestionarEmpleados.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(gestionarEmpleados.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(gestionarEmpleados.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new gestionarEmpleados().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Actualizar;
    private javax.swing.JButton jButton_Borrar;
    private javax.swing.JButton jButton_Guardar;
    private javax.swing.JButton jButton_Salir;
    private javax.swing.JComboBox<String> jComboBox_Cargo;
    private javax.swing.JComboBox<String> jComboBox_Estado;
    private com.toedter.calendar.JDateChooser jDateChooser_Nacimiento;
    private javax.swing.JLabel jLabel_Cargo;
    private javax.swing.JLabel jLabel_Contacto;
    private javax.swing.JLabel jLabel_Estado;
    private javax.swing.JLabel jLabel_Nacimiento;
    private javax.swing.JLabel jLabel_Nombre;
    private javax.swing.JLabel jLabel_Password;
    private javax.swing.JLabel jLabel_Titulo;
    private javax.swing.JLabel jLabel_User;
    private javax.swing.JLabel jLabel_Wallpaper;
    private javax.swing.JLabel jLabel_iconUser;
    private javax.swing.JLabel jLabel_logo;
    private javax.swing.JLabel jLabel_nameUser;
    private javax.swing.JLabel jLabel_numUser;
    private javax.swing.JPasswordField jPassword_Password;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Factura;
    private javax.swing.JTextField jTextField_Contacto;
    private javax.swing.JTextField jTextField_Nombre;
    private javax.swing.JTextField jTextField_User;
    // End of variables declaration//GEN-END:variables
}
