package ConexionBD;

import interfaces.ingreso;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    private static final String url = "jdbc:sqlserver://omnisysteam.database.windows.net:1433;database=sysales";
    private static final String user = ingreso.usuario;
    private static final String password = ingreso.password;
    public static Connection conexionBD = null;

    public static Connection conectar() {

        try {
            conexionBD = (Connection) DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            System.out.println("Error de conexion local" + e);
        }
        return conexionBD;
    }

    public static Connection cerrarConexion(Connection connection) {
        try {
            connection.close();
        } catch (SQLException e) {
            System.err.println("Error al cerrar la conexión: " + e.getMessage());
        }
        return null;
    }
}
