package ConexionBD;

import interfaces.Ingreso;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    private static final String url = "jdbc:sqlserver://sysales.database.windows.net:1433;database=sysales";
    public static Connection conexionBD = null;

    public static Connection conectar() {
        try {
            conexionBD = DriverManager.getConnection(url, Ingreso.usuario, Ingreso.password);
        } catch (SQLException e) {
            System.out.println("Error de conexion: " + e);
          
            return null;
        }
        return conexionBD;
    }

    public static void cerrarConexion(Connection connection) {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            System.err.println("Error al cerrar la conexión: " + e.getMessage());
        }
    }
}
