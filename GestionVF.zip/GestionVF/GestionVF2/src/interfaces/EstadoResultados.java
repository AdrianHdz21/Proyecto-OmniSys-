package interfaces;

import java.awt.Image;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import ConexionBD.Conexion;
import java.awt.Dimension;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

public class EstadoResultados extends javax.swing.JFrame {

    public EstadoResultados() {

        initComponents();
        setSize(600, 500);
        setResizable(false);
        setTitle("Estado de Resultados");
        setLocationRelativeTo(null);
        inicializarVentana();
    }

    private void inicializarVentana() {
        try {
            // Establecer conexión a la base de datos
            Connection con = Conexion.conectar();

            // Calcular ingresos y gastos
            double ingresos = calcularIngresos(con);
            double gastos = calcularGastos(con);

            // Calcular utilidad neta
            double utilidadNeta = ingresos - gastos;

            // Formatear los valores con 2 decimales
            String ingresosFormatted = String.format("%.2f", ingresos);
            String gastosFormatted = String.format("%.2f", gastos);
            String utilidadNetaFormatted = String.format("%.2f", utilidadNeta);

            // Mostrar estado de resultados en el JTextArea
            jTextField_Ingresos.setText(ingresosFormatted);
            jTextField_Gastos.setText("-"+gastosFormatted);
            jTextField_Utilidades.setText(utilidadNetaFormatted);
 
            // Crear el gráfico de pastel
            ChartPanel chartPanel = createChart(ingresos, gastos, utilidadNeta);

            // Establecer el tamaño del gráfico para una pantalla pequeña
            chartPanel.setPreferredSize(new Dimension(250, 250)); // Ajusta este tamaño según sea necesario

            // Agregar el gráfico al JPanel1_Grafica y establecer tamaño
            jPanel1_Grafica.setPreferredSize(new Dimension(250, 250));
            jPanel1_Grafica.add(chartPanel);
            jPanel1_Grafica.revalidate(); // Actualizar el JPanel después de agregar el chartPanel
             
            // Cerrar conexión
            Conexion.cerrarConexion(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("images/Icono.png"));
        return retValue;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel_Titulo = new javax.swing.JLabel();
        jLabel_logo = new javax.swing.JLabel();
        jButton_Salir = new javax.swing.JButton();
        jLabel_Indicaciones = new javax.swing.JLabel();
        jPanel1_Grafica = new javax.swing.JPanel();
        jTextField_Ingresos = new javax.swing.JTextField();
        jTextField_Gastos = new javax.swing.JTextField();
        jTextField_Utilidades = new javax.swing.JTextField();
        jLabel_Ingresos = new javax.swing.JLabel();
        jLabel_Gastos = new javax.swing.JLabel();
        jLabel_Utilidades = new javax.swing.JLabel();
        jLabel_Wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel_Titulo.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Titulo.setText("ESTADO DE RESULTADOS");
        getContentPane().add(jLabel_Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 80, 260, 20));

        jLabel_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Logo 2.png"))); // NOI18N
        getContentPane().add(jLabel_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(265, 10, 70, 70));

        jButton_Salir.setBackground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setForeground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerca 1.png"))); // NOI18N
        jButton_Salir.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Salir.setContentAreaFilled(false);
        jButton_Salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 20, 60, 60));

        jLabel_Indicaciones.setFont(new java.awt.Font("Times New Roman", 3, 10)); // NOI18N
        jLabel_Indicaciones.setForeground(new java.awt.Color(19, 36, 145));
        jLabel_Indicaciones.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Indicaciones.setText("INFORMACIÓN DE FACTURA: DETALLES DE LA TRANSACCIÓN");
        getContentPane().add(jLabel_Indicaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(145, 110, 310, 10));

        jPanel1_Grafica.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1_Grafica.setFont(new java.awt.Font("Tw Cen MT", 1, 10)); // NOI18N
        jPanel1_Grafica.setMaximumSize(new java.awt.Dimension(300, 300));
        getContentPane().add(jPanel1_Grafica, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 300, 270));

        jTextField_Ingresos.setEditable(false);
        jTextField_Ingresos.setBackground(new java.awt.Color(204, 204, 204));
        jTextField_Ingresos.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 14)); // NOI18N
        getContentPane().add(jTextField_Ingresos, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 220, 150, 25));
        jTextField_Ingresos.getAccessibleContext().setAccessibleName("");

        jTextField_Gastos.setEditable(false);
        jTextField_Gastos.setBackground(new java.awt.Color(204, 204, 204));
        jTextField_Gastos.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 14)); // NOI18N
        getContentPane().add(jTextField_Gastos, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 270, 150, 25));
        jTextField_Gastos.getAccessibleContext().setAccessibleName("");

        jTextField_Utilidades.setEditable(false);
        jTextField_Utilidades.setBackground(new java.awt.Color(204, 204, 204));
        jTextField_Utilidades.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 14)); // NOI18N
        getContentPane().add(jTextField_Utilidades, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 320, 150, 25));
        jTextField_Utilidades.getAccessibleContext().setAccessibleName("");

        jLabel_Ingresos.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 14)); // NOI18N
        jLabel_Ingresos.setText("Ingresos");
        getContentPane().add(jLabel_Ingresos, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 200, -1, -1));

        jLabel_Gastos.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 14)); // NOI18N
        jLabel_Gastos.setText("Gastos");
        getContentPane().add(jLabel_Gastos, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 250, -1, -1));

        jLabel_Utilidades.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 14)); // NOI18N
        jLabel_Utilidades.setText("Utilidades");
        getContentPane().add(jLabel_Utilidades, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 300, -1, -1));

        jLabel_Wallpaper.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Fondo2.png"))); // NOI18N
        getContentPane().add(jLabel_Wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SalirActionPerformed
        dispose();
        new Administrador().setVisible(true);
    }//GEN-LAST:event_jButton_SalirActionPerformed

    // Método para calcular los ingresos totales
    private double calcularIngresos(Connection con) throws SQLException {
        double ingresos = 0;
        String query = "SELECT SUM(Cantidad * PrecioVenta) AS TotalProductos FROM Ventas";
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        if (rs.next()) {
            ingresos = rs.getDouble("TotalProductos");
        }
        return ingresos;
    }

    // Método para calcular los gastos totales en salarios
    private double calcularGastos(Connection con) throws SQLException {
        double gastos = 0;

// Obtener gastos de la tabla Empleados
        String queryEmpleados = "SELECT SUM(Salario) AS TotalSalarios FROM Empleados";
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(queryEmpleados);
        if (rs.next()) {
            gastos += rs.getDouble("TotalSalarios");
        }

// Obtener gastos de la tabla Productos
        String queryProductos = "SELECT SUM(ExistenciaTotal * PrecioUnitario) AS TotalProductos FROM Productos";
        rs = stmt.executeQuery(queryProductos);
        if (rs.next()) {
            gastos += rs.getDouble("TotalProductos");
        }

// Cerrar ResultSet y Statement
        rs.close();
        stmt.close();

        return gastos;

    }

    private PieDataset createDataset(double ingresos, double gastos, double utilidadNeta) {
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("Ingresos", ingresos);
        dataset.setValue("Gastos", gastos);
        dataset.setValue("Utilidad Neta", utilidadNeta);
        return dataset;
    }

    private ChartPanel createChart(double ingresos, double gastos, double utilidadNeta) {
        // Crear el conjunto de datos para el gráfico de pastel
        PieDataset dataset = createDataset(ingresos, gastos, utilidadNeta);

        // Crear el gráfico de pastel
        JFreeChart chart = ChartFactory.createPieChart(
                "Estado de Resultados", // Título del gráfico
                dataset, // Conjunto de datos
                true, // Incluir leyenda
                true, // Herramientas
                false // URLs
        );

        // Crear un panel para mostrar el gráfico
        return new ChartPanel(chart);
    }

    private PieDataset createDataset(double ingresos, double gastos) {
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("Ingresos", ingresos);
        dataset.setValue("Gastos", gastos);
        return dataset;
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EstadoResultados.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EstadoResultados.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EstadoResultados.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EstadoResultados.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Salir;
    private javax.swing.JLabel jLabel_Gastos;
    private javax.swing.JLabel jLabel_Indicaciones;
    private javax.swing.JLabel jLabel_Ingresos;
    private javax.swing.JLabel jLabel_Titulo;
    private javax.swing.JLabel jLabel_Utilidades;
    private javax.swing.JLabel jLabel_Wallpaper;
    private javax.swing.JLabel jLabel_logo;
    private javax.swing.JPanel jPanel1_Grafica;
    private javax.swing.JTextField jTextField_Gastos;
    private javax.swing.JTextField jTextField_Ingresos;
    private javax.swing.JTextField jTextField_Utilidades;
    // End of variables declaration//GEN-END:variables
}
