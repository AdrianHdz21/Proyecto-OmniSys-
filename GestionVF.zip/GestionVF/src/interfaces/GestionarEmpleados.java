package interfaces;

import java.awt.Image;
import java.awt.Toolkit;
import ConexionBD.Conexion;
import java.sql.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class GestionarEmpleados extends javax.swing.JFrame {

    // Variables para almacenar información del usuario y empleado seleccionado
    public static String usuario;
    public static String password;
    public static String TipoUsuario;
    public static int IDEmpleados_update;

    // Modelo de tabla predeterminado para la tabla de empleados
    DefaultTableModel model = new DefaultTableModel();

    //Constructor de la clase
    public GestionarEmpleados() {
        initComponents(); // Inicializa componentes de la interfaz
        setSize(650, 520); // Establece tamaño de la ventana
        setResizable(false); // Hace que la ventana no sea redimensionable
        setTitle("Gestión Empleados"); // Establece el título de la ventana
        setLocationRelativeTo(null); // Centra la ventana en la pantalla

        // Configuración de botónes extra
        jButton_Actualizar.setEnabled(false);
        jButton_Borrar.setEnabled(false);

        // Llama al método para llenar la tabla y los campos
        cargarDatosTabla();
        jLabel_nameUser.setText("Nom Emp: " + Ingreso.nomEmpleado);
        jLabel_numUser.setText("Núm Emp: " + Ingreso.numEmpleado);
    }

// Método para obtener el icono de la aplicación
    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("images/Icono.png"));
        return retValue;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField_Nombre = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Factura = new javax.swing.JTable();
        jLabel_Nombre = new javax.swing.JLabel();
        jLabel_Cargo = new javax.swing.JLabel();
        jLabel_Estado = new javax.swing.JLabel();
        jButton_Actualizar = new javax.swing.JButton();
        jButton_Guardar = new javax.swing.JButton();
        jLabel_Titulo = new javax.swing.JLabel();
        jComboBox_Estado = new javax.swing.JComboBox<>();
        jComboBox_Cargo = new javax.swing.JComboBox<>();
        jTextField_User = new javax.swing.JTextField();
        jLabel_Password = new javax.swing.JLabel();
        jLabel_User = new javax.swing.JLabel();
        jPassword_Password = new javax.swing.JPasswordField();
        jLabel_Nacimiento = new javax.swing.JLabel();
        jTextField_Email = new javax.swing.JTextField();
        jLabel_Email = new javax.swing.JLabel();
        jDateChooser_Nacimiento = new com.toedter.calendar.JDateChooser();
        jButton_Borrar = new javax.swing.JButton();
        jLabel_iconUser = new javax.swing.JLabel();
        jLabel_logo = new javax.swing.JLabel();
        jButton_Salir = new javax.swing.JButton();
        jLabel_nameUser = new javax.swing.JLabel();
        jLabel_numUser = new javax.swing.JLabel();
        jLabel_Indicaciones = new javax.swing.JLabel();
        jLabel_Wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField_Nombre.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Nombre.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 10)); // NOI18N
        jTextField_Nombre.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Nombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Nombre.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Nombre.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, 260, 20));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jScrollPane1.setForeground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setFont(new java.awt.Font("Times New Roman", 1, 10)); // NOI18N

        jTable_Factura.setBackground(new java.awt.Color(255, 255, 255));
        jTable_Factura.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2)));
        jTable_Factura.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTable_Factura.setForeground(new java.awt.Color(0, 0, 0));
        jTable_Factura.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable_Factura.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jTable_Factura.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable_Factura);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 330, 600, 120));

        jLabel_Nombre.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Nombre.setText("Nombre Empleado");
        getContentPane().add(jLabel_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, -1, 20));

        jLabel_Cargo.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Cargo.setText("Cargo");
        getContentPane().add(jLabel_Cargo, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 150, -1, -1));

        jLabel_Estado.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Estado.setText("Estado");
        getContentPane().add(jLabel_Estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 150, -1, 20));

        jButton_Actualizar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Actualizar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Actualizar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Actualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/actualizar.png"))); // NOI18N
        jButton_Actualizar.setText("Actualizar");
        jButton_Actualizar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Actualizar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_ActualizarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 260, 105, 35));

        jButton_Guardar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Guardar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Guardar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/salvar (1).png"))); // NOI18N
        jButton_Guardar.setText("Cargar Datos");
        jButton_Guardar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Guardar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_GuardarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 260, 105, 35));

        jLabel_Titulo.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Titulo.setText("GESTION DE EMPLEADOS");
        getContentPane().add(jLabel_Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 90, 250, 25));

        jComboBox_Estado.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_Estado.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 10)); // NOI18N
        jComboBox_Estado.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_Estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Inactivo" }));
        jComboBox_Estado.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jComboBox_Estado.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(jComboBox_Estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 170, 100, 20));

        jComboBox_Cargo.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_Cargo.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 10)); // NOI18N
        jComboBox_Cargo.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_Cargo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Gerente", "Empleado" }));
        jComboBox_Cargo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jComboBox_Cargo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(jComboBox_Cargo, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 170, 100, 20));

        jTextField_User.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_User.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 10)); // NOI18N
        jTextField_User.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_User.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_User.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_User.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_User, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 220, 110, 25));

        jLabel_Password.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Password.setText("Password");
        getContentPane().add(jLabel_Password, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 200, 50, -1));

        jLabel_User.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_User.setText("Usuario");
        getContentPane().add(jLabel_User, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 200, 60, -1));

        jPassword_Password.setBackground(new java.awt.Color(255, 255, 255));
        jPassword_Password.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 10)); // NOI18N
        jPassword_Password.setForeground(new java.awt.Color(0, 0, 0));
        jPassword_Password.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPassword_Password.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black));
        getContentPane().add(jPassword_Password, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 220, 100, 25));

        jLabel_Nacimiento.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Nacimiento.setText("Fecha de Nacimiento");
        getContentPane().add(jLabel_Nacimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 200, 100, -1));

        jTextField_Email.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Email.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 10)); // NOI18N
        jTextField_Email.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Email.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Email.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Email.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jTextField_Email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_EmailActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField_Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 220, 120, 25));

        jLabel_Email.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Email.setText("Email");
        getContentPane().add(jLabel_Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, 50, -1));

        jDateChooser_Nacimiento.setBackground(new java.awt.Color(255, 255, 255));
        jDateChooser_Nacimiento.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black));
        jDateChooser_Nacimiento.setForeground(new java.awt.Color(0, 0, 0));
        jDateChooser_Nacimiento.setDateFormatString("d/MMM/y");
        jDateChooser_Nacimiento.setDebugGraphicsOptions(javax.swing.DebugGraphics.LOG_OPTION);
        jDateChooser_Nacimiento.setFocusCycleRoot(true);
        jDateChooser_Nacimiento.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        getContentPane().add(jDateChooser_Nacimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 220, 130, 25));

        jButton_Borrar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Borrar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Borrar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Borrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/borrar.png"))); // NOI18N
        jButton_Borrar.setText("Eliminar");
        jButton_Borrar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Borrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_BorrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Borrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 260, 105, 35));

        jLabel_iconUser.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_iconUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/usuario 2.png"))); // NOI18N
        getContentPane().add(jLabel_iconUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 60, 60));

        jLabel_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Logo 2.png"))); // NOI18N
        getContentPane().add(jLabel_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 20, 70, 70));

        jButton_Salir.setBackground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setForeground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerca 1.png"))); // NOI18N
        jButton_Salir.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Salir.setContentAreaFilled(false);
        jButton_Salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 20, 60, 60));

        jLabel_nameUser.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel_nameUser.setForeground(new java.awt.Color(19, 36, 145));
        getContentPane().add(jLabel_nameUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 30, 150, 20));

        jLabel_numUser.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel_numUser.setForeground(new java.awt.Color(19, 36, 145));
        getContentPane().add(jLabel_numUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 50, 150, 20));

        jLabel_Indicaciones.setFont(new java.awt.Font("Times New Roman", 3, 10)); // NOI18N
        jLabel_Indicaciones.setForeground(new java.awt.Color(19, 36, 145));
        jLabel_Indicaciones.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Indicaciones.setText("PARA REGISTRAR O MODIFICAR ALGÚN EMPLEADO, COMPLETE LOS CAMPOS REQUERIDOS.");
        getContentPane().add(jLabel_Indicaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 130, 530, 10));

        jLabel_Wallpaper.setBackground(new java.awt.Color(255, 255, 255));
        jLabel_Wallpaper.setForeground(new java.awt.Color(0, 0, 0));
        jLabel_Wallpaper.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Fondo2.png"))); // NOI18N
        jLabel_Wallpaper.setLabelFor(jLabel_Wallpaper);
        getContentPane().add(jLabel_Wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 520));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Método para llenar la tabla y los campos correspondientes
    private void cargarDatosTabla() {
        try {
            java.sql.Connection HA = Conexion.conectar();
            PreparedStatement PHA = HA.prepareStatement("select * from Empleados");
            ResultSet HA1 = PHA.executeQuery();

            // Configura el modelo de la tabla
            DefaultTableModel model = new DefaultTableModel() {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false; // Hace que todas las celdas de la tabla no sean editables
                }
            };
            // Llena la tabla con los datos obtenidos de la base de datos
            model.addColumn("UsuarioID ");
            model.addColumn("Nombre");
            model.addColumn("Usuario");
            model.addColumn("Contraseña");
            model.addColumn("Cargo");
            model.addColumn("Estado");
            model.addColumn("Email");
            model.addColumn("Nacimiento");

            while (HA1.next()) {
                Object[] fila = new Object[8];
                for (int i = 0; i < 8; i++) {
                    fila[i] = HA1.getObject(i + 1);
                }
                model.addRow(fila);
            }

            // Establece el modelo en la tabla
            jTable_Factura = new JTable(model); // Aquí se crea la tabla con el modelo configurado
            jTable_Factura
                    .setDefaultEditor(Object.class,
                            null); // Hace que la tabla no sea editable
            jScrollPane1.setViewportView(jTable_Factura);

            //Añade un evento para cuando se hace clic en algún registro de la tabla
            jTable_Factura.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int fila_point = jTable_Factura.rowAtPoint(e.getPoint());
                    int columna_point = 0;
                    if (fila_point > -1) {
                        jButton_Actualizar.setEnabled(true); // Habilita el botón de actualizar
                        jButton_Borrar.setEnabled(true);// Habilita el botón de aborrar
                        jButton_Guardar.setEnabled(false); // Deshabilita el botón de guardar
                        //Recibe el UsuarioID de acuerdo al registro seleccionado en la tabla
                        IDEmpleados_update = (int) model.getValueAt(fila_point, columna_point);
                        java.sql.Connection HA = Conexion.conectar();
                        PreparedStatement PHA;

                        //Realiza una consulta para recuperar los datos de acuerdo al ID y los coloca en el campo correspondiente
                        try {
                            PHA = HA.prepareStatement("select * from Empleados where UsuarioID = '" + IDEmpleados_update + "'");
                            ResultSet HA1 = PHA.executeQuery();
                            if (HA1.next()) {
                                jTextField_Nombre.setText(HA1.getString("NombreEmpleado"));
                                jTextField_Email.setText(HA1.getString("Email"));
                                jTextField_User.setText(HA1.getString("NombreUsuario"));
                                jPassword_Password.setText(HA1.getString("Contrasena"));
                                jDateChooser_Nacimiento.setDate(HA1.getDate("FechaNacimiento"));
                                //Para los combobox se recibe la informacion y en base a esa se revisa que exista en las opciones
                                String valorEstado = HA1.getString("Estado");
                                for (int i = 0; i < jComboBox_Estado.getItemCount(); i++) {
                                    if (jComboBox_Estado.getItemAt(i).equals(valorEstado)) {
                                        jComboBox_Estado.setSelectedIndex(i);
                                        break;
                                    }
                                }
                                String valorTipo = HA1.getString("TipoUsuario");
                                for (int i = 0; i < jComboBox_Cargo.getItemCount(); i++) {
                                    if (jComboBox_Cargo.getItemAt(i).equals(valorTipo)) {
                                        jComboBox_Cargo.setSelectedIndex(i);
                                        break;
                                    }
                                }

                            }
                            // Si se produce una excepción SQLException, se captura y se maneja aquí
                        } catch (SQLException ex) {
                            System.err.println("Error al cargar usuario" + e);
                            JOptionPane.showMessageDialog(null, "Error al cargar contactar administrador");
                        }
                    }
                }
            });
        } catch (SQLException ex) {
            Logger.getLogger(GestionarEmpleados.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void enviarCorreoVerificacionMailjet(String destinatario) {
        // Credenciales de API de Mailjet
        final String mailjetPublicKey = "3a9c6d844860276e8a4fe56dd398d1a7";
        final String mailjetPrivateKey = "609856274a7b80e230319db14f782073";

        Properties props = new Properties();
        props.put("mail.smtp.host", "in-v3.mailjet.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(mailjetPublicKey, mailjetPrivateKey);
            }
        });

        try {
            // Creación del mensaje
            Message mensajeCorreo = new MimeMessage(session);
            mensajeCorreo.setFrom(new InternetAddress("onmisysteam@outlook.es")); // Remitente del correo
            mensajeCorreo.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            mensajeCorreo.setSubject("Registro Realizado Correctamente");
            mensajeCorreo.setText("Se ha realizado correctamente su registro para acceder al sistema, por parte del usuario: " + Ingreso.nomEmpleado
                    + "\n\nUsuario es: " + usuario + "\nContraseña: " + password);

            // Envío del mensaje
            Transport.send(mensajeCorreo);

        } catch (MessagingException e) {
            JOptionPane.showMessageDialog(null, "Error al enviar el correo electrónico: " + e.getMessage());
            e.printStackTrace();
        }
    }

    //Metodo del boton guardar
    private void jButton_GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_GuardarActionPerformed
        usuario = jTextField_User.getText().trim();
        password = String.valueOf(jPassword_Password.getPassword()).trim();
        TipoUsuario = (String) jComboBox_Cargo.getSelectedItem();
        String Estado = (String) jComboBox_Estado.getSelectedItem();
        String Email = jTextField_Email.getText().trim();
        String NombreEmpleado = jTextField_Nombre.getText().trim();
        Date FechaNacimiento = jDateChooser_Nacimiento.getDate();

        // Validación para asegurarse de que no haya campos vacíos
        if (TipoUsuario.isEmpty() || Estado.isEmpty() || Email.isEmpty()
                || NombreEmpleado.isEmpty() || usuario.isEmpty() || password.isEmpty() || FechaNacimiento == null) {
            JOptionPane.showMessageDialog(null, "Por favor complete todos los campos obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (password.length() >= 8) {
        } else {
            JOptionPane.showMessageDialog(null, "La contraseña debe tener al menos 8 caracteres","Error", JOptionPane.ERROR_MESSAGE);  
            return;
        }

        try {
            // Establecer conexión con la base de datos "sysales"
            String salesConnectionString = "jdbc:sqlserver://sysales.database.windows.net:1433;database=sysales";
            try ( java.sql.Connection salesConnection = DriverManager.getConnection(salesConnectionString, "administrador", "systeam@123")) {
                // Prepara la consulta SQL para insertar un nuevo empleado en la base de datos
                String insertQuery = "INSERT INTO Empleados (NombreEmpleado, NombreUsuario, Contrasena,"
                        + " TipoUsuario, Estado, Email, FechaNacimiento) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?)";
                try ( PreparedStatement preparedStatement = salesConnection.prepareStatement(insertQuery)) {
                    // Establece los valores de los parámetros en la consulta preparada
                    preparedStatement.setString(1, NombreEmpleado);
                    preparedStatement.setString(2, usuario);
                    preparedStatement.setString(3, password);
                    preparedStatement.setString(4, TipoUsuario);
                    preparedStatement.setString(5, Estado);
                    preparedStatement.setString(6, Email);
                    preparedStatement.setDate(7, new java.sql.Date(FechaNacimiento.getTime()));

                    // Ejecuta la consulta SQL para insertar los datos del nuevo empleado en la base de datos
                    int rowsInserted = preparedStatement.executeUpdate();
                    if (rowsInserted > 0) {
                        dispose();
                        JOptionPane.showMessageDialog(null, "Empleado registrado correctamente.", "Exito", JOptionPane.INFORMATION_MESSAGE);
                        new GestionarEmpleados().setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al registrar empleado.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        } catch (SQLException e) {
            // Captura y maneja cualquier excepción SQLException que pueda ocurrir durante la ejecución de la consulta SQL
            JOptionPane.showMessageDialog(null, "Error al ejecutar la consulta SQL: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);

        }

        try {
            // Establecer conexión con la base de datos "master" y "sysales"
            String masterConnectionString = "jdbc:sqlserver://sysales.database.windows.net:1433;database=master";
            String salesConnectionString = "jdbc:sqlserver://sysales.database.windows.net:1433;database=sysales";

            try ( java.sql.Connection masterConnection = DriverManager.getConnection(masterConnectionString, "administrador", "systeam@123");  java.sql.Connection salesConnection = DriverManager.getConnection(salesConnectionString, "administrador", "systeam@123")) {

                // Ejecutar las consultas SQL en la base de datos "master"
                Statement masterStatement = masterConnection.createStatement();
                Statement salesStatement = salesConnection.createStatement();

                if (TipoUsuario.equals("Empleado") || TipoUsuario.equals("Gerente")) {
                    String loginCreationQuery = "CREATE LOGIN " + usuario + " WITH PASSWORD='" + password + "'";
                    String userCreationQuery = "CREATE USER " + usuario + " FOR LOGIN " + usuario;

                    masterStatement.executeUpdate(loginCreationQuery);
                    masterStatement.executeUpdate(userCreationQuery);
                }

                // Ejecutar la consulta SQL en la base de datos "sysales" para crear el usuario
                String userCreationQuery = "CREATE USER " + usuario;
                salesStatement.executeUpdate(userCreationQuery);

                if (TipoUsuario.equals("Empleado")) {
                    salesStatement.executeUpdate("EXEC sp_addrolemember 'db_datawriter', '" + usuario + "'");
                    salesStatement.executeUpdate("EXEC sp_addrolemember 'db_datareader', '" + usuario + "'");
                    salesStatement.executeUpdate("GRANT SELECT, INSERT ON Productos TO " + usuario + " WITH GRANT OPTION");
                } else if (TipoUsuario.equals("Gerente")) {
                    salesStatement.executeUpdate("EXEC sp_addrolemember 'db_datawriter', '" + usuario + "'");
                    salesStatement.executeUpdate("EXEC sp_addrolemember 'db_datareader', '" + usuario + "'");
                    salesStatement.executeUpdate("GRANT SELECT, INSERT, DELETE ON Productos, Empleados, Proveedores, Ventas TO " + usuario + " WITH GRANT OPTION");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al ejecutar las consultas SQL: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jButton_GuardarActionPerformed

    private void jButton_BorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_BorrarActionPerformed
        String user = jTextField_User.getText().trim();
        try {
            // Establecer conexión con la base de datos "master"
            String masterConnectionString = "jdbc:sqlserver://sysales.database.windows.net:1433;database=master";

            try ( java.sql.Connection masterConnection = DriverManager.getConnection(masterConnectionString, "administrador", "systeam@123")) {

                // Ejecutar la consulta SQL para eliminar el usuario en la base de datos "sysales"
                PreparedStatement deleteUserStatement = masterConnection.prepareStatement("DROP USER " + user);
                deleteUserStatement.executeUpdate();

                // Ejecutar la consulta SQL para eliminar el login en la base de datos "master"
                PreparedStatement deleteLoginStatement = masterConnection.prepareStatement("DROP LOGIN " + user);
                deleteLoginStatement.executeUpdate();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar el usuario y login: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Código para eliminar el usuario en la base de datos "sysales"
        try {
            String salesConnectionString = "jdbc:sqlserver://sysales.database.windows.net:1433;database=sysales";
            try ( java.sql.Connection salesConnection = DriverManager.getConnection(salesConnectionString, "administrador", "systeam@123")) {
                // Ejecutar la consulta SQL para eliminar el usuario en la base de datos "sysales"
                PreparedStatement deleteUserStatement = salesConnection.prepareStatement("DROP USER " + user);
                deleteUserStatement.executeUpdate();

            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar el usuario: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

// Código para eliminar el registro de la tabla
        try {
            java.sql.Connection HA = Conexion.conectar();
            PreparedStatement PHA = HA.prepareStatement("DELETE FROM Empleados WHERE UsuarioID = ?");
            PHA.setInt(1, IDEmpleados_update);
            int rowsDeleted = PHA.executeUpdate();
            HA.close();

            if (rowsDeleted > 0) {
                dispose();
                JOptionPane.showMessageDialog(null, "Usuario eliminado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                new GestionarEmpleados().setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "No se encontró ningún registro para eliminar", "Verifique", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar el registro", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton_BorrarActionPerformed

    private void jButton_ActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_ActualizarActionPerformed
        usuario = jTextField_User.getText().trim();
        password = String.valueOf(jPassword_Password.getPassword()).trim();
        TipoUsuario = (String) jComboBox_Cargo.getSelectedItem();
        String Estado = (String) jComboBox_Estado.getSelectedItem();
        String Email = jTextField_Email.getText().trim();
        String NombreEmpleado = jTextField_Nombre.getText().trim();
        Date FechaNacimiento = jDateChooser_Nacimiento.getDate();

        // Recopilación de datos de los campos de texto y elementos seleccionados
        // Verificación de campos obligatorios
        if (TipoUsuario.isEmpty() || Estado.isEmpty() || Email.isEmpty() || usuario.isEmpty() || password.isEmpty()
                || NombreEmpleado.isEmpty() || FechaNacimiento == null) {
            JOptionPane.showMessageDialog(null, "Por favor complete todos los campos obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        } else {
            try {
                // Actualización de la base de datos
                java.sql.Connection HA = Conexion.conectar();
                PreparedStatement PHA = HA.prepareStatement("UPDATE Empleados SET NombreEmpleado = ?, "
                        + "TipoUsuario = ?, NombreUsuario = ?, Contrasena = ?, Estado = ?, Email = ?, FechaNacimiento = ? "
                        + "WHERE UsuarioID = ?");
                PHA.setString(1, NombreEmpleado);
                PHA.setString(2, TipoUsuario);
                PHA.setString(3, usuario); // Se actualiza el nombre de usuario
                PHA.setString(4, password); // Se actualiza la contraseña
                PHA.setString(5, Estado);
                PHA.setString(6, Email);

                // Verifica si la fecha de nacimiento no es nula antes de convertirla
                if (FechaNacimiento != null) {
                    java.sql.Date fechaNacimientoSQL = new java.sql.Date(FechaNacimiento.getTime());
                    PHA.setDate(7, fechaNacimientoSQL);
                } else {
                    PHA.setNull(7, java.sql.Types.DATE); // Establece la fecha de nacimiento como NULL en la consulta
                }

                PHA.setInt(8, IDEmpleados_update); // Establece el valor de UsuarioID

                int rowsUpdated = PHA.executeUpdate();
                HA.close();

                // Limpiar campos y mostrar mensaje de éxito
                dispose();
                JOptionPane.showMessageDialog(null, "Modificación exitosa", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                new GestionarEmpleados().setVisible(true);
            } catch (SQLException e) {
                // Manejo de excepciones SQL
                System.err.println("Error al actualizar cliente" + e);
                JOptionPane.showMessageDialog(null, "Error al actualizar cliente", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }


    }//GEN-LAST:event_jButton_ActualizarActionPerformed

    private void jButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SalirActionPerformed
        dispose();
        new Administrador().setVisible(true);
    }//GEN-LAST:event_jButton_SalirActionPerformed

    private void jTextField_EmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_EmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_EmailActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GestionarEmpleados.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GestionarEmpleados.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GestionarEmpleados.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GestionarEmpleados.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GestionarEmpleados().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Actualizar;
    private javax.swing.JButton jButton_Borrar;
    private javax.swing.JButton jButton_Guardar;
    private javax.swing.JButton jButton_Salir;
    private javax.swing.JComboBox<String> jComboBox_Cargo;
    private javax.swing.JComboBox<String> jComboBox_Estado;
    private com.toedter.calendar.JDateChooser jDateChooser_Nacimiento;
    private javax.swing.JLabel jLabel_Cargo;
    private javax.swing.JLabel jLabel_Email;
    private javax.swing.JLabel jLabel_Estado;
    private javax.swing.JLabel jLabel_Indicaciones;
    private javax.swing.JLabel jLabel_Nacimiento;
    private javax.swing.JLabel jLabel_Nombre;
    private javax.swing.JLabel jLabel_Password;
    private javax.swing.JLabel jLabel_Titulo;
    private javax.swing.JLabel jLabel_User;
    private javax.swing.JLabel jLabel_Wallpaper;
    private javax.swing.JLabel jLabel_iconUser;
    private javax.swing.JLabel jLabel_logo;
    private javax.swing.JLabel jLabel_nameUser;
    private javax.swing.JLabel jLabel_numUser;
    private javax.swing.JPasswordField jPassword_Password;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Factura;
    private javax.swing.JTextField jTextField_Email;
    private javax.swing.JTextField jTextField_Nombre;
    private javax.swing.JTextField jTextField_User;
    // End of variables declaration//GEN-END:variables
}
