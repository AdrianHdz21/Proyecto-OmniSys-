package interfaces;

import java.awt.Image;
import java.awt.Toolkit;
import ConexionBD.Conexion;
import java.sql.*;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;

public class RegistroNuevosUsuarios extends javax.swing.JFrame {

    // Variables para almacenar información del usuario y empleado seleccionado
    public static String usuario;
    public static String password;
    public static String TipoUsuario;
    public static int IDEmpleados_update;

    //Constructor de la clase
    public RegistroNuevosUsuarios() {
        initComponents(); // Inicializa componentes de la interfaz
        setSize(470, 370); // Establece tamaño de la ventana
        setResizable(false); // Hace que la ventana no sea redimensionable
        setTitle("Regitro Nuevo Usuario"); // Establece el título de la ventana
        setLocationRelativeTo(null); // Centra la ventana en la pantalla
    }

// Método para obtener el icono de la aplicación
    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("images/Icono.png"));
        return retValue;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField_Nombre = new javax.swing.JTextField();
        jLabel_Nombre = new javax.swing.JLabel();
        jLabel_Cargo = new javax.swing.JLabel();
        jLabel_Estado = new javax.swing.JLabel();
        jButton_Guardar = new javax.swing.JButton();
        jLabel_Titulo = new javax.swing.JLabel();
        jComboBox_Estado = new javax.swing.JComboBox<>();
        jComboBox_Cargo = new javax.swing.JComboBox<>();
        jTextField_User = new javax.swing.JTextField();
        jLabel_Password = new javax.swing.JLabel();
        jLabel_User = new javax.swing.JLabel();
        jPassword_Password = new javax.swing.JPasswordField();
        jLabel_Nacimiento = new javax.swing.JLabel();
        jTextField_Email = new javax.swing.JTextField();
        jLabel_Email = new javax.swing.JLabel();
        jDateChooser_Nacimiento = new com.toedter.calendar.JDateChooser();
        jLabel_logo = new javax.swing.JLabel();
        jButton_Salir = new javax.swing.JButton();
        jLabel_Indicaciones = new javax.swing.JLabel();
        jLabel_Wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField_Nombre.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Nombre.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_Nombre.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Nombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Nombre.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Nombre.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, 240, 20));

        jLabel_Nombre.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Nombre.setText("Nombre Empleado");
        getContentPane().add(jLabel_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, -1, 20));

        jLabel_Cargo.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Cargo.setText("Cargo");
        getContentPane().add(jLabel_Cargo, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 200, -1, -1));

        jLabel_Estado.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Estado.setText("Estado");
        getContentPane().add(jLabel_Estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 150, -1, 20));

        jButton_Guardar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Guardar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Guardar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/registro.png"))); // NOI18N
        jButton_Guardar.setText("REGISTRARSE");
        jButton_Guardar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Guardar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_GuardarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 270, 105, 35));

        jLabel_Titulo.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Titulo.setText("REGISTRO DE USUARIOS");
        getContentPane().add(jLabel_Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 80, 250, 25));

        jComboBox_Estado.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_Estado.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 10)); // NOI18N
        jComboBox_Estado.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_Estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Activo", "Inactivo" }));
        jComboBox_Estado.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jComboBox_Estado.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(jComboBox_Estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 170, 120, 20));

        jComboBox_Cargo.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_Cargo.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 10)); // NOI18N
        jComboBox_Cargo.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_Cargo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Gerente", "Empleado" }));
        jComboBox_Cargo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jComboBox_Cargo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(jComboBox_Cargo, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 220, 100, 20));

        jTextField_User.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_User.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_User.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_User.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_User.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_User.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_User, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 280, 120, 25));

        jLabel_Password.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Password.setText("Password");
        getContentPane().add(jLabel_Password, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 260, 50, -1));

        jLabel_User.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_User.setText("Usuario");
        getContentPane().add(jLabel_User, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 260, 60, -1));

        jPassword_Password.setBackground(new java.awt.Color(255, 255, 255));
        jPassword_Password.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jPassword_Password.setForeground(new java.awt.Color(0, 0, 0));
        jPassword_Password.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPassword_Password.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black));
        getContentPane().add(jPassword_Password, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 280, 100, 25));

        jLabel_Nacimiento.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Nacimiento.setText("Fecha de Nacimiento");
        getContentPane().add(jLabel_Nacimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 200, 100, -1));

        jTextField_Email.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Email.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_Email.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Email.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Email.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Email.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jTextField_Email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_EmailActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField_Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 220, 120, 25));

        jLabel_Email.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Email.setText("Email");
        getContentPane().add(jLabel_Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, 50, -1));

        jDateChooser_Nacimiento.setBackground(new java.awt.Color(255, 255, 255));
        jDateChooser_Nacimiento.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black));
        jDateChooser_Nacimiento.setForeground(new java.awt.Color(0, 0, 0));
        jDateChooser_Nacimiento.setDateFormatString("d/MMM/y");
        jDateChooser_Nacimiento.setDebugGraphicsOptions(javax.swing.DebugGraphics.LOG_OPTION);
        jDateChooser_Nacimiento.setFocusCycleRoot(true);
        jDateChooser_Nacimiento.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jDateChooser_Nacimiento.setMaxSelectableDate(new java.util.Date(253370790073000L));
        getContentPane().add(jDateChooser_Nacimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 220, 120, 25));

        jLabel_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Logo 2.png"))); // NOI18N
        getContentPane().add(jLabel_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 10, 70, 70));

        jButton_Salir.setBackground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setForeground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerca 1.png"))); // NOI18N
        jButton_Salir.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Salir.setContentAreaFilled(false);
        jButton_Salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 10, 60, 60));

        jLabel_Indicaciones.setFont(new java.awt.Font("Times New Roman", 3, 10)); // NOI18N
        jLabel_Indicaciones.setForeground(new java.awt.Color(19, 36, 145));
        jLabel_Indicaciones.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Indicaciones.setText("PARA REGISTRARSE, COMPLETE LOS CAMPOS REQUERIDOS.");
        getContentPane().add(jLabel_Indicaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 120, 350, 10));

        jLabel_Wallpaper.setBackground(new java.awt.Color(255, 255, 255));
        jLabel_Wallpaper.setForeground(new java.awt.Color(0, 0, 0));
        jLabel_Wallpaper.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Fondo2.png"))); // NOI18N
        jLabel_Wallpaper.setLabelFor(jLabel_Wallpaper);
        getContentPane().add(jLabel_Wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 470, 370));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void enviarCorreoVerificacionMailjet(String destinatario) {
        // Credenciales de API de Mailjet
        final String mailjetPublicKey = "3a9c6d844860276e8a4fe56dd398d1a7";
        final String mailjetPrivateKey = "609856274a7b80e230319db14f782073";

        Properties props = new Properties();
        props.put("mail.smtp.host", "in-v3.mailjet.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(mailjetPublicKey, mailjetPrivateKey);
            }
        });

        try {
            // Creación del mensaje
            Message mensajeCorreo = new MimeMessage(session);
            mensajeCorreo.setFrom(new InternetAddress("onmisysteam@outlook.es")); // Remitente del correo
            mensajeCorreo.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            mensajeCorreo.setSubject("Registro Realizado Correctamente");
            mensajeCorreo.setText("Su usuario es: " + usuario + " \n Contraseña: " + password);

            // Envío del mensaje
            Transport.send(mensajeCorreo);

        } catch (MessagingException e) {
            JOptionPane.showMessageDialog(null, "Error al enviar el correo electrónico: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void jButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SalirActionPerformed
        dispose();
    }//GEN-LAST:event_jButton_SalirActionPerformed

    // Método para registrar un nuevo usuario
    private void jButton_GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_GuardarActionPerformed
        usuario = jTextField_User.getText().trim();
        password = String.valueOf(jPassword_Password.getPassword()).trim();
        TipoUsuario = (String) jComboBox_Cargo.getSelectedItem();
        String Estado = (String) jComboBox_Estado.getSelectedItem();
        String Email = jTextField_Email.getText().trim();
        String NombreEmpleado = jTextField_Nombre.getText().trim();
        Date FechaNacimiento = jDateChooser_Nacimiento.getDate();

        // Validación para asegurarse de que no haya campos vacíos
        if (TipoUsuario.isEmpty() || Estado.isEmpty() || Email.isEmpty()
                || NombreEmpleado.isEmpty() || usuario.isEmpty() || password.isEmpty() || FechaNacimiento == null) {
            JOptionPane.showMessageDialog(null, "Por favor complete todos los campos obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Establecer conexión con la base de datos "sysales"
            String salesConnectionString = "jdbc:sqlserver://sysales.database.windows.net:1433;database=sysales";
            try ( java.sql.Connection salesConnection = DriverManager.getConnection(salesConnectionString, "administrador", "systeam@123")) {
                // Prepara la consulta SQL para insertar un nuevo empleado en la base de datos

                String insertQuery = "INSERT INTO Empleados (NombreEmpleado, NombreUsuario, Contrasena,"
                        + " TipoUsuario, Estado, Email, FechaNacimiento) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?)";
                try ( PreparedStatement preparedStatement = salesConnection.prepareStatement(insertQuery)) {
                    // Establece los valores de los parámetros en la consulta preparada
                    preparedStatement.setString(1, NombreEmpleado);
                    preparedStatement.setString(2, usuario);
                    preparedStatement.setString(3, password);
                    preparedStatement.setString(4, TipoUsuario);
                    preparedStatement.setString(5, Estado);
                    preparedStatement.setString(6, Email);
                    preparedStatement.setDate(7, new java.sql.Date(FechaNacimiento.getTime()));

                    // Ejecuta la consulta SQL para insertar los datos del nuevo empleado en la base de datos
                    int rowsInserted = preparedStatement.executeUpdate();
                    if (rowsInserted > 0) {
                        JOptionPane.showMessageDialog(null, "Empleado registrado correctamente.", "Exito", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Error al registrar empleado.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        } catch (SQLException e) {
            // Captura y maneja cualquier excepción SQLException que pueda ocurrir durante la ejecución de la consulta SQL
            JOptionPane.showMessageDialog(null, "Error al ejecutar la consulta SQL: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        try {
            // Establecer conexión con la base de datos "master" y "sysales"
            String masterConnectionString = "jdbc:sqlserver://sysales.database.windows.net:1433;database=master";
            String salesConnectionString = "jdbc:sqlserver://sysales.database.windows.net:1433;database=sysales";

            try ( java.sql.Connection masterConnection = DriverManager.getConnection(masterConnectionString, "administrador", "systeam@123");  java.sql.Connection salesConnection = DriverManager.getConnection(salesConnectionString, "administrador", "systeam@123")) {

                // Ejecutar las consultas SQL en la base de datos "master"
                Statement masterStatement = masterConnection.createStatement();
                Statement salesStatement = salesConnection.createStatement();

                if (TipoUsuario.equals("Empleado") || TipoUsuario.equals("Gerente")) {
                    String loginCreationQuery = "CREATE LOGIN " + usuario + " WITH PASSWORD='" + password + "'";
                    String userCreationQuery = "CREATE USER " + usuario + " FOR LOGIN " + usuario;

                    masterStatement.executeUpdate(loginCreationQuery);
                    masterStatement.executeUpdate(userCreationQuery);
                }

                // Ejecutar la consulta SQL en la base de datos "sysales" para crear el usuario
                String userCreationQuery = "CREATE USER " + usuario;
                salesStatement.executeUpdate(userCreationQuery);

                if (TipoUsuario.equals("Empleado")) {
                    salesStatement.executeUpdate("EXEC sp_addrolemember 'db_datawriter', '" + usuario + "'");
                    salesStatement.executeUpdate("EXEC sp_addrolemember 'db_datareader', '" + usuario + "'");
                    salesStatement.executeUpdate("GRANT SELECT, INSERT ON Productos TO " + usuario + " WITH GRANT OPTION");
                } else if (TipoUsuario.equals("Gerente")) {
                    salesStatement.executeUpdate("EXEC sp_addrolemember 'db_datawriter', '" + usuario + "'");
                    salesStatement.executeUpdate("EXEC sp_addrolemember 'db_datareader', '" + usuario + "'");
                    salesStatement.executeUpdate("GRANT SELECT, INSERT, DELETE ON Productos, Empleados, Proveedores, Ventas TO " + usuario + " WITH GRANT OPTION");
                }
            }
        } catch (SQLException e) {
        }

        enviarCorreoVerificacionMailjet(Email);
        dispose();

    }//GEN-LAST:event_jButton_GuardarActionPerformed

    private void jTextField_EmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_EmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_EmailActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroNuevosUsuarios.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroNuevosUsuarios.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroNuevosUsuarios.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroNuevosUsuarios.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroNuevosUsuarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Guardar;
    private javax.swing.JButton jButton_Salir;
    private javax.swing.JComboBox<String> jComboBox_Cargo;
    private javax.swing.JComboBox<String> jComboBox_Estado;
    private com.toedter.calendar.JDateChooser jDateChooser_Nacimiento;
    private javax.swing.JLabel jLabel_Cargo;
    private javax.swing.JLabel jLabel_Email;
    private javax.swing.JLabel jLabel_Estado;
    private javax.swing.JLabel jLabel_Indicaciones;
    private javax.swing.JLabel jLabel_Nacimiento;
    private javax.swing.JLabel jLabel_Nombre;
    private javax.swing.JLabel jLabel_Password;
    private javax.swing.JLabel jLabel_Titulo;
    private javax.swing.JLabel jLabel_User;
    private javax.swing.JLabel jLabel_Wallpaper;
    private javax.swing.JLabel jLabel_logo;
    private javax.swing.JPasswordField jPassword_Password;
    private javax.swing.JTextField jTextField_Email;
    private javax.swing.JTextField jTextField_Nombre;
    private javax.swing.JTextField jTextField_User;
    // End of variables declaration//GEN-END:variables
}
