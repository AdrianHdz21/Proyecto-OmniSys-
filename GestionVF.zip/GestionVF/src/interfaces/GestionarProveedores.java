package interfaces;

import ConexionBD.Conexion;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.Statement;

public class GestionarProveedores extends javax.swing.JFrame {

    public static int IDProveedor_update;

    public GestionarProveedores() {
        initComponents();
        setSize(600, 500);
        setResizable(false);
        setTitle("Gestión de Proveedores");
        setLocationRelativeTo(null);

        jLabel_nameUser.setText("Nom Emp: " + Ingreso.nomEmpleado);
        jLabel_numUser.setText("Núm Emp: " + Ingreso.numEmpleado);

        jButton_Actualizar.setEnabled(false);
        jButton_Borrar.setEnabled(false);

        cargarDatosTabla();
    }

    private void cargarDatosTabla() {
        try {
            // Establece la conexión a la base de datos
            Connection conn = Conexion.conectar();
            // Prepara la consulta SQL para obtener los datos de los proveedores
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Proveedores");
            // Ejecuta la consulta y obtiene el resultado
            ResultSet rs = stmt.executeQuery();

            // Configura el modelo de la tabla
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("ProveedorID");
            model.addColumn("Nombre");
            model.addColumn("Telefono");
            model.addColumn("Email");

            // Llena el modelo con los datos obtenidos de la base de datos
            while (rs.next()) {
                Object[] fila = new Object[4];
                for (int i = 0; i < 4; i++) {
                    fila[i] = rs.getObject(i + 1);
                }
                model.addRow(fila);
            }

            // Establece el modelo en la tabla de proveedores
            jTable_Proveedores.setModel(model);

            // Hace que la tabla no sea editable
            jTable_Proveedores.setDefaultEditor(Object.class, null);

            // Cierra los recursos
            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException ex) {
            // Si ocurre un error durante la consulta, muestra un mensaje de error
            JOptionPane.showMessageDialog(null, "Error en el llenado de las tablas: " + ex.getMessage());
        }

        // Añade un evento para cuando se hace clic en algún registro de la tabla de proveedores
        jTable_Proveedores.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int fila_point = jTable_Proveedores.rowAtPoint(e.getPoint());
                int columna_point = 0;
                if (fila_point > -1) {
                    jButton_Actualizar.setEnabled(true); // Habilita el botón de actualizar
                    jButton_Borrar.setEnabled(true); // Habilita el botón de borrar
                    jButton_Guardar.setEnabled(false); // Deshabilita el botón de guardar
                    // Recibe el ProveedorID de acuerdo al registro seleccionado en la tabla
                    IDProveedor_update = (int) jTable_Proveedores.getValueAt(fila_point, columna_point);
                    java.sql.Connection conn = Conexion.conectar();
                    PreparedStatement stmt;

                    // Realiza una consulta para recuperar los datos de acuerdo al ID y los coloca en los campos correspondientes
                    try {
                        stmt = conn.prepareStatement("SELECT * FROM Proveedores WHERE ProveedorID = ?");
                        stmt.setInt(1, IDProveedor_update);
                        ResultSet rs = stmt.executeQuery();
                        if (rs.next()) {
                            jTextField_Email.setText(rs.getString("Email"));
                            jTextField_Contacto.setText(rs.getString("Telefono"));
                            jTextField_Prooveedor.setText(rs.getString("Nombre"));
                            // Actualiza el ComboBox con el código de proveedor seleccionado
                            String codigoProveedor = rs.getString("ProveedorID");
                        }
                        // Cierra los recursos
                        rs.close();
                        stmt.close();
                        conn.close();
                    } catch (SQLException ex) {
                        // Si ocurre un error durante la consulta, muestra un mensaje de error
                        JOptionPane.showMessageDialog(null, "Error al cargar, contactar al administrador");
                    }
                }
            }
        });
    }

    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("images/Icono.png"));
        return retValue;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField_Prooveedor = new javax.swing.JTextField();
        jTextField_Contacto = new javax.swing.JTextField();
        jTextField_Email = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Proveedores = new javax.swing.JTable();
        jLabel_Producto = new javax.swing.JLabel();
        jLabel_Cantidad = new javax.swing.JLabel();
        jLabel_PrecioU = new javax.swing.JLabel();
        jButton_Guardar = new javax.swing.JButton();
        jLabel_Titulo = new javax.swing.JLabel();
        jButton_Actualizar = new javax.swing.JButton();
        jButton_Borrar = new javax.swing.JButton();
        jLabel_iconUser = new javax.swing.JLabel();
        jLabel_logo = new javax.swing.JLabel();
        jButton_Salir = new javax.swing.JButton();
        jLabel_nameUser = new javax.swing.JLabel();
        jLabel_numUser = new javax.swing.JLabel();
        jLabel_Indicaciones = new javax.swing.JLabel();
        jLabel_Wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField_Prooveedor.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Prooveedor.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_Prooveedor.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Prooveedor.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Prooveedor.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Prooveedor.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Prooveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 170, 210, 20));

        jTextField_Contacto.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Contacto.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_Contacto.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Contacto.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Contacto.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Contacto.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jTextField_Contacto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_ContactoActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField_Contacto, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 220, 110, 20));

        jTextField_Email.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Email.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_Email.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Email.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Email.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Email.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 170, 200, 20));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jScrollPane1.setForeground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setFont(new java.awt.Font("Times New Roman", 1, 10)); // NOI18N

        jTable_Proveedores.setBackground(new java.awt.Color(255, 255, 255));
        jTable_Proveedores.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2)));
        jTable_Proveedores.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 10)); // NOI18N
        jTable_Proveedores.setForeground(new java.awt.Color(0, 0, 0));
        jTable_Proveedores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable_Proveedores.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jTable_Proveedores.setSelectionForeground(new java.awt.Color(0, 0, 0));
        jScrollPane1.setViewportView(jTable_Proveedores);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 300, 540, 120));

        jLabel_Producto.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Producto.setText("Nombre Proveedor");
        getContentPane().add(jLabel_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, 90, 20));

        jLabel_Cantidad.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Cantidad.setText("Telefono");
        getContentPane().add(jLabel_Cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, -1, -1));

        jLabel_PrecioU.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_PrecioU.setText("Email");
        getContentPane().add(jLabel_PrecioU, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 150, -1, 20));

        jButton_Guardar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Guardar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Guardar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/salvar (1).png"))); // NOI18N
        jButton_Guardar.setText("Guardar");
        jButton_Guardar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Guardar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_GuardarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 220, 105, 30));

        jLabel_Titulo.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Titulo.setText("GESTION DE PROVEEDORES");
        getContentPane().add(jLabel_Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 100, 260, 20));

        jButton_Actualizar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Actualizar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Actualizar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Actualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/actualizar.png"))); // NOI18N
        jButton_Actualizar.setText("Actualizar");
        jButton_Actualizar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Actualizar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_ActualizarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 220, 105, 30));

        jButton_Borrar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Borrar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Borrar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Borrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/borrar.png"))); // NOI18N
        jButton_Borrar.setText("Eliminar");
        jButton_Borrar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Borrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_BorrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Borrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 220, 105, 30));

        jLabel_iconUser.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_iconUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/usuario 2.png"))); // NOI18N
        getContentPane().add(jLabel_iconUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 60, 60));

        jLabel_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Logo 2.png"))); // NOI18N
        getContentPane().add(jLabel_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, 70, 70));

        jButton_Salir.setBackground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setForeground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerca 1.png"))); // NOI18N
        jButton_Salir.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Salir.setContentAreaFilled(false);
        jButton_Salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 20, 60, 60));

        jLabel_nameUser.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel_nameUser.setForeground(new java.awt.Color(19, 36, 145));
        getContentPane().add(jLabel_nameUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 30, 150, 20));

        jLabel_numUser.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel_numUser.setForeground(new java.awt.Color(19, 36, 145));
        getContentPane().add(jLabel_numUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 50, 150, 20));

        jLabel_Indicaciones.setFont(new java.awt.Font("Times New Roman", 3, 10)); // NOI18N
        jLabel_Indicaciones.setForeground(new java.awt.Color(19, 36, 145));
        jLabel_Indicaciones.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Indicaciones.setText("PARA REGISTRAR O MODIFICAR ALGÚN PROVEEDOR, COMPLETE LOS CAMPOS REQUERIDOS.");
        getContentPane().add(jLabel_Indicaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, 460, 10));

        jLabel_Wallpaper.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Fondo2.png"))); // NOI18N
        jLabel_Wallpaper.setLabelFor(jLabel_Wallpaper);
        getContentPane().add(jLabel_Wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_ActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_ActualizarActionPerformed
        // Obtener los nuevos valores de los JTextField
        String nombre = jTextField_Prooveedor.getText();
        String email = jTextField_Email.getText();
        String telefono = jTextField_Contacto.getText();
        if (nombre.isEmpty() || email.isEmpty() || telefono.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe llenar todos los campos para actualizar");
        } else {
            try {
                // Obtener los valores actuales en la base de datos para comparación
                Connection conn = Conexion.conectar();
                String sqlSelect = "SELECT Nombre, Telefono, Email FROM Proveedores WHERE ProveedorID = ?";
                PreparedStatement stmtSelect = conn.prepareStatement(sqlSelect);
                stmtSelect.setInt(1, IDProveedor_update);
                ResultSet rs = stmtSelect.executeQuery();

                if (rs.next()) {
                    String nombreActual = rs.getString("Nombre");
                    String telefonoActual = rs.getString("Telefono");
                    String emailActual = rs.getString("Email");

                    // Verificar si los nuevos valores son iguales a los actuales
                    if (nombre.equals(nombreActual) && telefono.equals(telefonoActual) && email.equals(emailActual)) {
                        // Los valores no han cambiado
                        System.out.println("No se han realizado cambios en los datos del proveedor.");
                    } else {
                        // Los valores han cambiado, proceder con la actualización
                        String sqlUpdate = "UPDATE Proveedores SET Nombre = ?, Telefono = ?, Email = ? WHERE ProveedorID = " + IDProveedor_update;
                        PreparedStatement stmtUpdate = conn.prepareStatement(sqlUpdate);
                        stmtUpdate.setString(1, nombre);
                        stmtUpdate.setString(2, telefono);
                        stmtUpdate.setString(3, email);
                        int rowsAffected = stmtUpdate.executeUpdate();

                        if (rowsAffected > 0) {
                            // La actualización fue exitosa
                            JOptionPane.showMessageDialog(null, "Los datos del proveedor se han actualizado correctamente.");
                            new GestionarProveedores().setVisible(true);
                            dispose();
                        } else {
                            // La actualización no tuvo éxito
                            JOptionPane.showMessageDialog(null, "Error al actualizar los datos del proveedor.");
                        }

                        // Cerrar el PreparedStatement para la actualización
                        stmtUpdate.close();
                    }
                }

                // Cerrar los ResultSet y PreparedStatement para la selección
                rs.close();
                stmtSelect.close();

                // Cerrar la conexión
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }
    }//GEN-LAST:event_jButton_ActualizarActionPerformed

    private void jButton_BorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_BorrarActionPerformed
        try {
            // Obtener el ID del proveedor seleccionado del JComboBox

            // Eliminar las ventas relacionadas con el proveedor
            Connection conn = Conexion.conectar();
            String sqlDeleteVentas = "DELETE FROM Ventas WHERE CodigoID IN (SELECT CodigoID FROM Productos WHERE ProveedorID = ?)";
            PreparedStatement stmtDeleteVentas = conn.prepareStatement(sqlDeleteVentas);
            stmtDeleteVentas.setInt(1, IDProveedor_update);
            stmtDeleteVentas.executeUpdate();

            // Eliminar los productos relacionados con el proveedor
            String sqlDeleteProductos = "DELETE FROM Productos WHERE ProveedorID = ?";
            PreparedStatement stmtDeleteProductos = conn.prepareStatement(sqlDeleteProductos);
            stmtDeleteProductos.setInt(1, IDProveedor_update);
            stmtDeleteProductos.executeUpdate();

            // Eliminar el proveedor de la base de datos
            String sqlDeleteProveedor = "DELETE FROM Proveedores WHERE ProveedorID = ?";
            PreparedStatement stmtDeleteProveedor = conn.prepareStatement(sqlDeleteProveedor);
            stmtDeleteProveedor.setInt(1, IDProveedor_update);
            int rowsAffected = stmtDeleteProveedor.executeUpdate();

            // Verificar si el borrado fue exitoso
            if (rowsAffected > 0) {
                // El borrado fue exitoso
                dispose();
                JOptionPane.showMessageDialog(null, "El proveedor ha sido eliminado correctamente.");
                new GestionarProveedores().setVisible(true);
            } else {
                // No se encontró ningún proveedor con el ID especificado
                JOptionPane.showMessageDialog(null, "No se encontró ningún proveedor con el ID especificado.");
            }

            // Cerrar los PreparedStatements
            stmtDeleteVentas.close();
            stmtDeleteProductos.close();
            stmtDeleteProveedor.close();

            // Cerrar la conexión
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al intentar eliminar el proveedor.");
        }
    }//GEN-LAST:event_jButton_BorrarActionPerformed

    private void jButton_GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_GuardarActionPerformed
        // Obtener los valores ingresados para el nuevo proveedor
        String nombre = jTextField_Prooveedor.getText();
        String telefono = jTextField_Contacto.getText();
        String email = jTextField_Email.getText();

        // Verificar que se hayan ingresado todos los datos necesarios
        if (nombre.isEmpty() || telefono.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, ingresa todos los datos del proveedor.");
            return;
        }

        // Insertar el nuevo proveedor en la base de datos
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = Conexion.conectar();
            String sql = "INSERT INTO Proveedores (Nombre, Telefono, Email) VALUES (?, ?, ?)";
            stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, nombre);
            stmt.setString(2, telefono);
            stmt.setString(3, email);
            int rowsAffected = stmt.executeUpdate();

            // Verificar si la inserción fue exitosa
            if (rowsAffected > 0) {
                // Obtener el ID generado para el nuevo proveedor
                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int newProveedorID = generatedKeys.getInt(1);
                    JOptionPane.showMessageDialog(null, "Nuevo proveedor agregado correctamente con ID: " + newProveedorID);
                }

                // Limpiar los campos de texto después de agregar el proveedor
                jTextField_Prooveedor.setText("");
                jTextField_Contacto.setText("");
                jTextField_Email.setText("");

            } else {
                JOptionPane.showMessageDialog(null, "Error al agregar el nuevo proveedor.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
        } finally {
            // Cerrar el PreparedStatement y la conexión
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }//GEN-LAST:event_jButton_GuardarActionPerformed

    private void jButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SalirActionPerformed
        dispose();
        new Administrador().setVisible(true);
    }//GEN-LAST:event_jButton_SalirActionPerformed

    private void jTextField_ContactoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_ContactoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_ContactoActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GestionarProveedores.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GestionarProveedores.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GestionarProveedores.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GestionarProveedores.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GestionarProveedores().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Actualizar;
    private javax.swing.JButton jButton_Borrar;
    private javax.swing.JButton jButton_Guardar;
    private javax.swing.JButton jButton_Salir;
    private javax.swing.JLabel jLabel_Cantidad;
    private javax.swing.JLabel jLabel_Indicaciones;
    private javax.swing.JLabel jLabel_PrecioU;
    private javax.swing.JLabel jLabel_Producto;
    private javax.swing.JLabel jLabel_Titulo;
    private javax.swing.JLabel jLabel_Wallpaper;
    private javax.swing.JLabel jLabel_iconUser;
    private javax.swing.JLabel jLabel_logo;
    private javax.swing.JLabel jLabel_nameUser;
    private javax.swing.JLabel jLabel_numUser;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Proveedores;
    private javax.swing.JTextField jTextField_Contacto;
    private javax.swing.JTextField jTextField_Email;
    private javax.swing.JTextField jTextField_Prooveedor;
    // End of variables declaration//GEN-END:variables
}
