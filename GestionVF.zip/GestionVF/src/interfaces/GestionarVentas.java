package interfaces;

import java.awt.Image;
import java.awt.Toolkit;
import ConexionBD.Conexion;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class GestionarVentas extends javax.swing.JFrame {

    public static int IDVentas_update;

    public GestionarVentas() {
        initComponents();
        setSize(900, 500);
        setResizable(false);
        setTitle("Gestión de Ventas");
        setLocationRelativeTo(null);

        jLabel_nameUser.setText("Nom Emp: " + Ingreso.nomEmpleado);
        jLabel_numUser.setText("Núm Emp: " + Ingreso.numEmpleado);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Ventas = new javax.swing.JTable();
        jDateChooser_Fin = new com.toedter.calendar.JDateChooser();
        jDateChooser_Inicio = new com.toedter.calendar.JDateChooser();
        jComboBox_Factura = new javax.swing.JComboBox<>();
        jLabel_FechaFin = new javax.swing.JLabel();
        jLabel_Factura = new javax.swing.JLabel();
        jLabel_FechaIn = new javax.swing.JLabel();
        jButton_Buscar = new javax.swing.JButton();
        jLabel_Venta = new javax.swing.JLabel();
        jTextField_VentaID = new javax.swing.JTextField();
        jLabel_iconUser = new javax.swing.JLabel();
        jLabel_logo = new javax.swing.JLabel();
        jButton_Salir = new javax.swing.JButton();
        jLabel_nameUser = new javax.swing.JLabel();
        jLabel_numUser = new javax.swing.JLabel();
        jLabel_Titulo = new javax.swing.JLabel();
        jLabel_Indicaciones = new javax.swing.JLabel();
        jLabel_Producto = new javax.swing.JLabel();
        jTextField_ProductoID = new javax.swing.JTextField();
        jTextField_EmpleadoID = new javax.swing.JTextField();
        jLabel_EmpleadoID = new javax.swing.JLabel();
        jLabel_Wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane1.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black, java.awt.Color.black, java.awt.Color.black));
        jScrollPane1.setForeground(new java.awt.Color(0, 0, 0));
        jScrollPane1.setFont(new java.awt.Font("Times New Roman", 1, 10)); // NOI18N

        jTable_Ventas.setAutoCreateRowSorter(true);
        jTable_Ventas.setBackground(new java.awt.Color(255, 255, 255));
        jTable_Ventas.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jTable_Ventas.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 10)); // NOI18N
        jTable_Ventas.setForeground(new java.awt.Color(0, 0, 0));
        jTable_Ventas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {},
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable_Ventas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jTable_Ventas.setSelectionBackground(new java.awt.Color(255, 255, 255));
        jTable_Ventas.setSelectionForeground(new java.awt.Color(0, 0, 0));
        jScrollPane1.setViewportView(jTable_Ventas);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 850, 180));

        jDateChooser_Fin.setBackground(new java.awt.Color(255, 255, 255));
        jDateChooser_Fin.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black));
        jDateChooser_Fin.setForeground(new java.awt.Color(0, 0, 0));
        jDateChooser_Fin.setDateFormatString("d/MMM/y");
        jDateChooser_Fin.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        getContentPane().add(jDateChooser_Fin, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 180, 130, 30));

        jDateChooser_Inicio.setBackground(new java.awt.Color(255, 255, 255));
        jDateChooser_Inicio.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black));
        jDateChooser_Inicio.setForeground(new java.awt.Color(0, 0, 0));
        jDateChooser_Inicio.setDateFormatString("d/MMM/y");
        jDateChooser_Inicio.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        getContentPane().add(jDateChooser_Inicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 130, 30));

        jComboBox_Factura.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_Factura.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jComboBox_Factura.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_Factura.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...", "Si", "No" }));
        jComboBox_Factura.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black));
        jComboBox_Factura.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(jComboBox_Factura, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 180, 70, 30));

        jLabel_FechaFin.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_FechaFin.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel_FechaFin.setText("Fecha Final");
        getContentPane().add(jLabel_FechaFin, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 160, -1, -1));

        jLabel_Factura.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Factura.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel_Factura.setText("Factura");
        getContentPane().add(jLabel_Factura, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 160, -1, -1));

        jLabel_FechaIn.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_FechaIn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel_FechaIn.setText("Fecha Inicial");
        getContentPane().add(jLabel_FechaIn, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, 90, -1));

        jButton_Buscar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Buscar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Buscar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Buscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/buscar.png"))); // NOI18N
        jButton_Buscar.setText("Buscar");
        jButton_Buscar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Buscar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_BuscarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 180, 70, 30));

        jLabel_Venta.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Venta.setText("Venta ID");
        getContentPane().add(jLabel_Venta, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 160, -1, -1));

        jTextField_VentaID.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_VentaID.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_VentaID.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_VentaID.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_VentaID.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_VentaID.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_VentaID, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 180, 80, 30));

        jLabel_iconUser.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_iconUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/usuario 2.png"))); // NOI18N
        getContentPane().add(jLabel_iconUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 60, 60));

        jLabel_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Logo 2.png"))); // NOI18N
        getContentPane().add(jLabel_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(415, 20, 70, 70));

        jButton_Salir.setBackground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setForeground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerca 1.png"))); // NOI18N
        jButton_Salir.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Salir.setContentAreaFilled(false);
        jButton_Salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 20, 60, 60));

        jLabel_nameUser.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel_nameUser.setForeground(new java.awt.Color(19, 36, 145));
        getContentPane().add(jLabel_nameUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 30, 150, 20));

        jLabel_numUser.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel_numUser.setForeground(new java.awt.Color(19, 36, 145));
        getContentPane().add(jLabel_numUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 50, 150, 20));

        jLabel_Titulo.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Titulo.setText("GESTION DE VENTAS");
        getContentPane().add(jLabel_Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 100, 260, 20));

        jLabel_Indicaciones.setFont(new java.awt.Font("Times New Roman", 3, 10)); // NOI18N
        jLabel_Indicaciones.setForeground(new java.awt.Color(19, 36, 145));
        jLabel_Indicaciones.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Indicaciones.setText("PARA BUSCAR UNA VENTA, SELECCIONE UNA DE LAS OPCIONES DE BÚSQUEDA DISPONIBLES.");
        getContentPane().add(jLabel_Indicaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(215, 130, 470, 10));

        jLabel_Producto.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Producto.setText("Producto ID");
        getContentPane().add(jLabel_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 160, -1, -1));

        jTextField_ProductoID.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_ProductoID.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_ProductoID.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_ProductoID.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_ProductoID.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_ProductoID.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_ProductoID, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 180, 80, 30));

        jTextField_EmpleadoID.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_EmpleadoID.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_EmpleadoID.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_EmpleadoID.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_EmpleadoID.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_EmpleadoID.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_EmpleadoID, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 180, 80, 30));

        jLabel_EmpleadoID.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_EmpleadoID.setText("Empleado ID");
        getContentPane().add(jLabel_EmpleadoID, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 160, -1, -1));

        jLabel_Wallpaper.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Fondo2.png"))); // NOI18N
        jLabel_Wallpaper.setLabelFor(jLabel_Wallpaper);
        getContentPane().add(jLabel_Wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void jButton_BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_BuscarActionPerformed
        // Verifica si no se han ingresado fechas ni seleccionado factura ni ingresado el ID de venta
        if (jDateChooser_Inicio.getDate() == null && jDateChooser_Fin.getDate() == null && jComboBox_Factura.getSelectedIndex() == 0 && jTextField_VentaID.getText().isEmpty()
                && jTextField_ProductoID.getText().isEmpty() && jTextField_EmpleadoID.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Para buscar es necesario un rango de fechas, Factura, ID de Venta o ID de Producto");
        } else if ((jDateChooser_Fin.getDate() == null && jDateChooser_Inicio.getDate() != null) || (jDateChooser_Fin.getDate() != null && jDateChooser_Inicio.getDate() == null)) {
            JOptionPane.showMessageDialog(null, "Ambas fechas deben estar llenas");
        } else {
            try {
                // Conexión a la base de datos
                java.sql.Connection conn = Conexion.conectar();
                PreparedStatement stmt;

                // Construcción de la consulta SQL
                StringBuilder queryBuilder = new StringBuilder("SELECT * FROM Ventas WHERE ");
                boolean whereAdded = false;

                // Si se ingresó un rango de fechas
                if (jDateChooser_Inicio.getDate() != null && jDateChooser_Fin.getDate() != null) {
                    queryBuilder.append("Fecha BETWEEN ? AND ? ");
                    whereAdded = true;
                }

                // Si se seleccionó una factura
                if (jComboBox_Factura.getSelectedIndex() > 0) {
                    if (whereAdded) {
                        queryBuilder.append("AND ");
                    }
                    queryBuilder.append("Factura = ? ");
                    whereAdded = true;
                }

                // Si se ingresó un ID de venta
                if (!jTextField_VentaID.getText().isEmpty()) {
                    if (whereAdded) {
                        queryBuilder.append("AND ");
                    }
                    queryBuilder.append("VentaID = ? ");
                    whereAdded = true;
                }
                // Si se ingresó un ID de producto
                if (!jTextField_ProductoID.getText().isEmpty()) {
                    if (whereAdded) {
                        queryBuilder.append("AND ");
                    }
                    queryBuilder.append("ProductoID = ? ");
                    whereAdded = true;
                }
                if (!jTextField_EmpleadoID.getText().isEmpty()) {
                    if (whereAdded) {
                        queryBuilder.append("AND ");
                    }
                    queryBuilder.append("UsuarioID = ? ");
                    whereAdded = true;
                }

                // Preparación de la consulta SQL
                stmt = conn.prepareStatement(queryBuilder.toString());

                // Índice de parámetros
                int parameterIndex = 1;

                // Si se ingresó un rango de fechas, establecer los parámetros correspondientes
                if (jDateChooser_Inicio.getDate() != null && jDateChooser_Fin.getDate() != null) {
                    stmt.setDate(parameterIndex++, new java.sql.Date(jDateChooser_Inicio.getDate().getTime()));
                    stmt.setDate(parameterIndex++, new java.sql.Date(jDateChooser_Fin.getDate().getTime()));
                }

                // Si se seleccionó una factura, establecer el parámetro correspondiente
                if (jComboBox_Factura.getSelectedIndex() > 0) {
                    stmt.setString(parameterIndex++, jComboBox_Factura.getSelectedItem().toString());
                }

                // Si se ingresó un ID de venta, establecer el parámetro correspondiente
                if (!jTextField_VentaID.getText().isEmpty()) {
                    stmt.setString(parameterIndex++, jTextField_VentaID.getText());
                }

                // Si se ingresó un ID de producto, establecer el parámetro correspondiente
                if (!jTextField_ProductoID.getText().isEmpty()) {
                    stmt.setString(parameterIndex++, jTextField_ProductoID.getText());
                }
                // Si se ingresó un ID de empleado, establecer el parámetro correspondiente
                if (!jTextField_EmpleadoID.getText().isEmpty()) {
                    stmt.setString(parameterIndex++, jTextField_EmpleadoID.getText());
                }

                // Ejecutar la consulta SQL
                ResultSet rs = stmt.executeQuery();

                // Configurar el modelo de la tabla
                DefaultTableModel model = new DefaultTableModel() {
                    @Override
                    public boolean isCellEditable(int row, int column) {
                        return false; // Hace que todas las celdas de la tabla no sean editables
                    }
                };

                // Llenar la tabla con los datos obtenidos de la base de datos
                model.addColumn("ProductoID");
                model.addColumn("Precio");
                model.addColumn("Cantidad");
                model.addColumn("Factura");
                model.addColumn("DenominacionSocial");
                model.addColumn("RFC");
                model.addColumn("CP");
                model.addColumn("Regimen");
                model.addColumn("Fecha");
                model.addColumn("Total");
                model.addColumn("Producto");
                model.addColumn("VentaID");
                model.addColumn("UsuarioID");

                // Formato deseado para mostrar la fecha
                SimpleDateFormat formatoSalida = new SimpleDateFormat("dd/MM/yyyy");

                while (rs.next()) {
                    Object[] fila = new Object[13];
                    for (int i = 0; i < 13; i++) {
                        if (i == 8) { // Si es la columna de la fecha, formatearla antes de agregarla a la fila
                            Date fechaBD = rs.getDate("Fecha");
                            fila[i] = formatoSalida.format(fechaBD);
                        } else {
                            fila[i] = rs.getObject(i + 1);
                        }
                    }
                    model.addRow(fila);
                }
                // Asignar el modelo a la tabla
                jTable_Ventas.setModel(model);
                jTextField_ProductoID.setText("");
                jTextField_VentaID.setText("");
                jDateChooser_Fin.setDate(null);
                jDateChooser_Inicio.setDate(null);
                jComboBox_Factura.setSelectedIndex(-1);
                jTextField_EmpleadoID.setText("");
           
                // Eliminar cualquier MouseListener existente
                for (MouseListener ml : jTable_Ventas.getMouseListeners()) {
                    jTable_Ventas.removeMouseListener(ml);
                }

                // Añadir un evento para cuando se hace clic en algún registro de la tabla
                jTable_Ventas.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        if (e.getClickCount() == 1) {
                            int fila_point = jTable_Ventas.rowAtPoint(e.getPoint());
                            if (fila_point > -1) {
                                // Recibir el VentasID de acuerdo al registro seleccionado en la tabla
                                IDVentas_update = (int) jTable_Ventas.getValueAt(fila_point, 11); // Ajustar el índice según la posición correcta de VentasID
                                new GestionarFacturas().setVisible(true); // Pasar el VentasID al constructor de la ventana de gestión de facturas
                            }
                        }
                    }
                });

                // Cerrar recursos
                rs.close();
                stmt.close();
                conn.close();

            } catch (SQLException ex) {
                Logger.getLogger(GestionarEmpleados.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "Error al cargar los datos, inténtelo de nuevo");
            }
        }


    }//GEN-LAST:event_jButton_BuscarActionPerformed

    private void jButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SalirActionPerformed
        dispose();
        new Administrador().setVisible(true);
    }//GEN-LAST:event_jButton_SalirActionPerformed

    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("images/Icono.png"));
        return retValue;
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GestionarVentas.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GestionarVentas.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GestionarVentas.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GestionarVentas.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GestionarVentas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Buscar;
    private javax.swing.JButton jButton_Salir;
    private javax.swing.JComboBox<String> jComboBox_Factura;
    private com.toedter.calendar.JDateChooser jDateChooser_Fin;
    private com.toedter.calendar.JDateChooser jDateChooser_Inicio;
    private javax.swing.JLabel jLabel_EmpleadoID;
    private javax.swing.JLabel jLabel_Factura;
    private javax.swing.JLabel jLabel_FechaFin;
    private javax.swing.JLabel jLabel_FechaIn;
    private javax.swing.JLabel jLabel_Indicaciones;
    private javax.swing.JLabel jLabel_Producto;
    private javax.swing.JLabel jLabel_Titulo;
    private javax.swing.JLabel jLabel_Venta;
    private javax.swing.JLabel jLabel_Wallpaper;
    private javax.swing.JLabel jLabel_iconUser;
    private javax.swing.JLabel jLabel_logo;
    private javax.swing.JLabel jLabel_nameUser;
    private javax.swing.JLabel jLabel_numUser;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Ventas;
    private javax.swing.JTextField jTextField_EmpleadoID;
    private javax.swing.JTextField jTextField_ProductoID;
    private javax.swing.JTextField jTextField_VentaID;
    // End of variables declaration//GEN-END:variables
}
