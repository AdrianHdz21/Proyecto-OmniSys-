package interfaces;

import ConexionBD.Conexion;
import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import java.sql.Statement;


public class gestionarProveedores extends javax.swing.JFrame {
    String user;
    public static int IDcliente_update = 0;
    DefaultTableModel model = new DefaultTableModel();

    public gestionarProveedores() {
        initComponents();
        cargarProveedores();
        setSize(500, 550);
        setResizable(false);
        setTitle("Gestión de Proveedores");
        setLocationRelativeTo(null);

        ImageIcon wallpaper = new ImageIcon("src/images/Fondo2.png");
        Icon icono = new ImageIcon(wallpaper.getImage().getScaledInstance(jLabel_Wallpaper.getWidth(), jLabel_Wallpaper.getHeight(), Image.SCALE_DEFAULT));
        jLabel_Wallpaper.setIcon(icono);
        this.repaint();

        ImageIcon wallpaper_logo = new ImageIcon("src/images/Logo.png");
        Icon icono_logo = new ImageIcon(wallpaper_logo.getImage().getScaledInstance(jLabel_logo.getWidth(), jLabel_logo.getHeight(), Image.SCALE_DEFAULT));
        jLabel_logo.setIcon(icono_logo);
        this.repaint();
        
        
                try {
            Connection HA = Conexion.conectar();
            PreparedStatement PHA = HA.prepareStatement("select * from Proveedores");
            ResultSet HA1 = PHA.executeQuery();
            
            jTable_Proveedores = new JTable(model);
            jScrollPane1.setViewportView(jTable_Proveedores);
            model.addColumn("Codigo");
            model.addColumn("Nombre");
            model.addColumn("Telefono");
            model.addColumn("Email");

            while (HA1.next()) {
                Object[] fila = new Object[4];
                for (int i = 0; i < 4; i++) {
                    fila[i] = HA1.getObject(i + 1);
                }
                model.addRow(fila);

            }
        } catch (SQLException e) {
            System.err.println("Error en el llenado de las tablas");
        }
                
                
        jComboBox_Codigo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                if (evt.getStateChange() == java.awt.event.ItemEvent.SELECTED) {
                    try {
                        // Obtener el valor seleccionado del JComboBox
                        int proveedorID = (int) jComboBox_Codigo.getSelectedItem();

                        // Realizar la consulta a la base de datos para obtener los valores correspondientes
                        Connection conn = Conexion.conectar();
                        String sql = "SELECT Nombre, Telefono, Email FROM Proveedores WHERE ProveedorID = ?";
                        PreparedStatement stmt = conn.prepareStatement(sql);
                        stmt.setInt(1, proveedorID);
                        ResultSet rs = stmt.executeQuery();

                        // Si se encuentra un resultado, llenar los JTextField con los valores obtenidos
                        if (rs.next()) {
                            String nombre = rs.getString("Nombre");
                            String telefono = rs.getString("Telefono");
                            String email = rs.getString("Email");

                            jTextField_Producto.setText(nombre);
                            jTextField_Cantidad.setText(telefono);
                            jTextField_PrecioU.setText(email);
                        } else {
                            // Si no se encuentra ningún resultado, limpiar los JTextField
                            jTextField_Producto.setText("");
                            jTextField_Cantidad.setText("");
                            jTextField_PrecioU.setText("");
                        }

                        // Cerrar la conexión y los recursos relacionados con la base de datos
                        rs.close();
                        stmt.close();
                        conn.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }
    
     private void cargarProveedores() {
        try {
            Connection conn = Conexion.conectar();
            String sql = "SELECT ProveedorID FROM Proveedores";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            DefaultComboBoxModel model = new DefaultComboBoxModel();
            while (rs.next()) {
                model.addElement(rs.getInt("ProveedorID"));
            }

            jComboBox_Codigo.setModel(model);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
     
    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("images/Icono.png"));
        return retValue;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton_Salir = new javax.swing.JButton();
        jLabel_iconUser = new javax.swing.JLabel();
        jLabel_nameUser = new javax.swing.JLabel();
        jLabel_numUser = new javax.swing.JLabel();
        jLabel_logo = new javax.swing.JLabel();
        jTextField_Producto = new javax.swing.JTextField();
        jTextField_Cantidad = new javax.swing.JTextField();
        jTextField_PrecioU = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Proveedores = new javax.swing.JTable();
        jLabel_Codigo = new javax.swing.JLabel();
        jLabel_Producto = new javax.swing.JLabel();
        jLabel_Cantidad = new javax.swing.JLabel();
        jLabel_PrecioU = new javax.swing.JLabel();
        jButton_Guardar = new javax.swing.JButton();
        jLabel_Titulo = new javax.swing.JLabel();
        jComboBox_Codigo = new javax.swing.JComboBox<>();
        jButton_Actualizar = new javax.swing.JButton();
        jButton_Borrar = new javax.swing.JButton();
        jLabel_Wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton_Salir.setBackground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setForeground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerca 1.png"))); // NOI18N
        jButton_Salir.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Salir.setContentAreaFilled(false);
        jButton_Salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 20, 30, 30));

        jLabel_iconUser.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_iconUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/usuario 2.png"))); // NOI18N
        getContentPane().add(jLabel_iconUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 45, 45));

        jLabel_nameUser.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(jLabel_nameUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 130, 20));

        jLabel_numUser.setText("AQUI ESTA");
        getContentPane().add(jLabel_numUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, 130, 20));
        getContentPane().add(jLabel_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, 70, 70));

        jTextField_Producto.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Producto.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jTextField_Producto.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Producto.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Producto.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Producto.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 170, 200, 20));

        jTextField_Cantidad.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Cantidad.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jTextField_Cantidad.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Cantidad.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Cantidad.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Cantidad.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, 110, 20));

        jTextField_PrecioU.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_PrecioU.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jTextField_PrecioU.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_PrecioU.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_PrecioU.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_PrecioU.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_PrecioU, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 230, 200, 20));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jScrollPane1.setForeground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setFont(new java.awt.Font("Times New Roman", 1, 10)); // NOI18N

        jTable_Proveedores.setBackground(new java.awt.Color(102, 102, 102));
        jTable_Proveedores.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2)));
        jTable_Proveedores.setFont(new java.awt.Font("Times New Roman", 1, 10)); // NOI18N
        jTable_Proveedores.setForeground(new java.awt.Color(0, 0, 0));
        jTable_Proveedores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Nombre", "Telefono", "Email"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable_Proveedores.setSelectionForeground(new java.awt.Color(0, 0, 0));
        jScrollPane1.setViewportView(jTable_Proveedores);
        if (jTable_Proveedores.getColumnModel().getColumnCount() > 0) {
            jTable_Proveedores.getColumnModel().getColumn(0).setResizable(false);
            jTable_Proveedores.getColumnModel().getColumn(3).setResizable(false);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 350, 410, 120));

        jLabel_Codigo.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Codigo.setText("Código Proveedor");
        getContentPane().add(jLabel_Codigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, -1));

        jLabel_Producto.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Producto.setText("Nombre Proveedor");
        getContentPane().add(jLabel_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 150, -1, 20));

        jLabel_Cantidad.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Cantidad.setText("Telefono");
        getContentPane().add(jLabel_Cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 210, -1, -1));

        jLabel_PrecioU.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_PrecioU.setText("Email");
        getContentPane().add(jLabel_PrecioU, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 210, -1, 20));

        jButton_Guardar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Guardar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Guardar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/salvar (1).png"))); // NOI18N
        jButton_Guardar.setText("Guardar");
        jButton_Guardar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Guardar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_GuardarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 280, 105, 35));

        jLabel_Titulo.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Titulo.setText("GESTION DE PROVEEDORES");
        getContentPane().add(jLabel_Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, 260, 20));

        jComboBox_Codigo.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_Codigo.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jComboBox_Codigo.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_Codigo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox_Codigo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(60, 63, 65), new java.awt.Color(4, 4, 4), new java.awt.Color(60, 63, 65)));
        jComboBox_Codigo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jComboBox_Codigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_CodigoActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox_Codigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 170, 110, -1));

        jButton_Actualizar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Actualizar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Actualizar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Actualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/actualizar.png"))); // NOI18N
        jButton_Actualizar.setText("Actualizar");
        jButton_Actualizar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Actualizar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_ActualizarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 280, 105, 35));

        jButton_Borrar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Borrar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Borrar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Borrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/borrar.png"))); // NOI18N
        jButton_Borrar.setText("Eliminar");
        jButton_Borrar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Borrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_BorrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Borrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 280, 105, 35));
        getContentPane().add(jLabel_Wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, 550));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SalirActionPerformed
        dispose();
        new administrador().setVisible(true);
    }//GEN-LAST:event_jButton_SalirActionPerformed

    private void jComboBox_CodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_CodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox_CodigoActionPerformed

    private void jButton_ActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_ActualizarActionPerformed
        try {
            // Obtener el valor seleccionado del JComboBox
            int proveedorID = (int) jComboBox_Codigo.getSelectedItem();

            // Obtener los nuevos valores de los JTextField
            String nombre = jTextField_Producto.getText();
            String telefono = jTextField_Cantidad.getText();
            String email = jTextField_PrecioU.getText();

            // Obtener los valores actuales en la base de datos para comparación
            Connection conn = Conexion.conectar();
            String sqlSelect = "SELECT Nombre, Telefono, Email FROM Proveedores WHERE ProveedorID = ?";
            PreparedStatement stmtSelect = conn.prepareStatement(sqlSelect);
            stmtSelect.setInt(1, proveedorID);
            ResultSet rs = stmtSelect.executeQuery();

            if (rs.next()) {
                String nombreActual = rs.getString("Nombre");
                String telefonoActual = rs.getString("Telefono");
                String emailActual = rs.getString("Email");

                // Verificar si los nuevos valores son iguales a los actuales
                if (nombre.equals(nombreActual) && telefono.equals(telefonoActual) && email.equals(emailActual)) {
                    // Los valores no han cambiado
                    System.out.println("No se han realizado cambios en los datos del proveedor.");
                } else {
                    // Los valores han cambiado, proceder con la actualización
                    String sqlUpdate = "UPDATE Proveedores SET Nombre = ?, Telefono = ?, Email = ? WHERE ProveedorID = ?";
                    PreparedStatement stmtUpdate = conn.prepareStatement(sqlUpdate);
                    stmtUpdate.setString(1, nombre);
                    stmtUpdate.setString(2, telefono);
                    stmtUpdate.setString(3, email);
                    stmtUpdate.setInt(4, proveedorID);
                    int rowsAffected = stmtUpdate.executeUpdate();

                    if (rowsAffected > 0) {
                        // La actualización fue exitosa
                        JOptionPane.showMessageDialog(null, "Los datos del proveedor se han actualizado correctamente.");
                    } else {
                        // La actualización no tuvo éxito
                        JOptionPane.showMessageDialog(null, "Error al actualizar los datos del proveedor.");
                    }

                    // Cerrar el PreparedStatement para la actualización
                    stmtUpdate.close();
                }
            }

            // Cerrar los ResultSet y PreparedStatement para la selección
            rs.close();
            stmtSelect.close();

            // Cerrar la conexión
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton_ActualizarActionPerformed

    private void jButton_BorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_BorrarActionPerformed
        try {
            // Obtener el ID del proveedor seleccionado del JComboBox
            int proveedorID = (int) jComboBox_Codigo.getSelectedItem();

            // Eliminar las ventas relacionadas con el proveedor
            Connection conn = Conexion.conectar();
            String sqlDeleteVentas = "DELETE FROM Ventas WHERE CodigoID IN (SELECT CodigoID FROM Productos WHERE ProveedorID = ?)";
            PreparedStatement stmtDeleteVentas = conn.prepareStatement(sqlDeleteVentas);
            stmtDeleteVentas.setInt(1, proveedorID);
            stmtDeleteVentas.executeUpdate();

            // Eliminar los productos relacionados con el proveedor
            String sqlDeleteProductos = "DELETE FROM Productos WHERE ProveedorID = ?";
            PreparedStatement stmtDeleteProductos = conn.prepareStatement(sqlDeleteProductos);
            stmtDeleteProductos.setInt(1, proveedorID);
            stmtDeleteProductos.executeUpdate();

            // Eliminar el proveedor de la base de datos
            String sqlDeleteProveedor = "DELETE FROM Proveedores WHERE ProveedorID = ?";
            PreparedStatement stmtDeleteProveedor = conn.prepareStatement(sqlDeleteProveedor);
            stmtDeleteProveedor.setInt(1, proveedorID);
            int rowsAffected = stmtDeleteProveedor.executeUpdate();

            // Verificar si el borrado fue exitoso
            if (rowsAffected > 0) {
                // El borrado fue exitoso
                JOptionPane.showMessageDialog(null, "El proveedor ha sido eliminado correctamente.");
            } else {
                // No se encontró ningún proveedor con el ID especificado
                JOptionPane.showMessageDialog(null, "No se encontró ningún proveedor con el ID especificado.");
            }

            // Cerrar los PreparedStatements
            stmtDeleteVentas.close();
            stmtDeleteProductos.close();
            stmtDeleteProveedor.close();

            // Cerrar la conexión
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al intentar eliminar el proveedor.");
        }
    }//GEN-LAST:event_jButton_BorrarActionPerformed

    private void jButton_GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_GuardarActionPerformed
        // Obtener los valores ingresados para el nuevo proveedor
            String nombre = jTextField_Producto.getText();
            String telefono = jTextField_Cantidad.getText();
            String email = jTextField_PrecioU.getText();

            // Verificar que se hayan ingresado todos los datos necesarios
            if (nombre.isEmpty() || telefono.isEmpty() || email.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Por favor, ingresa todos los datos del proveedor.");
                return;
            }

            // Insertar el nuevo proveedor en la base de datos
            Connection conn = null;
            PreparedStatement stmt = null;
            try {
                conn = Conexion.conectar();
                String sql = "INSERT INTO Proveedores (Nombre, Telefono, Email) VALUES (?, ?, ?)";
                stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
                stmt.setString(1, nombre);
                stmt.setString(2, telefono);
                stmt.setString(3, email);
                int rowsAffected = stmt.executeUpdate();

                // Verificar si la inserción fue exitosa
                if (rowsAffected > 0) {
                    // Obtener el ID generado para el nuevo proveedor
                    ResultSet generatedKeys = stmt.getGeneratedKeys();
                    if (generatedKeys.next()) {
                        int newProveedorID = generatedKeys.getInt(1);
                        JOptionPane.showMessageDialog(null, "Nuevo proveedor agregado correctamente con ID: " + newProveedorID);
                    }

                    // Limpiar los campos de texto después de agregar el proveedor
                    jTextField_Producto.setText("");
                    jTextField_Cantidad.setText("");
                    jTextField_PrecioU.setText("");

                    // Actualizar la lista de proveedores en el JComboBox y la tabla
                    cargarProveedores();
                } else {
                    JOptionPane.showMessageDialog(null, "Error al agregar el nuevo proveedor.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos.");
            } finally {
                // Cerrar el PreparedStatement y la conexión
                if (stmt != null) {
                    try {
                        stmt.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                if (conn != null) {
                    try {
                        conn.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
    }//GEN-LAST:event_jButton_GuardarActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(gestionarProveedores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(gestionarProveedores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(gestionarProveedores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(gestionarProveedores.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new gestionarProveedores().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Actualizar;
    private javax.swing.JButton jButton_Borrar;
    private javax.swing.JButton jButton_Guardar;
    private javax.swing.JButton jButton_Salir;
    private javax.swing.JComboBox<String> jComboBox_Codigo;
    private javax.swing.JLabel jLabel_Cantidad;
    private javax.swing.JLabel jLabel_Codigo;
    private javax.swing.JLabel jLabel_PrecioU;
    private javax.swing.JLabel jLabel_Producto;
    private javax.swing.JLabel jLabel_Titulo;
    private javax.swing.JLabel jLabel_Wallpaper;
    private javax.swing.JLabel jLabel_iconUser;
    private javax.swing.JLabel jLabel_logo;
    private javax.swing.JLabel jLabel_nameUser;
    private javax.swing.JLabel jLabel_numUser;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Proveedores;
    private javax.swing.JTextField jTextField_Cantidad;
    private javax.swing.JTextField jTextField_PrecioU;
    private javax.swing.JTextField jTextField_Producto;
    // End of variables declaration//GEN-END:variables
}
