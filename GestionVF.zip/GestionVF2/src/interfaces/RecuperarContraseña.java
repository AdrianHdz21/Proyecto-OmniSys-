package interfaces;

import java.awt.Image;
import java.awt.Toolkit;
import ConexionBD.Conexion;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import java.sql.*;
import java.util.Properties;
import javax.swing.JOptionPane;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class RecuperarContraseña extends javax.swing.JFrame {

    //Constructor de la clase
    public RecuperarContraseña() {
        initComponents(); // Inicializa componentes de la interfaz
        setSize(450, 250); // Establece tamaño de la ventana
        setResizable(false); // Hace que la ventana no sea redimensionable
        setTitle("Recuperacion De Contraseña"); // Establece el título de la ventana
        setLocationRelativeTo(null); // Centra la ventana en la pantalla
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);  //Hace que la ventana no se cierre

    }

// Método para obtener el icono de la aplicación
    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("images/Icono.png"));
        return retValue;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton_Recuperar = new javax.swing.JButton();
        jLabel_Titulo = new javax.swing.JLabel();
        jLabel_logo = new javax.swing.JLabel();
        jButton_Salir = new javax.swing.JButton();
        jLabel_Indicaciones = new javax.swing.JLabel();
        jLabel_Contacto1 = new javax.swing.JLabel();
        jTextField_Email = new javax.swing.JTextField();
        jLabel_Wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton_Recuperar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Recuperar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Recuperar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Recuperar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/restablecer.png"))); // NOI18N
        jButton_Recuperar.setText("RESTABLECER");
        jButton_Recuperar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Recuperar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Recuperar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_RecuperarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Recuperar, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 150, 105, 35));

        jLabel_Titulo.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Titulo.setText("RECUPERACION DE CONTRASEÑA");
        getContentPane().add(jLabel_Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 350, 25));

        jLabel_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Logo 2.png"))); // NOI18N
        getContentPane().add(jLabel_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 10, 70, 70));

        jButton_Salir.setBackground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setForeground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerca 1.png"))); // NOI18N
        jButton_Salir.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Salir.setContentAreaFilled(false);
        jButton_Salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 10, 60, 60));

        jLabel_Indicaciones.setFont(new java.awt.Font("Times New Roman", 3, 10)); // NOI18N
        jLabel_Indicaciones.setForeground(new java.awt.Color(19, 36, 145));
        jLabel_Indicaciones.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Indicaciones.setText("PARA LA RECUPERACION, COMPLETE  EL CAMPO REQUERIDO.");
        getContentPane().add(jLabel_Indicaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, 370, 10));

        jLabel_Contacto1.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Contacto1.setText("Email");
        getContentPane().add(jLabel_Contacto1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, -1, -1));

        jTextField_Email.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Email.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_Email.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Email.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Email.setToolTipText(" ");
        jTextField_Email.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Email.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, 200, 25));

        jLabel_Wallpaper.setBackground(new java.awt.Color(255, 255, 255));
        jLabel_Wallpaper.setForeground(new java.awt.Color(0, 0, 0));
        jLabel_Wallpaper.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Fondo2.png"))); // NOI18N
        jLabel_Wallpaper.setLabelFor(jLabel_Wallpaper);
        getContentPane().add(jLabel_Wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 450, 250));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SalirActionPerformed
        dispose();
        new Ingreso().setVisible(true);
    }//GEN-LAST:event_jButton_SalirActionPerformed

    //Metodo del boton guardar
    private void jButton_RecuperarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_RecuperarActionPerformed
        String email = jTextField_Email.getText().trim();
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";

// Validar que se haya proporcionado al menos uno de los dos parámetros
        if (email.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Debe proporcionar el correo electrónico", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

// Validar que el correo electrónico tenga un formato válido
        if (!email.matches(emailRegex)) {
            JOptionPane.showMessageDialog(null, "El correo electrónico no tiene un formato válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Connection conn = null;
        try {
            // Establecer la conexión a la base de datos
            conn = DriverManager.getConnection("jdbc:sqlserver://sysales.database.windows.net:1433;database=sysales;user=administrador;password=systeam@123");

            // Preparar la consulta SQL para obtener los datos de los empleados
            PreparedStatement stmt = conn.prepareStatement("SELECT Contrasena FROM Empleados WHERE Email = ?");
            stmt.setString(1, email);

            // Ejecutar la consulta y obtener el resultado
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String contraseña = rs.getString("Contrasena");

                // Envío de correo electrónico con la contraseña recuperada
                enviarCorreo(email, "Solicitud de recuperación de Contraseña", "Su contraseña es: " + contraseña);
                JOptionPane.showMessageDialog(null, "Su contraseña fue enviada al correo electrónico registrado");
                dispose();

            } else {
                JOptionPane.showMessageDialog(null, "No se encontró ninguna cuenta asociada al correo electrónico proporcionado", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al recuperar la contraseña: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } finally {
            // Cerrar la conexión a la base de datos
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        new Ingreso().setVisible(true);
        

    }//GEN-LAST:event_jButton_RecuperarActionPerformed

    public void enviarCorreo(String destino, String asunto, String mensaje) {
        // Credenciales de API de Mailjet
        final String mailjetPublicKey = "3a9c6d844860276e8a4fe56dd398d1a7";
        final String mailjetPrivateKey = "609856274a7b80e230319db14f782073";

        Properties props = new Properties();
        props.put("mail.smtp.host", "in-v3.mailjet.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(mailjetPublicKey, mailjetPrivateKey);
            }
        });

        try {
            // Creación del mensaje
            Message mensajeCorreo = new MimeMessage(session);
            mensajeCorreo.setFrom(new InternetAddress("onmisysteam@outlook.es")); // Remitente del correo
            mensajeCorreo.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destino));
            mensajeCorreo.setSubject(asunto);
            mensajeCorreo.setText(mensaje);

            // Envío del mensaje
            Transport.send(mensajeCorreo);
        } catch (MessagingException e) {
            JOptionPane.showMessageDialog(null, "Error al enviar el correo electrónico: " + e.getMessage());
            e.printStackTrace();
        }

    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RecuperarContraseña.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RecuperarContraseña.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RecuperarContraseña.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RecuperarContraseña.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>


        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RecuperarContraseña().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Recuperar;
    private javax.swing.JButton jButton_Salir;
    private javax.swing.JLabel jLabel_Contacto1;
    private javax.swing.JLabel jLabel_Indicaciones;
    private javax.swing.JLabel jLabel_Titulo;
    private javax.swing.JLabel jLabel_Wallpaper;
    private javax.swing.JLabel jLabel_logo;
    private javax.swing.JTextField jTextField_Email;
    // End of variables declaration//GEN-END:variables
}
