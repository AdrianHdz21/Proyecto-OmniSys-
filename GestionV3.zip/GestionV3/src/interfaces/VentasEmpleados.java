package interfaces;

import ConexionBD.Conexion;
import com.itextpdf.text.Chunk;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.io.FileOutputStream;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import java.text.SimpleDateFormat;
import java.util.Date;

public class VentasEmpleados extends javax.swing.JFrame {

    private JTextField[] textFields;
    private static int currentVentasID = 0;

    public VentasEmpleados() {
        initComponents();
        setSize(600, 600);
        setResizable(false);
        setTitle("Registro Ventas");
        setLocationRelativeTo(null);
        JTextField jTextField = new JTextField();

        cargaDatos();
        jLabel_nameUser.setText("Empleado: " + ingreso.nomEmpleado);
        jLabel_numUser.setText("Número Empleado: " + ingreso.numEmpleado);

    }

    private void cargaDatos() {
        // Llenar el listado de los productos disponibles en la base de datos
        try {
            Connection conn = Conexion.conectar();
            PreparedStatement stmt = conn.prepareStatement("SELECT ProductoID FROM Productos");
            ResultSet rs = stmt.executeQuery();

            // Limpiar el jComboBox antes de agregar los elementos
            jComboBox_CodigoProd.removeAllItems();
            // Agregar un elemento vacío al inicio del JComboBox
            jComboBox_CodigoProd.addItem("");

            while (rs.next()) {
                int productoID = rs.getInt("ProductoID");
                jComboBox_CodigoProd.addItem(String.valueOf(productoID));
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al llenar el listado de Productos: " + e.getMessage());
        }

        // Agregar ActionListener para cargar informacion de cada producto 
        jComboBox_CodigoProd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener el ProductoID seleccionado
                int selectedProductID = Integer.parseInt(jComboBox_CodigoProd.getSelectedItem().toString());

                // Consultar la base de datos para obtener los detalles del producto
                try {
                    Connection conn = Conexion.conectar();
                    PreparedStatement stmt = conn.prepareStatement("SELECT Nombre, Precio FROM Productos WHERE ProductoID = ?");
                    stmt.setInt(1, selectedProductID);
                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()) {
                        // Cargar los detalles en los campos de texto
                        jTextField_Producto.setText(rs.getString("Nombre"));
                        jTextField_PrecioU.setText(String.valueOf(rs.getDouble("Precio")));
                    } else {
                        // Manejar el caso si no se encuentra el producto
                        JOptionPane.showMessageDialog(null, "Producto no encontrado");
                    }

                    rs.close();
                    stmt.close();
                    conn.close();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Error al cargar los detalles del producto: " + ex.getMessage());
                }
            }
        });

    }

    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("images/Icono.png"));
        return retValue;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton_Salir = new javax.swing.JButton();
        jLabel_iconUser = new javax.swing.JLabel();
        jLabel_nameUser = new javax.swing.JLabel();
        jLabel_numUser = new javax.swing.JLabel();
        jLabel_logo = new javax.swing.JLabel();
        jTextField_Producto = new javax.swing.JTextField();
        jTextField_Cantidad = new javax.swing.JTextField();
        jTextField_PrecioU = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Factura = new javax.swing.JTable();
        jComboBox_CodigoProd = new javax.swing.JComboBox<>();
        jLabel_CodigoProd = new javax.swing.JLabel();
        jLabel_Producto = new javax.swing.JLabel();
        jLabel_Cantidad = new javax.swing.JLabel();
        jLabel_PrecioU = new javax.swing.JLabel();
        jButton_Agregar = new javax.swing.JButton();
        jButton_Ticket = new javax.swing.JButton();
        jLabel_Titulo = new javax.swing.JLabel();
        jLabel_Indicaciones = new javax.swing.JLabel();
        jTextField_CP = new javax.swing.JTextField();
        jTextField_Nombre = new javax.swing.JTextField();
        jTextField_RFC = new javax.swing.JTextField();
        jComboBox_Regimen = new javax.swing.JComboBox<>();
        jComboBox_Factura = new javax.swing.JComboBox<>();
        jLabel_Factura = new javax.swing.JLabel();
        jLabel_Regimen = new javax.swing.JLabel();
        jLabel_RFC = new javax.swing.JLabel();
        jLabel_Nombre = new javax.swing.JLabel();
        jLabel_CP = new javax.swing.JLabel();
        jLabel_Wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton_Salir.setBackground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setForeground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerca 1.png"))); // NOI18N
        jButton_Salir.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Salir.setContentAreaFilled(false);
        jButton_Salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 20, 45, 45));

        jLabel_iconUser.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_iconUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/usuario 2.png"))); // NOI18N
        getContentPane().add(jLabel_iconUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 45, 45));

        jLabel_nameUser.setFont(new java.awt.Font("Tw Cen MT", 1, 12)); // NOI18N
        jLabel_nameUser.setForeground(new java.awt.Color(19, 36, 145));
        getContentPane().add(jLabel_nameUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 150, 20));

        jLabel_numUser.setFont(new java.awt.Font("Tw Cen MT", 1, 12)); // NOI18N
        jLabel_numUser.setForeground(new java.awt.Color(19, 36, 145));
        getContentPane().add(jLabel_numUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 40, 150, 20));

        jLabel_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Logo 2.png"))); // NOI18N
        jLabel_logo.setLabelFor(jLabel_logo);
        getContentPane().add(jLabel_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 10, 70, 70));

        jTextField_Producto.setEditable(false);
        jTextField_Producto.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Producto.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jTextField_Producto.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Producto.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Producto.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Producto.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().add(jTextField_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 170, 230, 20));

        jTextField_Cantidad.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Cantidad.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jTextField_Cantidad.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Cantidad.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Cantidad.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Cantidad.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, 110, 20));

        jTextField_PrecioU.setEditable(false);
        jTextField_PrecioU.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_PrecioU.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jTextField_PrecioU.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_PrecioU.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_PrecioU.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_PrecioU.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().add(jTextField_PrecioU, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 170, 100, 20));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jScrollPane1.setForeground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setFont(new java.awt.Font("Times New Roman", 1, 10)); // NOI18N

        jTable_Factura.setBackground(new java.awt.Color(255, 255, 255));
        jTable_Factura.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2)));
        jTable_Factura.setFont(new java.awt.Font("Times New Roman", 0, 10)); // NOI18N
        jTable_Factura.setForeground(new java.awt.Color(0, 0, 0));
        jTable_Factura.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTable_Factura);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 390, 500, 120));

        jComboBox_CodigoProd.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_CodigoProd.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jComboBox_CodigoProd.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_CodigoProd.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        jComboBox_CodigoProd.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(60, 63, 65), new java.awt.Color(4, 4, 4), new java.awt.Color(60, 63, 65)));
        jComboBox_CodigoProd.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().add(jComboBox_CodigoProd, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 170, 110, 20));

        jLabel_CodigoProd.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_CodigoProd.setText("Código Producto");
        getContentPane().add(jLabel_CodigoProd, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, 20));

        jLabel_Producto.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Producto.setText("Producto");
        getContentPane().add(jLabel_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, -1, 20));

        jLabel_Cantidad.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Cantidad.setText("Cantidad");
        getContentPane().add(jLabel_Cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, -1, 20));

        jLabel_PrecioU.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_PrecioU.setText("Precio Unitario");
        getContentPane().add(jLabel_PrecioU, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 150, -1, 20));

        jButton_Agregar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Agregar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Agregar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Agregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/agregar.png"))); // NOI18N
        jButton_Agregar.setText("Agregar Producto");
        jButton_Agregar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Agregar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_AgregarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Agregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 330, 120, 35));

        jButton_Ticket.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Ticket.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Ticket.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Ticket.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/lista.png"))); // NOI18N
        jButton_Ticket.setText("Generar Ticket");
        jButton_Ticket.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Ticket.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Ticket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_TicketActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Ticket, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 330, 105, 35));

        jLabel_Titulo.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Titulo.setText("REGISTRO VENTAS");
        getContentPane().add(jLabel_Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 100, 230, 20));

        jLabel_Indicaciones.setFont(new java.awt.Font("Times New Roman", 3, 10)); // NOI18N
        jLabel_Indicaciones.setForeground(new java.awt.Color(19, 36, 145));
        jLabel_Indicaciones.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Indicaciones.setText("INGRESE LOS DATOS SOLICITADOS");
        getContentPane().add(jLabel_Indicaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 130, 190, 10));

        jTextField_CP.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_CP.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jTextField_CP.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_CP.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_CP.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_CP.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_CP, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 270, 110, 20));

        jTextField_Nombre.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Nombre.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jTextField_Nombre.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Nombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Nombre.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Nombre.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 220, 240, 20));

        jTextField_RFC.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_RFC.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jTextField_RFC.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_RFC.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_RFC.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_RFC.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_RFC, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, 110, 20));

        jComboBox_Regimen.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_Regimen.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jComboBox_Regimen.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_Regimen.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Simplificado de confianza", "General de ley", "Sin fines de lucro", "Personas Físicas con Act Emp" }));
        jComboBox_Regimen.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(60, 63, 65), new java.awt.Color(4, 4, 4), new java.awt.Color(60, 63, 65)));
        jComboBox_Regimen.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().add(jComboBox_Regimen, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 270, 240, 20));

        jComboBox_Factura.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_Factura.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jComboBox_Factura.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_Factura.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Si", "No" }));
        jComboBox_Factura.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(60, 63, 65), new java.awt.Color(4, 4, 4), new java.awt.Color(60, 63, 65)));
        jComboBox_Factura.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jComboBox_Factura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_FacturaActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox_Factura, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 220, 90, 20));

        jLabel_Factura.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Factura.setText("¿Requiere Factura?");
        getContentPane().add(jLabel_Factura, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, -1, 20));

        jLabel_Regimen.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Regimen.setText("Régimen Fiscal");
        getContentPane().add(jLabel_Regimen, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 250, -1, 20));

        jLabel_RFC.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_RFC.setText("RFC");
        getContentPane().add(jLabel_RFC, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, -1, 20));

        jLabel_Nombre.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Nombre.setText("Nombre o Denominación Social");
        getContentPane().add(jLabel_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 200, 240, 20));

        jLabel_CP.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_CP.setText("Código Postal");
        getContentPane().add(jLabel_CP, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 250, -1, 20));

        jLabel_Wallpaper.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Fondo2.png"))); // NOI18N
        jLabel_Wallpaper.setLabelFor(jLabel_Wallpaper);
        getContentPane().add(jLabel_Wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 600));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void jButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SalirActionPerformed
        dispose();
        new ingreso().setVisible(true);
    }//GEN-LAST:event_jButton_SalirActionPerformed

    private void jButton_TicketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_TicketActionPerformed
        try {
            // Crear el documento PDF
            Document document = new Document();
            String rutaDescargas = System.getProperty("user.home") + "\\Downloads\\ticket_" + currentVentasID + ".pdf";
            PdfWriter.getInstance(document, new FileOutputStream(rutaDescargas));
            document.open();

            // Agregar encabezado
            Paragraph header = new Paragraph("TICKET DE VENTA");
            header.setAlignment(Element.ALIGN_CENTER);
            header.setFont(FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16));
            document.add(header);
            document.add(Chunk.NEWLINE);

            // Agregar información general
            String factura = jComboBox_Factura.getSelectedItem().toString();
            String regimen;

            if (factura.equals("Si")) {
                regimen = jComboBox_Regimen.getSelectedItem().toString();
            } else {
                regimen = "";
            }

            // Obtener la fecha y hora actual
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            String fechaHoraActual = dateFormat.format(new Date());

            Paragraph infoGeneral = new Paragraph("Venta ID: " + currentVentasID + "\n"
                    + "Fecha y Hora: " + fechaHoraActual + "\n"
                    + "Factura: " + factura + "\n"
                    + "Régimen Fiscal: " + regimen);
            document.add(infoGeneral);
            document.add(Chunk.NEWLINE);

            // Agregar información del cliente
            Paragraph infoCliente = new Paragraph("Información del Cliente:\n"
                    + "Nombre o Denominación Social: " + jTextField_Nombre.getText() + "\n"
                    + "RFC: " + jTextField_RFC.getText() + "\n"
                    + "Código Postal: " + jTextField_CP.getText());
            document.add(infoCliente);
            document.add(Chunk.NEWLINE);

            // Crear tabla para los productos
            PdfPTable tabla = new PdfPTable(5);
            tabla.setWidthPercentage(100);
            tabla.setSpacingBefore(10);
            tabla.setSpacingAfter(10);

            // Encabezados de la tabla
            tabla.addCell("Código");
            tabla.addCell("Producto");
            tabla.addCell("Precio Unitario (MXN)");
            tabla.addCell("Cantidad");
            tabla.addCell("Total (MXN)");

            // Obtener los productos de la tabla Ventas y agregarlos a la tabla PDF
            try {
                Connection conn = Conexion.conectar();
                PreparedStatement stmt = conn.prepareStatement("SELECT CodigoID, Producto, Precio, Cantidad, Total FROM Ventas WHERE VentasID = ?");
                stmt.setInt(1, currentVentasID);
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    String codigoProducto = rs.getString("CodigoID");
                    String nombreProducto = rs.getString("Producto");
                    double precioUnitario = rs.getDouble("Precio");
                    int cantidadProducto = rs.getInt("Cantidad");
                    double totalProducto = rs.getDouble("Total");

                    tabla.addCell(codigoProducto);
                    tabla.addCell(nombreProducto);
                    tabla.addCell(String.format("$%.2f MXN", precioUnitario));
                    tabla.addCell(String.valueOf(cantidadProducto));
                    tabla.addCell(String.format("$%.2f MXN", totalProducto));
                }

                rs.close();
                stmt.close();
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error al obtener los productos de la tabla Ventas: " + ex.getMessage());
            }

            document.add(tabla);

            // Agregar total general
            double totalGeneral = 0.0;
            try {
                Connection conn = Conexion.conectar();
                PreparedStatement stmt = conn.prepareStatement("SELECT SUM(Total) AS TotalGeneral FROM Ventas WHERE VentasID = ?");
                stmt.setInt(1, currentVentasID);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    totalGeneral = rs.getDouble("TotalGeneral");
                }

                rs.close();
                stmt.close();
                conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error al obtener el total general: " + ex.getMessage());
            }

            Paragraph totalGeneralParagraph = new Paragraph("Total General: $" + String.format("%.2f MXN", totalGeneral), FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12));
            totalGeneralParagraph.setAlignment(Element.ALIGN_RIGHT);
            document.add(totalGeneralParagraph);

            document.close();

            JOptionPane.showMessageDialog(this, "El archivo PDF ha sido generado correctamente en la carpeta de descargas.");
            new VentasEmpleados().setVisible(true);
            dispose();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al generar el archivo PDF: " + ex.getMessage());
        }
    }//GEN-LAST:event_jButton_TicketActionPerformed

    private void jButton_AgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_AgregarActionPerformed
        // Obtener los valores de los campos de texto
        String cp = jTextField_CP.getText();
        String nombreDenominacion = jTextField_Nombre.getText();
        String rfc = jTextField_RFC.getText();
        String producto = jTextField_Producto.getText();
        int cantidad = 0;
        if (!jTextField_Cantidad.getText().isEmpty()) {
            cantidad = Integer.parseInt(jTextField_Cantidad.getText());
        }

        double precio = 0.0;
        if (!jTextField_PrecioU.getText().isEmpty()) {
            precio = Double.parseDouble(jTextField_PrecioU.getText());
        }

        double total = cantidad * precio;
        total = Math.round(total * 100.0) / 100.0; // Formatear total a dos decimales

// Obtener el valor seleccionado del JComboBox
        String codigoProducto = jComboBox_CodigoProd.getSelectedItem().toString();
        String facturaSeleccionada = jComboBox_Factura.getSelectedItem().toString();

        String regimen;
        if (facturaSeleccionada.equals("Si")) {
            regimen = jComboBox_Regimen.getSelectedItem().toString();
        } else {
            regimen = "";
        }

        if (facturaSeleccionada.equals("Si") && (cp.isEmpty() || nombreDenominacion.isEmpty() || rfc.isEmpty())) {
            JOptionPane.showMessageDialog(null, "Debes llenar todos los campos");
        } else {
            // Obtener un nuevo VentasID si no hay una venta actual
            if (currentVentasID == 0) {
                currentVentasID = obtenerUltimoID("Ventas", "VentasID") + 1;
            }

            try {
                // Preparar la sentencia SQL para insertar un nuevo producto en la venta actual
                Connection conn = Conexion.conectar();

                PreparedStatement stmtProducto = conn.prepareStatement(
                        "INSERT INTO Ventas (VentasID, CodigoID, Producto, Precio, Cantidad, Factura, NombreDenominacion, RFC, CP, Regimen, Fecha, Total) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                stmtProducto.setInt(1, currentVentasID); // Asignar el IDVenta obtenido
                stmtProducto.setString(2, codigoProducto);
                stmtProducto.setString(3, producto);
                stmtProducto.setDouble(4, precio);
                stmtProducto.setInt(5, cantidad);
                stmtProducto.setString(6, facturaSeleccionada);
                stmtProducto.setString(7, nombreDenominacion);
                stmtProducto.setString(8, rfc);
                stmtProducto.setString(9, cp);
                stmtProducto.setString(10, regimen); // Establecer el valor del régimen
                stmtProducto.setDate(11, new java.sql.Date(System.currentTimeMillis()));
                stmtProducto.setDouble(12, total);

                stmtProducto.executeUpdate();
                stmtProducto.close();
                conn.close();

                if (facturaSeleccionada.equals("No")) {
                    jTextField_Producto.setText("");
                    jTextField_Cantidad.setText("");
                    jTextField_PrecioU.setText("");
                    jComboBox_CodigoProd.setSelectedIndex(1);
                    jTextField_CP.setText("");
                    jTextField_Nombre.setText("");
                    jTextField_RFC.setText("");
                } else {
                    jTextField_Producto.setText("");
                    jTextField_Cantidad.setText("");
                    jTextField_PrecioU.setText("");
                    jComboBox_CodigoProd.setSelectedIndex(1);
                }

                // Actualizar la tabla JTable_Ventas con los nuevos datos
                actualizarTablaVentas();

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error al insertar en la tabla Ventas: " + ex.getMessage());
            }
        }
    }

    private int obtenerUltimoID(String tabla, String columnaID) {
        int ultimoID = 0;
        try {
            Connection conn = Conexion.conectar();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT MAX(" + columnaID + ") AS UltimoID FROM " + tabla);
            if (rs.next()) {
                ultimoID = rs.getInt("UltimoID");
            }
            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al obtener el último ID de la tabla " + tabla + ": " + ex.getMessage());
        }
        return ultimoID;
    }

    // Método para actualizar la tabla Ventas
    private void actualizarTablaVentas() {
        try {
            Connection conn = Conexion.conectar();
            PreparedStatement stmt = conn.prepareStatement("SELECT VentasID, CodigoID, Producto, Precio, Cantidad, Total FROM Ventas WHERE VentasID = ?");
            stmt.setInt(1, currentVentasID);
            ResultSet rs = stmt.executeQuery();

            // Configurar el modelo de la tabla
            DefaultTableModel model = new DefaultTableModel() {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false; // Hace que todas las celdas de la tabla no sean editables
                }
            };
            model.setRowCount(0);

            // Agregar columnas al modelo
            model.addColumn("Venta ID");
            model.addColumn("Producto ID");
            model.addColumn("Producto");
            model.addColumn("Precio Uni");
            model.addColumn("Cantidad");
            model.addColumn("Total");

            // Llenar el modelo con los datos obtenidos de la base de datos
            while (rs.next()) {
                Object[] fila = new Object[6];
                for (int i = 0; i < 6; i++) {
                    fila[i] = rs.getObject(i + 1);
                }
                model.addRow(fila);
            }

            rs.close();
            stmt.close();
            conn.close();

            // Asignar el modelo a la tabla JTable_Ventas
            jTable_Factura.setModel(model);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al actualizar la tabla Ventas: " + ex.getMessage());
        }
    }//GEN-LAST:event_jButton_AgregarActionPerformed

    private void jComboBox_FacturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_FacturaActionPerformed
        textFields = new JTextField[]{jTextField_CP, jTextField_Nombre, jTextField_RFC};
        boolean selected = jComboBox_Factura.getSelectedItem().toString().equals("No");
        for (JTextField textField : textFields) {
            textField.setEnabled(!selected);
            jComboBox_Regimen.setEnabled(!selected);
            if (!selected) {
                textField.setBackground(Color.WHITE);
                jComboBox_Regimen.setBackground(Color.WHITE);
            } else {
                textField.setBackground(Color.LIGHT_GRAY);
                jComboBox_Regimen.setBackground(Color.LIGHT_GRAY);
            }
        }
    }//GEN-LAST:event_jComboBox_FacturaActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentasEmpleados.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentasEmpleados.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentasEmpleados.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentasEmpleados.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentasEmpleados().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Agregar;
    private javax.swing.JButton jButton_Salir;
    private javax.swing.JButton jButton_Ticket;
    private javax.swing.JComboBox<String> jComboBox_CodigoProd;
    private javax.swing.JComboBox<String> jComboBox_Factura;
    private javax.swing.JComboBox<String> jComboBox_Regimen;
    private javax.swing.JLabel jLabel_CP;
    private javax.swing.JLabel jLabel_Cantidad;
    private javax.swing.JLabel jLabel_CodigoProd;
    private javax.swing.JLabel jLabel_Factura;
    private javax.swing.JLabel jLabel_Indicaciones;
    private javax.swing.JLabel jLabel_Nombre;
    private javax.swing.JLabel jLabel_PrecioU;
    private javax.swing.JLabel jLabel_Producto;
    private javax.swing.JLabel jLabel_RFC;
    private javax.swing.JLabel jLabel_Regimen;
    private javax.swing.JLabel jLabel_Titulo;
    private javax.swing.JLabel jLabel_Wallpaper;
    private javax.swing.JLabel jLabel_iconUser;
    private javax.swing.JLabel jLabel_logo;
    private javax.swing.JLabel jLabel_nameUser;
    private javax.swing.JLabel jLabel_numUser;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Factura;
    private javax.swing.JTextField jTextField_CP;
    private javax.swing.JTextField jTextField_Cantidad;
    private javax.swing.JTextField jTextField_Nombre;
    private javax.swing.JTextField jTextField_PrecioU;
    private javax.swing.JTextField jTextField_Producto;
    private javax.swing.JTextField jTextField_RFC;
    // End of variables declaration//GEN-END:variables
}
