package interfaces;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.Icon;
import ConexionBD.Conexion;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;

public class gestionarFacturas extends javax.swing.JFrame {

    String user;
    public static int IDcliente_update = 0;
    DefaultTableModel model = new DefaultTableModel();

    public gestionarFacturas() {
        initComponents();
        setSize(450, 520);
        setResizable(false);
        setTitle("Gestión de Proveedores");
        setLocationRelativeTo(null);

        ImageIcon wallpaper = new ImageIcon("src/images/Fondo2.png");
        Icon icono = new ImageIcon(wallpaper.getImage().getScaledInstance(jLabel_Wallpaper.getWidth(), jLabel_Wallpaper.getHeight(), Image.SCALE_DEFAULT));
        jLabel_Wallpaper.setIcon(icono);
        this.repaint();

        ImageIcon wallpaper_logo = new ImageIcon("src/images/Logo.png");
        Icon icono_logo = new ImageIcon(wallpaper_logo.getImage().getScaledInstance(jLabel_logo.getWidth(), jLabel_logo.getHeight(), Image.SCALE_DEFAULT));
        jLabel_logo.setIcon(icono_logo);
        this.repaint();
    }

    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("images/Icono.png"));
        return retValue;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton_Salir = new javax.swing.JButton();
        jLabel_iconUser = new javax.swing.JLabel();
        jLabel_nameUser = new javax.swing.JLabel();
        jLabel_numUser = new javax.swing.JLabel();
        jLabel_logo = new javax.swing.JLabel();
        jLabel_Titulo = new javax.swing.JLabel();
        jTextField_CP = new javax.swing.JTextField();
        jTextField_Nombre = new javax.swing.JTextField();
        jTextField_RFC = new javax.swing.JTextField();
        JLabel_RFC = new javax.swing.JLabel();
        jLabel_Nombre = new javax.swing.JLabel();
        jLabel_CP = new javax.swing.JLabel();
        jLabel_Productos = new javax.swing.JLabel();
        jLabel_Regimen = new javax.swing.JLabel();
        jTextField_Regimen = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel_Factura = new javax.swing.JLabel();
        jLabel_Estado = new javax.swing.JLabel();
        jComboBox_Estado = new javax.swing.JComboBox<>();
        jTextField_Factura = new javax.swing.JTextField();
        jButton_Guardar = new javax.swing.JButton();
        jLabel_Wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton_Salir.setBackground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setForeground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerca 1.png"))); // NOI18N
        jButton_Salir.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Salir.setContentAreaFilled(false);
        jButton_Salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 20, 30, 30));

        jLabel_iconUser.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_iconUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/usuario 2.png"))); // NOI18N
        getContentPane().add(jLabel_iconUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 45, 45));

        jLabel_nameUser.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(jLabel_nameUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 130, 20));

        jLabel_numUser.setText("AQUI ESTA");
        getContentPane().add(jLabel_numUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, 130, 20));
        getContentPane().add(jLabel_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 20, 70, 70));

        jLabel_Titulo.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Titulo.setText("GESTION DE FACTURAS");
        getContentPane().add(jLabel_Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, 260, 20));

        jTextField_CP.setEditable(false);
        jTextField_CP.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_CP.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jTextField_CP.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_CP.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_CP.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_CP.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_CP, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 200, 110, 20));

        jTextField_Nombre.setEditable(false);
        jTextField_Nombre.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Nombre.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jTextField_Nombre.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Nombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Nombre.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Nombre.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 240, 20));

        jTextField_RFC.setEditable(false);
        jTextField_RFC.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_RFC.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jTextField_RFC.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_RFC.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_RFC.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_RFC.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_RFC, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 250, 110, 20));

        JLabel_RFC.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        JLabel_RFC.setText("RFC");
        getContentPane().add(JLabel_RFC, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 230, -1, -1));

        jLabel_Nombre.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Nombre.setText("Nombre o Denominación Social");
        getContentPane().add(jLabel_Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, 240, -1));

        jLabel_CP.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_CP.setText("Código Postal");
        getContentPane().add(jLabel_CP, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 180, -1, -1));

        jLabel_Productos.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Productos.setText("Productos");
        getContentPane().add(jLabel_Productos, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, -1, -1));

        jLabel_Regimen.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Regimen.setText("Régimen Fiscal");
        getContentPane().add(jLabel_Regimen, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, -1, -1));

        jTextField_Regimen.setEditable(false);
        jTextField_Regimen.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Regimen.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jTextField_Regimen.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Regimen.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Regimen.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Regimen.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Regimen, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 240, 20));

        jTextArea1.setEditable(false);
        jTextArea1.setBackground(new java.awt.Color(255, 255, 255));
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Times New Roman", 0, 10)); // NOI18N
        jTextArea1.setForeground(new java.awt.Color(0, 0, 0));
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 350, 380, 110));

        jLabel_Factura.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Factura.setText("¿Requiere Factura?");
        getContentPane().add(jLabel_Factura, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, -1, 20));

        jLabel_Estado.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Estado.setText("Estado");
        getContentPane().add(jLabel_Estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 130, -1, 20));

        jComboBox_Estado.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_Estado.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jComboBox_Estado.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_Estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pendiente", "Cancelada", "Emitida" }));
        jComboBox_Estado.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(60, 63, 65), new java.awt.Color(4, 4, 4), new java.awt.Color(60, 63, 65)));
        jComboBox_Estado.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jComboBox_Estado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_EstadoActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox_Estado, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 150, 90, 20));

        jTextField_Factura.setEditable(false);
        jTextField_Factura.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Factura.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jTextField_Factura.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Factura.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Factura.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Factura.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        getContentPane().add(jTextField_Factura, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, 110, 20));

        jButton_Guardar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Guardar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Guardar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/salvar (1).png"))); // NOI18N
        jButton_Guardar.setText("Guardar");
        jButton_Guardar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Guardar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_GuardarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 290, 105, 35));
        getContentPane().add(jLabel_Wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 450, 520));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SalirActionPerformed
        dispose();
        new gestionarVentas().setVisible(true);
    }//GEN-LAST:event_jButton_SalirActionPerformed

    private void jComboBox_EstadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_EstadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox_EstadoActionPerformed

    private void jButton_GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_GuardarActionPerformed
        //Para esta interfaz solo se debe guardar el combobox de estado, y no podra cambiarse
    }//GEN-LAST:event_jButton_GuardarActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(gestionarFacturas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(gestionarFacturas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(gestionarFacturas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(gestionarFacturas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new gestionarFacturas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel JLabel_RFC;
    private javax.swing.JButton jButton_Guardar;
    private javax.swing.JButton jButton_Salir;
    private javax.swing.JComboBox<String> jComboBox_Estado;
    private javax.swing.JLabel jLabel_CP;
    private javax.swing.JLabel jLabel_Estado;
    private javax.swing.JLabel jLabel_Factura;
    private javax.swing.JLabel jLabel_Nombre;
    private javax.swing.JLabel jLabel_Productos;
    private javax.swing.JLabel jLabel_Regimen;
    private javax.swing.JLabel jLabel_Titulo;
    private javax.swing.JLabel jLabel_Wallpaper;
    private javax.swing.JLabel jLabel_iconUser;
    private javax.swing.JLabel jLabel_logo;
    private javax.swing.JLabel jLabel_nameUser;
    private javax.swing.JLabel jLabel_numUser;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField_CP;
    private javax.swing.JTextField jTextField_Factura;
    private javax.swing.JTextField jTextField_Nombre;
    private javax.swing.JTextField jTextField_RFC;
    private javax.swing.JTextField jTextField_Regimen;
    // End of variables declaration//GEN-END:variables
}
