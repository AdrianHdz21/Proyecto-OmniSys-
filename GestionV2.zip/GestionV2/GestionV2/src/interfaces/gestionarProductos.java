package interfaces;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import ConexionBD.Conexion;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public final class gestionarProductos extends javax.swing.JFrame {
    String user;
    public static int IDProductos_update = 0;
    DefaultTableModel model = new DefaultTableModel();

    public gestionarProductos() {
        initComponents();
        cargarProductID();
        cargarProveedores();
        setSize(500, 550);
        setResizable(false);
        setTitle("Gestión de Prodductos");
        setLocationRelativeTo(null);

        ImageIcon wallpaper = new ImageIcon("src/images/Fondo2.png");
        Icon icono = new ImageIcon(wallpaper.getImage().getScaledInstance(jLabel_Wallpaper.getWidth(), jLabel_Wallpaper.getHeight(), Image.SCALE_DEFAULT));
        jLabel_Wallpaper.setIcon(icono);
        this.repaint();

        ImageIcon wallpaper_logo = new ImageIcon("src/images/Logo.png");
        Icon icono_logo = new ImageIcon(wallpaper_logo.getImage().getScaledInstance(jLabel_logo.getWidth(), jLabel_logo.getHeight(), Image.SCALE_DEFAULT));
        jLabel_logo.setIcon(icono_logo);
        this.repaint();
        
        //AQUI ME PELAS LA VERGA :)
        //ESTE CODIGO ES PARA LA TABLA 
        try {
            Connection HA = Conexion.conectar();
            PreparedStatement PHA = HA.prepareStatement("select * from Productos");
            ResultSet HA1 = PHA.executeQuery();
            
            jTable_Productos = new JTable(model);
            jScrollPane1.setViewportView(jTable_Productos);
            model.addColumn("ProductoID");
            model.addColumn("Nombre");
            model.addColumn("Precio");
            model.addColumn("Proveedor");
            model.addColumn("Existencia");

            while (HA1.next()) {
                Object[] fila = new Object[5];
                for (int i = 0; i < 5; i++) {
                    fila[i] = HA1.getObject(i + 1);
                }
                model.addRow(fila);

            }

        } catch (SQLException e) {
            System.err.println("Error en el llenado de las tablas");
        }

        jTable_Productos.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int fila_point = jTable_Productos.rowAtPoint(e.getPoint());
                int columna_point = 0;

                if (fila_point > -1) {
                    IDProductos_update = (int) model.getValueAt(fila_point, columna_point);

                }
            }
        });
                
        //AQUI TAMBIEN ME LA PELAS ---> OYE TRANQUILO VIEJO TE VOY ACUSAR CON FATIMA :(
        
        //Inicializacion del Listener para cargarinformacion en los Jtexfield y JComboBox
        jButton_Guardar.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
        // Obtén los elementos seleccionados en los JComboBox
        int codigoSeleccionado = Integer.parseInt(jComboBox_Codigo.getSelectedItem().toString());
        String proveedorSeleccionado = jComboBox_Proovedor.getSelectedItem().toString();

        // Realiza consultas a la base de datos para obtener la información correspondiente
            try {
                Connection conexion = Conexion.conectar();

                // Consulta para obtener el nombre, existencia y precio del producto
                PreparedStatement consultaProducto = conexion.prepareStatement("SELECT Nombre, Existencia, Precio FROM Productos WHERE ProductoID = ?");
                consultaProducto.setInt(1, codigoSeleccionado);
                ResultSet resultadoProducto = consultaProducto.executeQuery();
                if (resultadoProducto.next()) {
                    jTextField_Producto.setText(resultadoProducto.getString("Nombre"));
                    jTextField_Cantidad.setText(String.valueOf(resultadoProducto.getInt("Existencia")));
                    jTextField_PrecioU.setText(String.valueOf(resultadoProducto.getDouble("Precio")));
                }

                // Consulta para obtener el ID del proveedor
                PreparedStatement consultaProveedor = conexion.prepareStatement("SELECT ProveedorID FROM Proveedores WHERE Nombre = ?");
                consultaProveedor.setString(1, proveedorSeleccionado);
                ResultSet resultadoProveedor = consultaProveedor.executeQuery();
                if (resultadoProveedor.next()) {
                    jComboBox_Codigo.setSelectedItem(String.valueOf(resultadoProveedor.getInt("ProveedorID")));
                }
            } catch (SQLException e) {
                System.err.println("Error al obtener la información de la base de datos");
            }
        }
        });   

        jButton_Borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                // Obtén el ProductoID del JComboBox
                int productoID = Integer.parseInt(jComboBox_Codigo.getSelectedItem().toString());

                try {
                    // Crea una conexión a la base de datos
                    Connection conexion = Conexion.conectar();

                    // Prepara una consulta SQL para eliminar el producto con el ProductoID seleccionado
                    PreparedStatement consulta = conexion.prepareStatement("DELETE FROM Productos WHERE ProductoID = ?");

                    // Establece el ProductoID en la consulta
                    consulta.setInt(1, productoID);

                    // Ejecuta la consulta
                    int resultado = consulta.executeUpdate();

                    // Verifica si la consulta fue exitosa
                    if (resultado == 1) {
                        JOptionPane.showMessageDialog(null, "Producto eliminado exitosamente");
                    } else {
                        JOptionPane.showMessageDialog(null, "No se pudo eliminar el producto");
                    }
                } catch (SQLException e) {
                    System.err.println("Error al eliminar el producto de la base de datos");
                }
            }
        });
  
    }

        @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton_Salir = new javax.swing.JButton();
        jLabel_iconUser = new javax.swing.JLabel();
        jLabel_nameUser = new javax.swing.JLabel();
        jLabel_numUser = new javax.swing.JLabel();
        jLabel_logo = new javax.swing.JLabel();
        jTextField_Producto = new javax.swing.JTextField();
        jTextField_Cantidad = new javax.swing.JTextField();
        jTextField_PrecioU = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Productos = new javax.swing.JTable();
        jLabel_Codigo = new javax.swing.JLabel();
        jLabel_Producto = new javax.swing.JLabel();
        jLabel_Cantidad = new javax.swing.JLabel();
        jLabel_PrecioU = new javax.swing.JLabel();
        jButton_Guardar = new javax.swing.JButton();
        jLabel_Titulo = new javax.swing.JLabel();
        jComboBox_Codigo = new javax.swing.JComboBox<>();
        jLabel_Proveedor = new javax.swing.JLabel();
        jComboBox_Proovedor = new javax.swing.JComboBox<>();
        jButton_Actualizar = new javax.swing.JButton();
        jButton_Borrar = new javax.swing.JButton();
        jLabel_Wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton_Salir.setBackground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setForeground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerca 1.png"))); // NOI18N
        jButton_Salir.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Salir.setContentAreaFilled(false);
        jButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 20, 30, 30));

        jLabel_iconUser.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_iconUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/usuario 2.png"))); // NOI18N
        getContentPane().add(jLabel_iconUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 45, 45));

        jLabel_nameUser.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_nameUser.setText("ACA TAAMB");
        getContentPane().add(jLabel_nameUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 130, 20));

        jLabel_numUser.setText("AQUI ESTA");
        getContentPane().add(jLabel_numUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, 130, 20));
        getContentPane().add(jLabel_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, 70, 70));

        jTextField_Producto.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Producto.setFont(new java.awt.Font("Times New Roman", 0, 10)); // NOI18N
        jTextField_Producto.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Producto.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Producto.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Producto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_ProductoActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, 200, 30));

        jTextField_Cantidad.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Cantidad.setFont(new java.awt.Font("Times New Roman", 0, 10)); // NOI18N
        jTextField_Cantidad.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Cantidad.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Cantidad.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_Cantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_CantidadActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField_Cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 230, 120, 30));

        jTextField_PrecioU.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_PrecioU.setFont(new java.awt.Font("Times New Roman", 0, 10)); // NOI18N
        jTextField_PrecioU.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_PrecioU.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_PrecioU.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        jTextField_PrecioU.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField_PrecioUActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField_PrecioU, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 170, 100, 30));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jScrollPane1.setForeground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setFont(new java.awt.Font("Times New Roman", 1, 10)); // NOI18N

        jTable_Productos.setBackground(new java.awt.Color(102, 102, 102));
        jTable_Productos.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2)));
        jTable_Productos.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jTable_Productos.setForeground(new java.awt.Color(0, 0, 0));
        jTable_Productos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ProductoID", "Nombre", "Precio", "Proveedor", "Existencia"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable_Productos);
        if (jTable_Productos.getColumnModel().getColumnCount() > 0) {
            jTable_Productos.getColumnModel().getColumn(0).setResizable(false);
            jTable_Productos.getColumnModel().getColumn(2).setResizable(false);
            jTable_Productos.getColumnModel().getColumn(3).setResizable(false);
            jTable_Productos.getColumnModel().getColumn(4).setResizable(false);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 350, 410, 120));

        jLabel_Codigo.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Codigo.setText("Código Producto");
        getContentPane().add(jLabel_Codigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, -1, -1));

        jLabel_Producto.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Producto.setText("Nombre Producto");
        getContentPane().add(jLabel_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 210, -1, 20));

        jLabel_Cantidad.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Cantidad.setText("Precio Unitario");
        getContentPane().add(jLabel_Cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 150, -1, -1));

        jLabel_PrecioU.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_PrecioU.setText("Existencia");
        getContentPane().add(jLabel_PrecioU, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 210, -1, 20));

        jButton_Guardar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Guardar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Guardar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/salvar (1).png"))); // NOI18N
        jButton_Guardar.setText("Cargar Datos");
        jButton_Guardar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_GuardarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 280, 105, 35));

        jLabel_Titulo.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Titulo.setText("GESTION DE PRODUCTOS");
        getContentPane().add(jLabel_Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, 250, 20));

        jComboBox_Codigo.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_Codigo.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jComboBox_Codigo.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_Codigo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox_Codigo.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(60, 63, 65), new java.awt.Color(4, 4, 4), new java.awt.Color(60, 63, 65)));
        jComboBox_Codigo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jComboBox_Codigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_CodigoActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox_Codigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 170, 110, -1));

        jLabel_Proveedor.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Proveedor.setText("Código Proveedor");
        getContentPane().add(jLabel_Proveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, -1, -1));

        jComboBox_Proovedor.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_Proovedor.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jComboBox_Proovedor.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_Proovedor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox_Proovedor.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(60, 63, 65), new java.awt.Color(4, 4, 4), new java.awt.Color(60, 63, 65)));
        jComboBox_Proovedor.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jComboBox_Proovedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox_ProovedorActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox_Proovedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 170, 110, -1));

        jButton_Actualizar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Actualizar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Actualizar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Actualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/actualizar.png"))); // NOI18N
        jButton_Actualizar.setText("Actualizar");
        jButton_Actualizar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Actualizar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_ActualizarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 280, 105, 35));

        jButton_Borrar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Borrar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Borrar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Borrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/borrar.png"))); // NOI18N
        jButton_Borrar.setText("Eliminar");
        jButton_Borrar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Borrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_BorrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Borrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 280, 105, 35));
        getContentPane().add(jLabel_Wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 500, 550));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //Metodo para actualizar los productos de la tabla 
    public void actualizarProducto(int idProducto, String nombre, double precio, String proveedor, int existencia) {
    try {
        Connection conn = Conexion.conectar();
        String query = "UPDATE Productos SET Nombre = ?, Precio = ?, Proveedor = ?, Existencia = ? WHERE ProductoID = ?";
        PreparedStatement pstmt = conn.prepareStatement(query);
        pstmt.setString(1, nombre);
        pstmt.setDouble(2, precio);
        pstmt.setString(3, proveedor);
        pstmt.setInt(4, existencia);
        pstmt.setInt(5, idProducto);
        pstmt.executeUpdate();
    } catch (SQLException e) {
        System.err.println("Error al actualizar el producto");
    }
}
    
    //Realiza una consulta a la BD recupera los ID de los productos
    public void cargarProductID() {
    try {
        Connection conn = Conexion.conectar();
        String query = "SELECT ProductoID FROM Productos";
        PreparedStatement pstmt = conn.prepareStatement(query);
        
        ResultSet rs = pstmt.executeQuery();
        
        // Limpiar el jComboBox antes de agregar los elementos
        jComboBox_Codigo.removeAllItems();

        while (rs.next()) {
            jComboBox_Codigo.addItem(rs.getString("ProductoID"));
        }
    } catch (SQLException e) {
        System.err.println("Error al cargar los ProductID");
    }
}
    
    //Realiza una consulta a la BD recupera los Nombres de los proveedores
    public void cargarProveedores() {
        try {
            Connection con = Conexion.conectar();
            PreparedStatement pst = con.prepareStatement("SELECT Nombre FROM Proveedores");

            ResultSet rs = pst.executeQuery();
            
            // Limpiar el jComboBox antes de agregar los elementos
            jComboBox_Proovedor.removeAllItems();

            while (rs.next()) {
                jComboBox_Proovedor.addItem(rs.getString("Nombre"));
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar los proveedores");
        }
    }
    
    public void actualizarProducto() {
        try {
            Connection conn = Conexion.conectar();
            String query = "UPDATE Productos SET Nombre = ?, Precio = ?, Proveedor = ?, Existencia = ? WHERE ProductoID = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);

            pstmt.setString(1, jTextField_Producto.getText());
            pstmt.setDouble(2, Double.parseDouble(jTextField_PrecioU.getText()));
            pstmt.setString(3, (String) jComboBox_Proovedor.getSelectedItem());
            pstmt.setInt(4, Integer.parseInt(jTextField_Cantidad.getText()));
            pstmt.setInt(5, Integer.parseInt((String) jComboBox_Codigo.getSelectedItem()));

            pstmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Producto actualizado correctamente");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar el producto");
        }
    }
    
    ////////////////////////////////////////////////
    
    private void jButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SalirActionPerformed
        dispose();
        new administrador().setVisible(true);
    }//GEN-LAST:event_jButton_SalirActionPerformed

    private void jComboBox_CodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_CodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox_CodigoActionPerformed

    private void jComboBox_ProovedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox_ProovedorActionPerformed
        
    }//GEN-LAST:event_jComboBox_ProovedorActionPerformed

    private void jButton_ActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_ActualizarActionPerformed
        // Llama a la función actualizarProducto() cuando se presione el botón
        actualizarProducto();
    }//GEN-LAST:event_jButton_ActualizarActionPerformed

    private void jButton_BorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_BorrarActionPerformed
        
    }//GEN-LAST:event_jButton_BorrarActionPerformed

    
    private void jTextField_ProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_ProductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_ProductoActionPerformed
    
    private void jTextField_PrecioUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_PrecioUActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_PrecioUActionPerformed

    private void jTextField_CantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField_CantidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField_CantidadActionPerformed

    private void jButton_GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_GuardarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton_GuardarActionPerformed

    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("images/Icono.png"));
        return retValue;
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(gestionarProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(gestionarProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(gestionarProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(gestionarProductos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new gestionarProductos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Actualizar;
    private javax.swing.JButton jButton_Borrar;
    private javax.swing.JButton jButton_Guardar;
    private javax.swing.JButton jButton_Salir;
    private javax.swing.JComboBox<String> jComboBox_Codigo;
    private javax.swing.JComboBox<String> jComboBox_Proovedor;
    private javax.swing.JLabel jLabel_Cantidad;
    private javax.swing.JLabel jLabel_Codigo;
    private javax.swing.JLabel jLabel_PrecioU;
    private javax.swing.JLabel jLabel_Producto;
    private javax.swing.JLabel jLabel_Proveedor;
    private javax.swing.JLabel jLabel_Titulo;
    private javax.swing.JLabel jLabel_Wallpaper;
    private javax.swing.JLabel jLabel_iconUser;
    private javax.swing.JLabel jLabel_logo;
    private javax.swing.JLabel jLabel_nameUser;
    private javax.swing.JLabel jLabel_numUser;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Productos;
    private javax.swing.JTextField jTextField_Cantidad;
    private javax.swing.JTextField jTextField_PrecioU;
    private javax.swing.JTextField jTextField_Producto;
    // End of variables declaration//GEN-END:variables
}
