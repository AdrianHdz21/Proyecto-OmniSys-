package interfaces;

import java.awt.Image;
import java.awt.Toolkit;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class administrador extends javax.swing.JFrame {

    public administrador() {
        initComponents();
        setSize(600, 330);
        setResizable(false);
        setTitle("Menu Gerente");
        setLocationRelativeTo(null);

        ImageIcon wallpaper = new ImageIcon("src/images/Fondo2.png");
        Icon icono = new ImageIcon(wallpaper.getImage().getScaledInstance(jLabel_Wallpaper.getWidth(), jLabel_Wallpaper.getHeight(), Image.SCALE_DEFAULT));
        jLabel_Wallpaper.setIcon(icono);
        this.repaint();

        ImageIcon wallpaper_logo = new ImageIcon("src/images/Logo.png");
        Icon icono_logo = new ImageIcon(wallpaper_logo.getImage().getScaledInstance(jLabel_logo.getWidth(), jLabel_logo.getHeight(), Image.SCALE_DEFAULT));
        jLabel_logo.setIcon(icono_logo);
        this.repaint();
    }

    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("images/Icono.png"));
        return retValue;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel_Opciones = new javax.swing.JLabel();
        jButton_Proveedores = new javax.swing.JButton();
        jLabel_Empleados = new javax.swing.JLabel();
        jLabel_Productos = new javax.swing.JLabel();
        jButton_Empleados = new javax.swing.JButton();
        jButton_Ventas = new javax.swing.JButton();
        jLabel_Ventas = new javax.swing.JLabel();
        jLabel_Proveedores = new javax.swing.JLabel();
        jLabel_Titulo = new javax.swing.JLabel();
        jLabel_logo = new javax.swing.JLabel();
        jButton_Productos = new javax.swing.JButton();
        jButton_Salir = new javax.swing.JButton();
        jLabel_Wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel_Opciones.setBackground(new java.awt.Color(68, 109, 133));
        jLabel_Opciones.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        jLabel_Opciones.setForeground(new java.awt.Color(0, 0, 255));
        jLabel_Opciones.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Opciones.setText("MENU GERENTES");
        getContentPane().add(jLabel_Opciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 90, 200, -1));

        jButton_Proveedores.setBackground(new java.awt.Color(0, 235, 255));
        jButton_Proveedores.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/repartidor 1.png"))); // NOI18N
        jButton_Proveedores.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Proveedores.setContentAreaFilled(false);
        jButton_Proveedores.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Proveedores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_ProveedoresActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Proveedores, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 150, 90, 90));

        jLabel_Empleados.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel_Empleados.setForeground(new java.awt.Color(0, 0, 204));
        jLabel_Empleados.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Empleados.setText("Empleados");
        getContentPane().add(jLabel_Empleados, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 250, 70, -1));

        jLabel_Productos.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel_Productos.setForeground(new java.awt.Color(0, 0, 204));
        jLabel_Productos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Productos.setText("Productos");
        getContentPane().add(jLabel_Productos, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 250, 70, -1));

        jButton_Empleados.setBackground(new java.awt.Color(0, 235, 255));
        jButton_Empleados.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/usuario 1.png"))); // NOI18N
        jButton_Empleados.setBorder(javax.swing.BorderFactory.createEmptyBorder(-10, -10, -10, -10));
        jButton_Empleados.setBorderPainted(false);
        jButton_Empleados.setContentAreaFilled(false);
        jButton_Empleados.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Empleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_EmpleadosActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Empleados, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, 90, 90));

        jButton_Ventas.setBackground(new java.awt.Color(0, 235, 255));
        jButton_Ventas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/carrito 1.png"))); // NOI18N
        jButton_Ventas.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Ventas.setContentAreaFilled(false);
        jButton_Ventas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Ventas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_VentasActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Ventas, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 150, 90, 90));

        jLabel_Ventas.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel_Ventas.setForeground(new java.awt.Color(0, 0, 204));
        jLabel_Ventas.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Ventas.setText("Ventas");
        getContentPane().add(jLabel_Ventas, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 250, 70, -1));

        jLabel_Proveedores.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel_Proveedores.setForeground(new java.awt.Color(0, 0, 204));
        jLabel_Proveedores.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Proveedores.setText("Proveedores");
        getContentPane().add(jLabel_Proveedores, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 250, 70, -1));

        jLabel_Titulo.setFont(new java.awt.Font("Times New Roman", 3, 10)); // NOI18N
        jLabel_Titulo.setForeground(new java.awt.Color(0, 0, 204));
        jLabel_Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Titulo.setText("SELECCIONA UNA OPCION");
        getContentPane().add(jLabel_Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 120, 180, -1));
        getContentPane().add(jLabel_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 10, 70, 70));

        jButton_Productos.setBackground(new java.awt.Color(0, 235, 255));
        jButton_Productos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/producto 1.png"))); // NOI18N
        jButton_Productos.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Productos.setContentAreaFilled(false);
        jButton_Productos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Productos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_ProductosActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Productos, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, 90, 90));

        jButton_Salir.setBackground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setForeground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerca 1.png"))); // NOI18N
        jButton_Salir.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Salir.setContentAreaFilled(false);
        jButton_Salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 10, 30, 30));

        jLabel_Wallpaper.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().add(jLabel_Wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 330));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_ProveedoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_ProveedoresActionPerformed
        dispose();
        new gestionarProveedores().setVisible(true);
    }//GEN-LAST:event_jButton_ProveedoresActionPerformed

    private void jButton_EmpleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_EmpleadosActionPerformed
        dispose();
        new gestionarEmpleados().setVisible(true);
    }//GEN-LAST:event_jButton_EmpleadosActionPerformed

    private void jButton_VentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_VentasActionPerformed
        dispose();
        new gestionarVentas().setVisible(true);
    }//GEN-LAST:event_jButton_VentasActionPerformed

    private void jButton_ProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_ProductosActionPerformed
        dispose();
        new gestionarProductos().setVisible(true);
    }//GEN-LAST:event_jButton_ProductosActionPerformed

    private void jButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SalirActionPerformed
        dispose();
        new ingreso().setVisible(true);
    }//GEN-LAST:event_jButton_SalirActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(administrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(administrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(administrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(administrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new administrador().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Empleados;
    private javax.swing.JButton jButton_Productos;
    private javax.swing.JButton jButton_Proveedores;
    private javax.swing.JButton jButton_Salir;
    private javax.swing.JButton jButton_Ventas;
    private javax.swing.JLabel jLabel_Empleados;
    private javax.swing.JLabel jLabel_Opciones;
    private javax.swing.JLabel jLabel_Productos;
    private javax.swing.JLabel jLabel_Proveedores;
    private javax.swing.JLabel jLabel_Titulo;
    private javax.swing.JLabel jLabel_Ventas;
    private javax.swing.JLabel jLabel_Wallpaper;
    private javax.swing.JLabel jLabel_logo;
    // End of variables declaration//GEN-END:variables
}
