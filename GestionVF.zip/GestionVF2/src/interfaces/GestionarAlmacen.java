package interfaces;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import ConexionBD.Conexion;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public final class GestionarAlmacen extends javax.swing.JFrame {

    public static int IDProductos_update;
    DefaultTableModel model = new DefaultTableModel();

    public GestionarAlmacen() {
        initComponents();
        setSize(600, 550);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);  //Hace que la ventana no se cierre
        setResizable(false);
        setTitle("Gestión de Almacen");
        setLocationRelativeTo(null);

        jLabel_nameUser.setText("Nom Emp: " + Ingreso.nomEmpleado);
        jLabel_numUser.setText("Núm Emp: " + Ingreso.numEmpleado);

        jButton_Actualizar.setEnabled(false);
        jButton_Borrar.setEnabled(false);

        cargarDatosTabla();
        cargarProveedores();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField_Producto = new javax.swing.JTextField();
        jTextField_Cantidad = new javax.swing.JTextField();
        jTextField_PrecioU = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Productos = new javax.swing.JTable();
        jLabel_Producto = new javax.swing.JLabel();
        jLabel_Cantidad = new javax.swing.JLabel();
        jLabel_PrecioU = new javax.swing.JLabel();
        jButton_Guardar = new javax.swing.JButton();
        jLabel_Titulo = new javax.swing.JLabel();
        jButton_Actualizar = new javax.swing.JButton();
        jButton_Borrar = new javax.swing.JButton();
        jLabel_Proveedor = new javax.swing.JLabel();
        jComboBox_Proveedor = new javax.swing.JComboBox<>();
        jLabel_iconUser = new javax.swing.JLabel();
        jLabel_logo = new javax.swing.JLabel();
        jButton_Salir = new javax.swing.JButton();
        jLabel_nameUser = new javax.swing.JLabel();
        jLabel_numUser = new javax.swing.JLabel();
        jTextField_PrecioV = new javax.swing.JTextField();
        jLabel_PrecioV = new javax.swing.JLabel();
        jLabel_Indicaciones = new javax.swing.JLabel();
        jLabel_Wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField_Producto.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Producto.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_Producto.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Producto.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Producto.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        getContentPane().add(jTextField_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, 250, 20));

        jTextField_Cantidad.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_Cantidad.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_Cantidad.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_Cantidad.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_Cantidad.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        getContentPane().add(jTextField_Cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, 120, 20));

        jTextField_PrecioU.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_PrecioU.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_PrecioU.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_PrecioU.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_PrecioU.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        getContentPane().add(jTextField_PrecioU, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 170, 110, 20));

        jScrollPane1.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jScrollPane1.setForeground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setFont(new java.awt.Font("Times New Roman", 1, 10)); // NOI18N

        jTable_Productos.setBackground(new java.awt.Color(255, 255, 255));
        jTable_Productos.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2), new java.awt.Color(2, 2, 2)));
        jTable_Productos.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 10)); // NOI18N
        jTable_Productos.setForeground(new java.awt.Color(0, 0, 0));
        jTable_Productos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTable_Productos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jScrollPane1.setViewportView(jTable_Productos);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 360, 510, 120));

        jLabel_Producto.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Producto.setText("Nombre Producto");
        getContentPane().add(jLabel_Producto, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 150, -1, 20));

        jLabel_Cantidad.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Cantidad.setText("Precio Unitario");
        getContentPane().add(jLabel_Cantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 150, 70, -1));

        jLabel_PrecioU.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_PrecioU.setText("Existencia Comprada");
        getContentPane().add(jLabel_PrecioU, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, 110, 20));

        jButton_Guardar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Guardar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Guardar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Guardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/salvar (1).png"))); // NOI18N
        jButton_Guardar.setText("Cargar Datos");
        jButton_Guardar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Guardar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_GuardarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Guardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 290, 105, 35));

        jLabel_Titulo.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel_Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Titulo.setText("GESTION DE ALMACEN");
        getContentPane().add(jLabel_Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 100, 250, 20));

        jButton_Actualizar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Actualizar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Actualizar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Actualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/actualizar.png"))); // NOI18N
        jButton_Actualizar.setText("Actualizar");
        jButton_Actualizar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Actualizar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_ActualizarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Actualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 290, 105, 35));

        jButton_Borrar.setBackground(new java.awt.Color(19, 36, 145));
        jButton_Borrar.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 12)); // NOI18N
        jButton_Borrar.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Borrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/borrar.png"))); // NOI18N
        jButton_Borrar.setText("Eliminar");
        jButton_Borrar.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(0, 235, 255), new java.awt.Color(0, 235, 255)));
        jButton_Borrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Borrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_BorrarActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Borrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 290, 105, 35));

        jLabel_Proveedor.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_Proveedor.setText("Nombre Proveedor");
        getContentPane().add(jLabel_Proveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 210, -1, 20));

        jComboBox_Proveedor.setBackground(new java.awt.Color(255, 255, 255));
        jComboBox_Proveedor.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jComboBox_Proveedor.setForeground(new java.awt.Color(0, 0, 0));
        jComboBox_Proveedor.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.black, java.awt.Color.black));
        jComboBox_Proveedor.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        getContentPane().add(jComboBox_Proveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 230, 250, 20));

        jLabel_iconUser.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_iconUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/usuario 2.png"))); // NOI18N
        getContentPane().add(jLabel_iconUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 60, 60));

        jLabel_logo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Logo 2.png"))); // NOI18N
        getContentPane().add(jLabel_logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, 70, 70));

        jButton_Salir.setBackground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setForeground(new java.awt.Color(60, 63, 65));
        jButton_Salir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerca 1.png"))); // NOI18N
        jButton_Salir.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        jButton_Salir.setContentAreaFilled(false);
        jButton_Salir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_SalirActionPerformed(evt);
            }
        });
        getContentPane().add(jButton_Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 20, 60, 60));

        jLabel_nameUser.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel_nameUser.setForeground(new java.awt.Color(19, 36, 145));
        getContentPane().add(jLabel_nameUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 30, 150, 20));

        jLabel_numUser.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        jLabel_numUser.setForeground(new java.awt.Color(19, 36, 145));
        getContentPane().add(jLabel_numUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 50, 150, 20));

        jTextField_PrecioV.setBackground(new java.awt.Color(255, 255, 255));
        jTextField_PrecioV.setFont(new java.awt.Font("Tw Cen MT Condensed", 0, 12)); // NOI18N
        jTextField_PrecioV.setForeground(new java.awt.Color(0, 0, 0));
        jTextField_PrecioV.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField_PrecioV.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(4, 4, 4), new java.awt.Color(4, 4, 4)));
        getContentPane().add(jTextField_PrecioV, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 170, 120, 20));

        jLabel_PrecioV.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 12)); // NOI18N
        jLabel_PrecioV.setText("Precio De Venta");
        getContentPane().add(jLabel_PrecioV, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 150, 80, 20));

        jLabel_Indicaciones.setFont(new java.awt.Font("Times New Roman", 3, 10)); // NOI18N
        jLabel_Indicaciones.setForeground(new java.awt.Color(19, 36, 145));
        jLabel_Indicaciones.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Indicaciones.setText("PARA REGISTRAR O MODIFICAR ALGÚN PRODUCTO, COMPLETE LOS CAMPOS REQUERIDOS.");
        getContentPane().add(jLabel_Indicaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, 460, 10));

        jLabel_Wallpaper.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel_Wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Fondo2.png"))); // NOI18N
        jLabel_Wallpaper.setLabelFor(jLabel_Wallpaper);
        getContentPane().add(jLabel_Wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 550));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void cargarDatosTabla() {
        try {
            // Establece la conexión a la base de datos
            Connection conn = Conexion.conectar();

            // Prepara la consulta SQL para obtener los datos de los productos y sus proveedores
            PreparedStatement stmt = conn.prepareStatement("SELECT ProductoID, Productos.Nombre AS NomProducto, PrecioUnitario,PrecioVenta, ExistenciaTotal,ExistenciaVendida,ExistenciaActual, Proveedores.Nombre AS NomProveedor FROM Productos"
                    + " INNER JOIN Proveedores ON Productos.ProveedorID = Proveedores.ProveedorID");
            ResultSet rs = stmt.executeQuery();

            // Configura el modelo de la tabla
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("ProductoID");
            model.addColumn("Nom Prod");
            model.addColumn("Prec Uni");
            model.addColumn("Prec Ven");
            model.addColumn("Exis Com");
            model.addColumn("Exis Ven");
            model.addColumn("Exis Act");
            model.addColumn("Nom Prov");

            // Llena el modelo con los datos obtenidos de la base de datos
            while (rs.next()) {
                Object[] fila = new Object[8];
                for (int i = 0; i < 8; i++) {
                    fila[i] = rs.getObject(i + 1);
                }
                model.addRow(fila);
            }

            // Establece el modelo en la tabla de productos
            jTable_Productos.setModel(model);

            // Hace que la tabla no sea editable
            jTable_Productos.setDefaultEditor(Object.class, null);

            // Cierra los recursos
            rs.close();
            stmt.close();
            conn.close();

        } catch (SQLException ex) {
            // Si ocurre un error durante la consulta, muestra un mensaje de error
            JOptionPane.showMessageDialog(null, "Error en el llenado de las tablas: " + ex.getMessage());
        }

        jTable_Productos.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    int fila_point = jTable_Productos.rowAtPoint(e.getPoint());
                    if (fila_point > -1) {
                        jButton_Actualizar.setEnabled(true); // Habilita el botón de actualizar
                        jButton_Borrar.setEnabled(true); // Habilita el botón de borrar
                        jButton_Guardar.setEnabled(false); // Deshabilita el botón de guardar

                        // Obtener el ProductoID de la fila seleccionada
                        IDProductos_update = (int) jTable_Productos.getValueAt(fila_point, 0);

                        // Realiza una consulta para recuperar los datos del producto y su proveedor de acuerdo al ID y los coloca en los campos correspondientes
                        try {
                            Connection conn = Conexion.conectar();
                            PreparedStatement stmt = conn.prepareStatement("SELECT ProductoID, Productos.Nombre AS NomProducto, PrecioUnitario, PrecioVenta, ExistenciaTotal, ExistenciaVendida, ExistenciaActual, Proveedores.Nombre AS NomProveedor FROM Productos INNER JOIN Proveedores ON Productos.ProveedorID = Proveedores.ProveedorID WHERE ProductoID = ?");
                            stmt.setInt(1, IDProductos_update);
                            ResultSet rs = stmt.executeQuery();

                            // Verificar si la consulta SQL devuelve resultados
                            if (rs.next()) {
                                // Mapear los resultados a los campos correspondientes
                                jTextField_Producto.setText(rs.getString("NomProducto"));
                                jTextField_PrecioU.setText(rs.getString("PrecioUnitario"));
                                jTextField_PrecioV.setText(rs.getString("PrecioVenta"));
                                jComboBox_Proveedor.setSelectedItem(rs.getString("NomProveedor"));
                            } else {
                                // Si la consulta no devuelve resultados, mostrar un mensaje de error
                                JOptionPane.showMessageDialog(null, "No se encontraron datos para el ProductoID seleccionado.");
                            }

                            // Cierra los recursos
                            rs.close();
                            stmt.close();
                            conn.close();
                        } catch (SQLException ex) {
                            // Si ocurre un error durante la consulta, muestra un mensaje de error
                            JOptionPane.showMessageDialog(null, "Error al cargar, contactar al administrador");
                            ex.printStackTrace(); // Imprimir el rastreo de la pila para depuración
                        }
                    }
                } catch (Exception ex) {
                    // Captura cualquier excepción no controlada y muestra el mensaje de error
                    JOptionPane.showMessageDialog(null, "Error inesperado: " + ex.getMessage());
                    ex.printStackTrace(); // Imprimir el rastreo de la pila para depuración
                }
            }
        });

    }

    private void jButton_ActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_ActualizarActionPerformed
        try {
            // Obtener los valores de los campos
            String nombreProveedor = (String) jComboBox_Proveedor.getSelectedItem();
            int existenciaA = Integer.parseInt(jTextField_Cantidad.getText().trim());
            double precioU = Double.parseDouble(jTextField_PrecioU.getText().trim());
            double precioV = Double.parseDouble(jTextField_PrecioV.getText().trim());
            String nombreProducto = jTextField_Producto.getText().trim();

            // Validar los campos
            if (nombreProveedor.isEmpty() || existenciaA <= 0 || precioU <= 0.0 || precioV <= 0.0 || nombreProducto.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos correctamente", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                try {
                    // Establecer la conexión
                    Connection conn = Conexion.conectar();

                    // Obtener el valor actual de existenciaComprada
                    String selectQuery = "SELECT ExistenciaTotal, ExistenciaActual FROM Productos WHERE ProductoID = ?";
                    PreparedStatement selectStmt = conn.prepareStatement(selectQuery);
                    selectStmt.setInt(1, IDProductos_update);

                    ResultSet rs = selectStmt.executeQuery();

                    if (rs.next()) {
                        int existenciaCActual = rs.getInt("ExistenciaTotal");
                        int existenciaANueva = rs.getInt("ExistenciaActual");

                        // Sumar el nuevo valor al valor existente de existenciaTotal
                        int nuevaExistenciaC = existenciaCActual + existenciaA;
                        int nuevaExistenciaA = existenciaANueva + existenciaA;

                        // Preparar la consulta SQL para la actualización
                        String updateQuery = "UPDATE Productos SET Nombre = ?, PrecioUnitario = ?, PrecioVenta = ?, ExistenciaActual = ?, ExistenciaTotal = ? WHERE ProductoID = ?";
                        PreparedStatement pstmt = conn.prepareStatement(updateQuery);
                        pstmt.setString(1, nombreProducto);
                        pstmt.setDouble(2, precioU);
                        pstmt.setDouble(3, precioV);
                        pstmt.setInt(4, nuevaExistenciaA);
                        pstmt.setInt(5, nuevaExistenciaC);
                        pstmt.setInt(6, IDProductos_update);

                        // Ejecutar la actualización
                        int filasActualizadas = pstmt.executeUpdate();

                        // Cerrar recursos
                        pstmt.close();
                        conn.close();

                        // Verificar si se actualizaron filas
                        if (filasActualizadas > 0) {
                            dispose();
                            JOptionPane.showMessageDialog(null, "Modificación exitosa", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                            new GestionarAlmacen().setVisible(true);
                        } else {
                            JOptionPane.showMessageDialog(null, "No se encontró ningún producto con el ID proporcionado", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No se encontró ningún producto con el ID proporcionado", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                    // Cerrar recursos
                    rs.close();
                    selectStmt.close();
                } catch (SQLException e) {
                    // Mostrar mensaje de error en caso de excepción
                    JOptionPane.showMessageDialog(null, "Error al actualizar el producto: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Cantidad, Precio Unitario y Precio Venta deben ser valores numéricos y mayores que 0.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jButton_ActualizarActionPerformed

    //Realiza una consulta a la BD recupera los Nombres de los proveedores
    public void cargarProveedores() {
        try {
            Connection con = Conexion.conectar();
            PreparedStatement pst = con.prepareStatement("SELECT Nombre FROM Proveedores");

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                jComboBox_Proveedor.addItem(rs.getString("Nombre"));
            }

            rs.close();
            pst.close();
            con.close();
        } catch (SQLException e) {
            System.err.println("Error al cargar los proveedores");
        }

    }

    private void jButton_BorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_BorrarActionPerformed
        try ( Connection conn = Conexion.conectar()) {
            // Prepara una consulta SQL para eliminar el producto con el ProductoID seleccionado
            String sql = "DELETE FROM Productos WHERE ProductoID = ?";
            try ( PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, IDProductos_update);

                int rowsDeleted = stmt.executeUpdate();

                if (rowsDeleted > 0) {
                    dispose();
                    JOptionPane.showMessageDialog(null, "Registro eliminado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    new GestionarAlmacen().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "No se encontró ningún registro para eliminar.", "Verificar", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar el registro: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton_BorrarActionPerformed

    private void jButton_GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_GuardarActionPerformed
// Obtener los valores de los campos
        String proveedor = (String) jComboBox_Proveedor.getSelectedItem();
        String cantidad = jTextField_Cantidad.getText().trim();
        String nombreProducto = jTextField_Producto.getText().trim();
        String precioU = jTextField_PrecioU.getText().trim();
        String precioV = jTextField_PrecioV.getText().trim();

// Validar que no haya campos vacíos y que los valores numéricos sean válidos
        if (proveedor.isEmpty() || cantidad.isEmpty() || nombreProducto.isEmpty() || precioU.isEmpty() || precioV.isEmpty()
                || !cantidad.matches("\\d+") || !precioU.matches("^\\d*\\.?\\d+$") || !precioV.matches("^\\d*\\.?\\d+$")
                || Integer.parseInt(cantidad) <= 0 || Double.parseDouble(precioU) <= 0 || Double.parseDouble(precioV) <= 0) {
            String mensaje = "Por favor complete todos los campos obligatorios con valores válidos:\n";
            if (proveedor.isEmpty()) {
                mensaje += "- Proveedor\n";
            }
            if (cantidad.isEmpty() || !cantidad.matches("\\d+") || Integer.parseInt(cantidad) <= 0) {
                mensaje += "- Cantidad (debe ser un número entero positivo mayor que 0)\n";
            }
            if (nombreProducto.isEmpty()) {
                mensaje += "- Nombre del producto\n";
            }
            if (precioU.isEmpty() || !precioU.matches("^\\d*\\.?\\d+$") || Double.parseDouble(precioU) <= 0) {
                mensaje += "- Precio unitario (debe ser un número decimal positivo mayor que 0)\n";
            }
            if (precioV.isEmpty() || !precioV.matches("^\\d*\\.?\\d+$") || Double.parseDouble(precioV) <= 0) {
                mensaje += "- Precio de venta (debe ser un número decimal positivo mayor que 0)\n";
            }
            JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            // Validar que cantidad, precioU y precioV sean valores numéricos
            try {
                int cantidadInt = Integer.parseInt(cantidad);
                double precioUnitario = Double.parseDouble(precioU);
                double precioVenta = Double.parseDouble(precioV);

                // Establecer conexión a la base de datos
                try ( Connection conn = Conexion.conectar()) {
                    // Obtener el ID del proveedor
                    int proveedorID = -1;
                    String query = "SELECT ProveedorID FROM Proveedores WHERE Nombre = ?";
                    try ( PreparedStatement pstmt = conn.prepareStatement(query)) {
                        pstmt.setString(1, proveedor);
                        try ( ResultSet rs = pstmt.executeQuery()) {
                            if (rs.next()) {
                                proveedorID = rs.getInt("ProveedorID");
                            }
                        }
                    }

                    // Verificar si se encontró el proveedor
                    if (proveedorID != -1) {
                        // Obtener el valor actual de ExistenciaTotal
                        int existenciaTotalActual = 0;
                        String selectQuery = "SELECT ExistenciaTotal FROM Productos WHERE Nombre = ? AND ProveedorID = ?";
                        try ( PreparedStatement selectStmt = conn.prepareStatement(selectQuery)) {
                            selectStmt.setString(1, nombreProducto);
                            selectStmt.setInt(2, proveedorID);
                            try ( ResultSet rs = selectStmt.executeQuery()) {
                                if (rs.next()) {
                                    existenciaTotalActual = rs.getInt("ExistenciaTotal");
                                }
                            }
                        }

                        // Calcular la nueva existencia total
                        int nuevaExistenciaTotal = existenciaTotalActual + cantidadInt;

                        // Preparar la consulta SQL para insertar un nuevo producto
                        String insertQuery = "INSERT INTO Productos (Nombre, PrecioUnitario, ProveedorID, ExistenciaActual, ExistenciaTotal, PrecioVenta) VALUES (?, ?, ?, ?, ?, ?)";
                        try ( PreparedStatement preparedStatement = conn.prepareStatement(insertQuery)) {
                            // Establecer los valores de los parámetros en la consulta preparada
                            preparedStatement.setString(1, nombreProducto);
                            preparedStatement.setDouble(2, precioUnitario);
                            preparedStatement.setInt(3, proveedorID);
                            preparedStatement.setInt(4, cantidadInt);
                            preparedStatement.setInt(5, nuevaExistenciaTotal);
                            preparedStatement.setDouble(6, precioVenta);

                            // Ejecutar la consulta SQL para insertar el nuevo producto
                            int rowsInserted = preparedStatement.executeUpdate();

                            // Verificar si se insertaron filas
                            if (rowsInserted > 0) {
                                dispose();
                                JOptionPane.showMessageDialog(null, "Producto registrado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                                new GestionarAlmacen().setVisible(true);
                            } else {
                                JOptionPane.showMessageDialog(null, "Error al registrar el producto.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No se encontró el proveedor en la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (SQLException e) {
                    JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Cantidad, Precio Unitario y Precio Venta deben ser valores numéricos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_jButton_GuardarActionPerformed

    private void jButton_SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_SalirActionPerformed
        dispose();
        new Administrador().setVisible(true);
    }//GEN-LAST:event_jButton_SalirActionPerformed

    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("images/Icono.png"));
        return retValue;
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GestionarAlmacen.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GestionarAlmacen.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GestionarAlmacen.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GestionarAlmacen.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GestionarAlmacen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Actualizar;
    private javax.swing.JButton jButton_Borrar;
    private javax.swing.JButton jButton_Guardar;
    private javax.swing.JButton jButton_Salir;
    private javax.swing.JComboBox<String> jComboBox_Proveedor;
    private javax.swing.JLabel jLabel_Cantidad;
    private javax.swing.JLabel jLabel_Indicaciones;
    private javax.swing.JLabel jLabel_PrecioU;
    private javax.swing.JLabel jLabel_PrecioV;
    private javax.swing.JLabel jLabel_Producto;
    private javax.swing.JLabel jLabel_Proveedor;
    private javax.swing.JLabel jLabel_Titulo;
    private javax.swing.JLabel jLabel_Wallpaper;
    private javax.swing.JLabel jLabel_iconUser;
    private javax.swing.JLabel jLabel_logo;
    private javax.swing.JLabel jLabel_nameUser;
    private javax.swing.JLabel jLabel_numUser;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Productos;
    private javax.swing.JTextField jTextField_Cantidad;
    private javax.swing.JTextField jTextField_PrecioU;
    private javax.swing.JTextField jTextField_PrecioV;
    private javax.swing.JTextField jTextField_Producto;
    // End of variables declaration//GEN-END:variables
}
