package Comandos;

import ConexionBD.Conexion;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import interfaces.gestionarEmpleados;

public class CreacionUsuarios {

    public static void crearNuevoUsuario(String nuevoUsuario, String nuevaContraseña) {
        Connection connection = Conexion.conectar();

        if (connection != null) {
            String createUserSQL;
            String grantPermissionsSQL;
            // Crear un usuario y un inicio de sesión en la base de datos master
            createUserSQL = "CREATE LOGIN " + nuevoUsuario + " WITH PASSWORD = '" + nuevaContraseña + "';";
            executeCommand(connection, createUserSQL);

            if (gestionarEmpleados.TipoUsuario.equals("Gerente")) {
                grantPermissionsSQL = "CREATE USER " + nuevoUsuario + " FOR LOGIN " + nuevoUsuario + "; "
                        + "GRANT SELECT, INSERT, UPDATE, DELETE TO " + nuevoUsuario + " WITH GRANT OPTION;";
            } else {
                grantPermissionsSQL = "USE sysales;"
                        + "CREATE USER " + nuevoUsuario + " FOR LOGIN " + nuevoUsuario + "; "
                        + "GRANT SELECT, INSERT, UPDATE, DELETE TO " + nuevoUsuario + " WITH GRANT OPTION;";
            }

            executeCommand(connection, grantPermissionsSQL);

            // Ejecutar los comandos SQL correspondientes
            executeCommand(connection, grantPermissionsSQL);
            Conexion.cerrarConexion(connection);
        } else {
            System.err.println("No se pudo establecer conexión a la base de datos.");
        }
    }

    //ACA IRIA LA ACTUALIZACION DE USUARIO PERO NO SE COMO HACERLO XD
    //ACA ME LA PELAS DE PASO
    /*public static void actualizarUsuario(String nuevoUsuario, String nuevaContraseña) {
        Connection connection = Conexion.conectar();

        if (connection != null) {
            String alterUserMasterSQL;
            String alterUserSysalesSQL;

            // Modificar la contraseña del usuario en la base de datos master
            alterUserMasterSQL = "ALTER LOGIN " + nuevoUsuario + " WITH PASSWORD = '" + nuevaContraseña + "';";
            executeCommand(connection, alterUserMasterSQL);

            // Modificar la contraseña del usuario en la base de datos sysales
            alterUserSysalesSQL = "USE sysales; "
                    + "ALTER USER " + nuevoUsuario + " FOR LOGIN = '" + nuevoUsuario + "';";
            executeCommand(connection, alterUserSysalesSQL);
        } else {
            System.err.println("No se pudo establecer conexión a la base de datos.");
        }
    }*/
    public static void executeCommand(Connection connection, String sql) {
        try ( Statement statement = connection.createStatement()) {
            statement.execute(sql);
            System.out.println("Comando ejecutado correctamente.");
        } catch (SQLException e) {
            System.err.println("Error al ejecutar el comando SQL: " + e.getMessage());
        }
    }
}
